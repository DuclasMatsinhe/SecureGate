## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (broken.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.691 | 0 |
| pip-audit | VALID | - | 0 | 0.478 | 0 |
| gitleaks | VALID | - | 0 | 0.446 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 723e1f10ff00), strategy S3, run abb9d765-1004-48c3-8fdf-c746485c06a8, engine 2.0.0.dev1._
