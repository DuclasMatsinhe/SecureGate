## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_exp02_wksr833l/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.689 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.453 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f1f4da2c2a3f), strategy S2, run a57f3915-ed3a-431f-b9ef-8974b5781ce4, engine 2.0.0.dev1._
