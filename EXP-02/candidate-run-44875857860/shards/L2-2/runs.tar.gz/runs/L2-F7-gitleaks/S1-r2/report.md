## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.67 | 0 |
| pip-audit | VALID | - | 0 | 0.479 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.476 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a5395cdb4ae8), strategy S1, run 5cd20cfc-27bd-465a-9945-43a28fde9e80, engine 2.0.0.dev1._
