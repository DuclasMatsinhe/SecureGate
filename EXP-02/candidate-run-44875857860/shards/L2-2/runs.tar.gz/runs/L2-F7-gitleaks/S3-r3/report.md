## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.669 | 0 |
| pip-audit | VALID | - | 0 | 0.478 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.483 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 93b146434cc6), strategy S3, run 2cb9e57b-fca8-4f82-87b0-a08a7afb05bf, engine 2.0.0.dev1._
