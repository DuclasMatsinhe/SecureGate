## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.689 | 0 |
| pip-audit | VALID | - | 0 | 0.477 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.477 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a5395cdb4ae8), strategy S1, run a2fafb88-9e2f-426b-9a7b-60c28fa0cb5f, engine 2.0.0.dev1._
