## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.687 | 0 |
| pip-audit | VALID | - | 0 | 0.478 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.484 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a5395cdb4ae8), strategy S1, run 2cbdb86b-7788-4e84-8b95-2ff32284be8b, engine 2.0.0.dev1._
