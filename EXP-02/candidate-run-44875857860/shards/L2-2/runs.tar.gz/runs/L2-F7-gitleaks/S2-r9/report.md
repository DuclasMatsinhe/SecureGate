## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.679 | 0 |
| pip-audit | VALID | - | 0 | 0.47 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.476 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a7e07d32ea6b), strategy S2, run c6474c15-39ed-4825-a832-016c35dbcd94, engine 2.0.0.dev1._
