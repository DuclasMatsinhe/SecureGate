## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.68 | 0 |
| pip-audit | VALID | - | 0 | 0.475 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.474 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a5395cdb4ae8), strategy S1, run 7cb2e23a-3d23-4b0d-afd9-43ee13b66da2, engine 2.0.0.dev1._
