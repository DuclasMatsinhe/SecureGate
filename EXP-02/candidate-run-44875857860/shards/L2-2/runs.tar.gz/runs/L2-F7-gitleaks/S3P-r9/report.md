## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.697 | 0 |
| pip-audit | VALID | - | 0 | 0.478 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.476 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 75e49fc5466f), strategy S3, run 58125c3e-2737-4748-a943-d387d59d2d63, engine 2.0.0.dev1._
