## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.813 | 0 |
| pip-audit | VALID | - | 0 | 0.475 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.473 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 75e49fc5466f), strategy S3, run 8d283d50-9d4f-4f90-9588-226405106fa2, engine 2.0.0.dev1._
