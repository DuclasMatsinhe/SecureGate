## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.662 | 0 |
| pip-audit | VALID | - | 0 | 0.477 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.477 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 93b146434cc6), strategy S3, run c641f8e1-7d21-4ecf-a9fa-cdfd65df88e1, engine 2.0.0.dev1._
