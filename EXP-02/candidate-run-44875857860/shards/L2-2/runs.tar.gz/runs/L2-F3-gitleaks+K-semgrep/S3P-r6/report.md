## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_wksr833l.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.715 | 1 |
| pip-audit | VALID | - | 0 | 0.481 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_wksr833l.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 818084bc3d9a), strategy S3, run 12e95bc0-f739-4016-ac36-ecce5698dd44, engine 2.0.0.dev1._
