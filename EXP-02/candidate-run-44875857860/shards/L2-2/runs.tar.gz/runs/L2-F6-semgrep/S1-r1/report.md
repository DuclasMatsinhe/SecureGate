## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.718 | 0 |
| pip-audit | VALID | - | 0 | 0.475 | 0 |
| gitleaks | VALID | - | 0 | 0.455 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 73d2a24a7727), strategy S1, run d7b0440b-b423-4865-b92c-e776451de3b8, engine 2.0.0.dev1._
