## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.707 | 0 |
| pip-audit | VALID | - | 0 | 0.475 | 0 |
| gitleaks | VALID | - | 0 | 0.445 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f711eb9d6dd9), strategy S3, run 238aafc9-1fbe-4a7c-b6d7-d167325feff3, engine 2.0.0.dev1._
