## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.736 | 0 |
| pip-audit | VALID | - | 0 | 0.476 | 0 |
| gitleaks | VALID | - | 0 | 0.444 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f711eb9d6dd9), strategy S3, run 6f3f1c12-6fba-40d6-bd69-5cbee1b47591, engine 2.0.0.dev1._
