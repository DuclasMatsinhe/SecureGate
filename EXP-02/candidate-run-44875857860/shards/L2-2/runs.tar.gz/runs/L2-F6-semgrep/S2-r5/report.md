## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.741 | 0 |
| pip-audit | VALID | - | 0 | 0.48 | 0 |
| gitleaks | VALID | - | 0 | 0.445 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f0b269313ce4), strategy S2, run 149056bd-a129-4f95-9efd-15e560ecaa48, engine 2.0.0.dev1._
