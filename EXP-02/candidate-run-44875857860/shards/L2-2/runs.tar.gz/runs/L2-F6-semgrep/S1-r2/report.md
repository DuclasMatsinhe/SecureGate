## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.693 | 0 |
| pip-audit | VALID | - | 0 | 0.48 | 0 |
| gitleaks | VALID | - | 0 | 0.446 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 73d2a24a7727), strategy S1, run f4b75552-748a-410d-a5e3-68a13112e2e9, engine 2.0.0.dev1._
