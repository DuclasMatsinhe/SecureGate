## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.675 | 0 |
| pip-audit | VALID | - | 0 | 0.477 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 40a6a2a16951), strategy S3, run 3eebf7d3-f88f-4c19-87a8-82e57b519c1d, engine 2.0.0.dev1._
