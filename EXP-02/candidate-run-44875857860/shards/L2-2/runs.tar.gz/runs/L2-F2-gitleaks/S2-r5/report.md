## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.683 | 0 |
| pip-audit | VALID | - | 0 | 0.477 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 85cdefd389cb), strategy S2, run 0a450525-277c-45c2-85cf-dbc7f86a9a0f, engine 2.0.0.dev1._
