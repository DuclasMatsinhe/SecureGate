## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.693 | 0 |
| pip-audit | VALID | - | 0 | 0.479 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.029 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 40a6a2a16951), strategy S3, run cb8a2625-ef98-4024-8098-13e5cd948365, engine 2.0.0.dev1._
