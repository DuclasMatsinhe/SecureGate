## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.0 | 0 |

_Policy inline v1.0 (sha256 c9ff4b86847b), strategy S3, run 24cf6130-a08a-4f71-b02b-d42d8c60a678, engine 2.0.0.dev1._
