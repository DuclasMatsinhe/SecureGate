## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.198 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ddc3abd259c8), strategy S2, run 34d7e175-7058-457a-8102-f6d2da85fb97, engine 2.0.0.dev1._
