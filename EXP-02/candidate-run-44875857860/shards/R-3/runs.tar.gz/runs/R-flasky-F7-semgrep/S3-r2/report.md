## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1156)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.234 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.339 | 0 |
| gitleaks | VALID | - | 0 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6e77d20b17b7), strategy S3, run b3117699-e1c5-4ab9-92ac-5963ff5c2b3a, engine 2.0.0.dev1._
