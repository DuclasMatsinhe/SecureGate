## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.254 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.354 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e189ad4ef615), strategy S3, run 156025e5-1faa-430e-a9f7-6add0f77a10a, engine 2.0.0.dev1._
