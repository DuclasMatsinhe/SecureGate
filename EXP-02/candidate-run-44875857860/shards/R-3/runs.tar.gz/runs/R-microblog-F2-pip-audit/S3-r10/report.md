## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.222 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.023 | 0 |
| gitleaks | VALID | - | 0 | 0.349 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e189ad4ef615), strategy S3, run 6f5df01f-67da-4b38-8807-9ed3e70a1844, engine 2.0.0.dev1._
