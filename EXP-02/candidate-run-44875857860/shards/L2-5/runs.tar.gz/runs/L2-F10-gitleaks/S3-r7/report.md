## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.245 | 0 |
| pip-audit | VALID | - | 0 | 0.361 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 94e2bf6f5625), strategy S3, run a3083be5-9861-46a1-9337-fada15a27837, engine 2.0.0.dev1._
