## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.269 | 0 |
| pip-audit | VALID | - | 0 | 0.366 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.359 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7bf54da1f074), strategy S2, run 9f4a481d-2c3b-40a3-82fa-f1b48cc15571, engine 2.0.0.dev1._
