## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.274 | 0 |
| pip-audit | VALID | - | 0 | 0.361 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7bf54da1f074), strategy S2, run c0dae0dc-7839-4496-984e-304985d95ca5, engine 2.0.0.dev1._
