## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.242 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | VALID | - | 3 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 23bc9043bd9e), strategy S0, run fec2fa7f-1e46-4549-8161-323194c9a1de, engine 2.0.0.dev1._
