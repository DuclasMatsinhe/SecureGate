## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.247 | 0 |
| pip-audit | VALID | - | 0 | 0.36 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.356 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 94e2bf6f5625), strategy S3, run dd84df52-3ebc-4679-abde-b276427affd9, engine 2.0.0.dev1._
