## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.267 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3da1b62b284a), strategy S3, run a4a62d6c-8a65-4e16-abbf-192cc8d00c91, engine 2.0.0.dev1._
