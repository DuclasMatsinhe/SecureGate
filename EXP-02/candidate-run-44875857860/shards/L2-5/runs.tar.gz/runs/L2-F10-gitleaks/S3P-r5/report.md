## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.253 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3da1b62b284a), strategy S3, run 89beb4c5-5c3e-45ba-b853-6929c8540c5d, engine 2.0.0.dev1._
