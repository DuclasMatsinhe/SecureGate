## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.234 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.356 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3da1b62b284a), strategy S3, run c9097cf6-a0e4-4d7c-af4f-8b9bef205223, engine 2.0.0.dev1._
