## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.23 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.331 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 12c8dfdb330d), strategy S2, run 6ebe126a-193c-49ea-88e3-74c39de7c1a3, engine 2.0.0.dev1._
