## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.26 | 0 |
| pip-audit | VALID | - | 0 | 0.373 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ad673eb6756f), strategy S3, run db565f9b-c84b-453c-99fc-e6851f9a877d, engine 2.0.0.dev1._
