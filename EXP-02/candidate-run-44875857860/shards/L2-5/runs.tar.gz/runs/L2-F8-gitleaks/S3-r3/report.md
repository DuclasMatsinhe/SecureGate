## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.267 | 0 |
| pip-audit | VALID | - | 0 | 0.364 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.334 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9f132c358aee), strategy S3, run d6604c7e-251e-4664-a8bc-c7a4fc50bc93, engine 2.0.0.dev1._
