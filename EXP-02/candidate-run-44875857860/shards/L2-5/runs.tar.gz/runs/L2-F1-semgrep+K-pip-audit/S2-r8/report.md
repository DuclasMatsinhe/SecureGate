## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_pziza9sb/not-installed/tool'
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 1 | 0.366 | 18 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4177 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4175 | dependency | - |

_Policy policy.toml vEXP-02 v1 (sha256 a95e25e5cc3b), strategy S2, run 6367665b-b9f0-4a09-b01c-6e8eca550108, engine 2.0.0.dev1._
