## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 655)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.244 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d78f830ee8b2), strategy S3, run 599e3134-3677-4188-86d3-294ad69c2e3e, engine 2.0.0.dev1._
