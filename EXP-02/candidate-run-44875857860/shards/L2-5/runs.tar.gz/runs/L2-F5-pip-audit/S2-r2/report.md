## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.204 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.369 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1a753d83caff), strategy S2, run 09e5c9b3-a1f7-46d2-853e-b3cda6029bcc, engine 2.0.0.dev1._
