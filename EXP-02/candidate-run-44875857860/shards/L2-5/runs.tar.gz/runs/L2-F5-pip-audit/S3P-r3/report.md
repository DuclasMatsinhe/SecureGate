## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.202 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.375 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4a822db1f709), strategy S3, run 5e87b3a2-3af4-4200-9c9b-06ab8dd2f9fe, engine 2.0.0.dev1._
