## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.369 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4a822db1f709), strategy S3, run 58ac3cbb-8b82-465a-8be7-5953dd4b0b41, engine 2.0.0.dev1._
