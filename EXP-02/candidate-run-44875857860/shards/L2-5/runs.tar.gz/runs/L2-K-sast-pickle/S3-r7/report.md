## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_pziza9sb.probe-pickle-loads (app.py:5)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.227 | 1 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_pziza9sb.probe-pickle-loads | app.py:5 | - |

_Policy policy.toml vEXP-02 v1 (sha256 9f132c358aee), strategy S3, run 6519a336-1552-47e7-a430-be1d261fb1b8, engine 2.0.0.dev1._
