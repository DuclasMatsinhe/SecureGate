## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_pziza9sb.probe-pickle-loads (app.py:5)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.23 | 1 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_pziza9sb.probe-pickle-loads | app.py:5 | - |

_Policy policy.toml vEXP-02 v1 (sha256 4f28185c69f3), strategy S0, run 88352518-c775-4d85-b23c-fbbad0de82c4, engine 2.0.0.dev1._
