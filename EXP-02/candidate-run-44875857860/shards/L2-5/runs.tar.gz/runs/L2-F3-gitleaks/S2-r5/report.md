## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.242 | 0 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 26c7fdb63a1e), strategy S2, run 267d0715-122f-4842-b778-e3d718369fd2, engine 2.0.0.dev1._
