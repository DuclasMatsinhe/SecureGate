## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.216 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 66662695380b), strategy S3, run 40a87475-5778-40e8-aa4f-54ca6170d114, engine 2.0.0.dev1._
