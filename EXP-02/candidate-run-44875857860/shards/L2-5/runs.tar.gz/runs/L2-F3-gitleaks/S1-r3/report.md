## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.252 | 0 |
| pip-audit | VALID | - | 0 | 0.365 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ec4335f046cb), strategy S1, run 55dac3d4-9ef8-4f51-ab07-cdc27a0fd78e, engine 2.0.0.dev1._
