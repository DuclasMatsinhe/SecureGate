## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.258 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 dd3d3571c6bc), strategy S1, run bb1cc11a-8c67-45ce-aed6-1adfa6c4ff0e, engine 2.0.0.dev1._
