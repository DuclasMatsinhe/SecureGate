## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.261 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.365 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.023 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7fc9c3f2b820), strategy S3, run 885a761e-9010-4275-8af4-a10f915d5c3a, engine 2.0.0.dev1._
