## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.269 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.359 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 653098827068), strategy S3, run b536eb8a-c2e3-4e3b-b6f3-f11a2872f85b, engine 2.0.0.dev1._
