## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.226 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.4 | 0 |
| gitleaks | VALID | - | 0 | 1.975 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run 8b1e145f-f25f-4681-a298-afe5325a6bf5, engine 2.0.0.dev1._
