## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.213 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.393 | 0 |
| gitleaks | VALID | - | 0 | 1.936 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ab1dc005d10), strategy S3, run 7d67975e-3042-4110-b11f-f6102071a28f, engine 2.0.0.dev1._
