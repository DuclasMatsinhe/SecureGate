## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.229 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.402 | 0 |
| gitleaks | VALID | - | 0 | 1.969 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ab1dc005d10), strategy S3, run 53613277-87c4-4031-992f-9022222ea534, engine 2.0.0.dev1._
