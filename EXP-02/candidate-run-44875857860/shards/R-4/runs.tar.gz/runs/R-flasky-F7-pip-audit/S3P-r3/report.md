## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.281 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.379 | 0 |
| gitleaks | VALID | - | 0 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run a983fae6-9db4-4817-a225-bcc34cfe80ca, engine 2.0.0.dev1._
