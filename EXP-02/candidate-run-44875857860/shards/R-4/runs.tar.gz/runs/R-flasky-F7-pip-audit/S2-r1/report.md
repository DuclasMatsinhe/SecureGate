## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.271 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.374 | 0 |
| gitleaks | VALID | - | 0 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 481fde2973f8), strategy S2, run 43e6706e-f84d-4528-b997-bb20a8094805, engine 2.0.0.dev1._
