## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.278 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.384 | 0 |
| gitleaks | VALID | - | 0 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run f25cc0fb-003f-4a04-96b6-5cf448c1fc7b, engine 2.0.0.dev1._
