## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.248 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.378 | 0 |
| gitleaks | VALID | - | 0 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ab1dc005d10), strategy S3, run a0e2eae3-14b7-4e39-b40a-cb555e042c3c, engine 2.0.0.dev1._
