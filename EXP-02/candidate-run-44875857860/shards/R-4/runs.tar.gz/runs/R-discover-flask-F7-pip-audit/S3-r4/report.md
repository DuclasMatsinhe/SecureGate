## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 19321)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.197 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.364 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ab1dc005d10), strategy S3, run 89856fe4-9ae0-4f98-94d1-dbc948318572, engine 2.0.0.dev1._
