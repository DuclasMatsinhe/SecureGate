## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.201 | 0 |
| pip-audit | VALID | - | 1 | 0.378 | 0 |
| gitleaks | VALID | - | 0 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 40efebd1f743), strategy S0, run 584966e9-beb2-4006-83a1-2cda16220844, engine 2.0.0.dev1._
