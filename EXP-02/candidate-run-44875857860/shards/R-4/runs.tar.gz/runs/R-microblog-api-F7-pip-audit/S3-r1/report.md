## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 70831)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.262 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.414 | 0 |
| gitleaks | VALID | - | 0 | 0.366 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ab1dc005d10), strategy S3, run 0fca1a4f-0e41-4970-b388-7b5fd7827c6c, engine 2.0.0.dev1._
