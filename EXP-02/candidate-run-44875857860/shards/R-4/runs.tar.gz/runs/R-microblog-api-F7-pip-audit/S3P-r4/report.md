## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 70831)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.266 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.411 | 0 |
| gitleaks | VALID | - | 0 | 0.372 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run 7e28f197-6858-4671-a3fc-6b7d29b0c8b5, engine 2.0.0.dev1._
