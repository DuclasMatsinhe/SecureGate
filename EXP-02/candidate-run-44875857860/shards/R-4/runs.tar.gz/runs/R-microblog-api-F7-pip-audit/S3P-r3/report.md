## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 70831)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.258 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.414 | 0 |
| gitleaks | VALID | - | 0 | 0.364 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run da6414dc-1235-47a5-b7d1-925c3e1259da, engine 2.0.0.dev1._
