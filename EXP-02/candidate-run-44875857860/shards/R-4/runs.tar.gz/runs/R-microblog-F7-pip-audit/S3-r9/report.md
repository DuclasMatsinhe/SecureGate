## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.252 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.419 | 0 |
| gitleaks | VALID | - | 0 | 0.372 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ab1dc005d10), strategy S3, run cbd76d17-23e3-48b9-95b7-e04e51edd984, engine 2.0.0.dev1._
