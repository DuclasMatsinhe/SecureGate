## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.26 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.416 | 0 |
| gitleaks | VALID | - | 0 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run ce2f0f49-d75e-40ea-8a32-8bbed03afc8b, engine 2.0.0.dev1._
