## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.233 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.416 | 0 |
| gitleaks | VALID | - | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 deaa981d1100), strategy S3, run ce6b767a-c613-429b-9911-8a81a85be99e, engine 2.0.0.dev1._
