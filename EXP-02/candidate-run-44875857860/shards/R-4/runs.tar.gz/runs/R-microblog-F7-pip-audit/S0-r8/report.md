## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.265 | 0 |
| pip-audit | VALID | - | 1 | 0.422 | 0 |
| gitleaks | VALID | - | 0 | 0.355 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 40efebd1f743), strategy S0, run 0766c512-c872-4ee6-98d2-c43db6371155, engine 2.0.0.dev1._
