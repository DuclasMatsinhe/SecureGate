## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.946 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.032 | 0 |
| gitleaks | VALID | - | 0 | 2.874 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6cdd1c9aff7e), strategy S1, run 1d79f028-11b7-4a29-a6e2-432e7762bfa4, engine 2.0.0.dev1._
