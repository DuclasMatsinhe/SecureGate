## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.89 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.032 | 0 |
| gitleaks | VALID | - | 0 | 0.511 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 437ffcc50391), strategy S3, run 8125ce31-2c02-4e48-82f6-32a59b9b9c74, engine 2.0.0.dev1._
