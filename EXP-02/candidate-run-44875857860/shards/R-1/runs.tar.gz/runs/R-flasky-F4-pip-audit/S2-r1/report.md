## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.934 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.033 | 0 |
| gitleaks | VALID | - | 0 | 0.485 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f540b861c209), strategy S2, run 179832fa-ec93-4510-b391-68f4590c2df9, engine 2.0.0.dev1._
