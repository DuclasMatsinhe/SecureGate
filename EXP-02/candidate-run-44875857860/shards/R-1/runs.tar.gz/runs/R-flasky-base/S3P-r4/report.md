## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.893 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.528 | 0 |
| gitleaks | VALID | - | 0 | 0.489 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5745dad40562), strategy S3, run 0640074c-8583-4dd0-a82e-7ef3c78633a8, engine 2.0.0.dev1._
