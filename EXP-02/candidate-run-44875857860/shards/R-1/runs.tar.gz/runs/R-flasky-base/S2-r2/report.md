## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.906 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.552 | 0 |
| gitleaks | VALID | - | 0 | 0.501 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4702ae9acc37), strategy S2, run 458092ed-6bed-412e-853e-75ab59266cab, engine 2.0.0.dev1._
