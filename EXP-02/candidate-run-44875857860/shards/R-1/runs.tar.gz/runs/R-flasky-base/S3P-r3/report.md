## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.908 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.523 | 0 |
| gitleaks | VALID | - | 0 | 0.486 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5745dad40562), strategy S3, run 7156d78e-4087-4cc8-b18d-a7ae58f7fd60, engine 2.0.0.dev1._
