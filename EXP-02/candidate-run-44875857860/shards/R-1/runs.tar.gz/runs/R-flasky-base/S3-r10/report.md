## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.958 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.517 | 0 |
| gitleaks | VALID | - | 0 | 0.49 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d4c3dd94d453), strategy S3, run f1333f13-6b00-4917-980f-395e04963c8e, engine 2.0.0.dev1._
