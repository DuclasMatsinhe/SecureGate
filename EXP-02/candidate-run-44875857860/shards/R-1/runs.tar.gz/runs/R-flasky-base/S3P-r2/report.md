## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.896 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.516 | 0 |
| gitleaks | VALID | - | 0 | 0.498 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5745dad40562), strategy S3, run e04ac622-bd93-4335-a0b8-c316591a363c, engine 2.0.0.dev1._
