## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.91 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.517 | 0 |
| gitleaks | VALID | - | 0 | 0.499 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d4c3dd94d453), strategy S3, run 804379f4-848e-4242-8951-6f6fe3f38dca, engine 2.0.0.dev1._
