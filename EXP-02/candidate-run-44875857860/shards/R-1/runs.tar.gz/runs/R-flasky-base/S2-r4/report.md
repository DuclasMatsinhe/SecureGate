## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.915 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.514 | 0 |
| gitleaks | VALID | - | 0 | 0.484 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4702ae9acc37), strategy S2, run 686576d0-1693-4501-b296-b3ed82d05212, engine 2.0.0.dev1._
