## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.914 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.525 | 0 |
| gitleaks | VALID | - | 0 | 0.491 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d4c3dd94d453), strategy S3, run eb5a1f0c-6e7f-411d-b987-d7a71110fe55, engine 2.0.0.dev1._
