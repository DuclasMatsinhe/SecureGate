## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.905 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.031 | 0 |
| gitleaks | VALID | - | 0 | 0.494 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 437ffcc50391), strategy S3, run df050bcf-7e77-4dea-b509-40b8f22dfc6d, engine 2.0.0.dev1._
