## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-pxh4-856f-4h89 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-71 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-71 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2025-183 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-120 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-120 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1383 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1383 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1384 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1384 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1385 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1385 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1605 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1605 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-178 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-178 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1860 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1997 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1997 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-215 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-215 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2152 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2152 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2270 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2270 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3417 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4140 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4144 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4145 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4147 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4183 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4320 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.911 | 0 |
| pip-audit | VALID | - | 1 | 0.555 | 76 |
| gitleaks | VALID | - | 0 | 0.5 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-4320 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4320 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2024-71 | dependency | - |
| pip-audit | HIGH | PYSEC-2024-71 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1385 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1383 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1384 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1383 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1384 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1385 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2152 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2152 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-215 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-215 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1472 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |

_56 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 d4c3dd94d453), strategy S3, run 6fabf4c4-32b9-4cac-9000-7dfe3ef6d3dd, engine 2.0.0.dev1._
