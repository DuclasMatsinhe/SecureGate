## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report
- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (manage.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.909 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.031 | 0 |
| gitleaks | VALID | - | 0 | 0.501 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 437ffcc50391), strategy S3, run e0121862-6bd2-481e-9cd4-c38bdb049d7a, engine 2.0.0.dev1._
