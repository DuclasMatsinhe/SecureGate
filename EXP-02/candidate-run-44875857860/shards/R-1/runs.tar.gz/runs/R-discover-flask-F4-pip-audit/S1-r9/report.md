## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.936 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.033 | 0 |
| gitleaks | VALID | - | 0 | 0.497 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6cdd1c9aff7e), strategy S1, run 99855e79-29aa-4916-9660-33f7fbcaad27, engine 2.0.0.dev1._
