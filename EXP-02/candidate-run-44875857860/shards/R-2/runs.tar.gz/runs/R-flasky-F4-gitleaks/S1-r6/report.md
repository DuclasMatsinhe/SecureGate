## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.048 | 0 |
| pip-audit | VALID | - | 0 | 0.326 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.019 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c1f8a7cf581b), strategy S1, run 38d7f658-c491-41b4-aea8-6f00cf50b762, engine 2.0.0.dev1._
