## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.104 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.292 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.019 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5a8534bab153), strategy S3, run 04b05cf2-c87c-48dd-99e4-826bb54ebe8a, engine 2.0.0.dev1._
