## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.222 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.283 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.018 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 848fac3e1f0a), strategy S2, run 6dd78215-f3ef-4b9d-843a-8e44c6c70223, engine 2.0.0.dev1._
