## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.09 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.291 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.031 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 785f8e1a3849), strategy S3, run 1aa5cf61-be43-457d-a2ca-b9fff94248ec, engine 2.0.0.dev1._
