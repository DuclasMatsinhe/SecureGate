## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.065 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.279 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.019 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5a8534bab153), strategy S3, run c6ba9c96-38df-41f3-9dff-19d2393a18c9, engine 2.0.0.dev1._
