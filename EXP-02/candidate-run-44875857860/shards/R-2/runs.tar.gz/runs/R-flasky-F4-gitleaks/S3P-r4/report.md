## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.046 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.281 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.019 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5a8534bab153), strategy S3, run 94df1526-a53b-4aac-98d1-7f949333767f, engine 2.0.0.dev1._
