## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| pip-audit | VALID | - | 0 | 0.298 | 0 |
| gitleaks | VALID | - | 0 | 0.27 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3ab654daf6dd), strategy S0, run 429291e7-98de-4f0f-8ec4-54eaa44a8987, engine 2.0.0.dev1._
