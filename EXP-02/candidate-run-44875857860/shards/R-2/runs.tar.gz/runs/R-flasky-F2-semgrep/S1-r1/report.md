## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.018 | 0 |
| pip-audit | VALID | - | 0 | 0.289 | 0 |
| gitleaks | VALID | - | 0 | 0.268 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 52a568d4b972), strategy S1, run 3e1c8bcf-4bc6-427c-8834-820124a2ae25, engine 2.0.0.dev1._
