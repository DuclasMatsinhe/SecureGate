## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.018 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.308 | 0 |
| gitleaks | VALID | - | 0 | 0.267 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 471041fed705), strategy S3, run 2cbd37e9-44c1-476b-8a61-207bc6011302, engine 2.0.0.dev1._
