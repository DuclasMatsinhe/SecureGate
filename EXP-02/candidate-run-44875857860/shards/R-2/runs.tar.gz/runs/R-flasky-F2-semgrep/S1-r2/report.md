## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.018 | 0 |
| pip-audit | VALID | - | 0 | 0.277 | 0 |
| gitleaks | VALID | - | 0 | 0.268 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 52a568d4b972), strategy S1, run e89b45a8-e58c-41ff-a624-7d34d5ab263a, engine 2.0.0.dev1._
