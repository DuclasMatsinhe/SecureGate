## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.297 | 0 |
| gitleaks | VALID | - | 0 | 0.273 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5eb3c80bf7c1), strategy S2, run 4e6f9ac6-2a7a-484c-b476-ede2ffd982b2, engine 2.0.0.dev1._
