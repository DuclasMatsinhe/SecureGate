## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.018 | 0 |
| pip-audit | VALID | - | 0 | 0.303 | 0 |
| gitleaks | VALID | - | 0 | 0.27 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3ab654daf6dd), strategy S0, run 979a9bb3-dad0-41ac-b166-cb0e3f2e4e3f, engine 2.0.0.dev1._
