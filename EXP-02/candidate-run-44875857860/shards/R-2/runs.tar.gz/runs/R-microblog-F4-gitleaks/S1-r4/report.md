## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-114605 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-128089 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-pxh4-856f-4h89 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-xmj3-9gf7-h52w (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-242 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-242 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-230 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-230 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-60 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-60 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2025-183 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2025-49 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2025-49 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1111 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1111 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-120 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-120 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1307 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-178 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-178 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1860 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1873 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1873 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1918 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1918 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-215 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-215 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2152 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2152 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2270 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2270 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2987 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2987 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3417 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3447 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3447 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4140 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4144 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4145 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4147 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4183 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4320 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.388 | 0 |
| pip-audit | VALID | - | 1 | 0.389 | 100 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2024-221 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1111 | dependency | - |
| pip-audit | HIGH | PYSEC-2024-221 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1111 | dependency | - |
| pip-audit | HIGH | PYSEC-2024-230 | dependency | - |
| pip-audit | HIGH | PYSEC-2024-230 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4320 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4320 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1307 | dependency | - |
| pip-audit | HIGH | CVE-2026-114605 | dependency | - |
| pip-audit | HIGH | CVE-2026-128089 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2152 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2152 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1434 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1433 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1434 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1433 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-242 | dependency | - |

_80 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 c1f8a7cf581b), strategy S1, run f371542e-1bf6-4f07-b81c-99cd98bd9517, engine 2.0.0.dev1._
