## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.225 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 dd0f95730886), strategy S3, run 697ca94a-fa46-415f-94bd-86b06d71d2dc, engine 2.0.0.dev1._
