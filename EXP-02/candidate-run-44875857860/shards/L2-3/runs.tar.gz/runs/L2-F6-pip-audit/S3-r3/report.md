## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.23 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.375 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 dd0f95730886), strategy S3, run f8b44677-4669-4f97-bd1f-a29a99dbe293, engine 2.0.0.dev1._
