## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.222 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.374 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e30d3ad496cc), strategy S3, run 22227035-f531-4045-a759-dcd5116320f7, engine 2.0.0.dev1._
