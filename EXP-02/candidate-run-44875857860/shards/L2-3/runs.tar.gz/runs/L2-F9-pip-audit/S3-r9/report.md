## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.185 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.372 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7bf889af1de8), strategy S3, run 48b4696b-941f-4a40-87d3-eebfb7339349, engine 2.0.0.dev1._
