## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.184 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.36 | 0 |
| gitleaks | VALID | - | 0 | 0.326 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7fd284a4337a), strategy S2, run 020b9cac-3260-4103-9e99-cee7f432c4f8, engine 2.0.0.dev1._
