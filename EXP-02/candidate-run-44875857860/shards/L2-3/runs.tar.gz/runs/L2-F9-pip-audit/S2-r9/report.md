## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.183 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.362 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7fd284a4337a), strategy S2, run 493a4188-5abf-470f-9ea8-8fa6e4147cb9, engine 2.0.0.dev1._
