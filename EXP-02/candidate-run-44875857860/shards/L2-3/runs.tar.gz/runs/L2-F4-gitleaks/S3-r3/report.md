## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.205 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bb4cd11b0b75), strategy S3, run 3a3682b2-e7fa-4f0b-9614-f3ae930c1689, engine 2.0.0.dev1._
