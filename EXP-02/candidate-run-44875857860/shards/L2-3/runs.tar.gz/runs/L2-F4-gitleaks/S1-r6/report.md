## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.222 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 39b66526d04e), strategy S1, run 8a5e2939-36c7-4f7d-9522-f7828e39398b, engine 2.0.0.dev1._
