## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 668)
- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.198 | 0 |
| pip-audit | VALID | - | 0 | 0.339 | 0 |
| gitleaks | VALID | - | 3 | 0.331 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 71b7c93fce40), strategy S3, run 039ee997-da39-4964-a161-a35aa45bdd77, engine 2.0.0.dev1._
