## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ea03d02c8564), strategy S3, run 5d50cfc4-5305-4097-86e5-36f28b5a463c, engine 2.0.0.dev1._
