## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.004 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 223a7016fc25), strategy S0, run e204453d-33cf-422a-b01a-955017186a66, engine 2.0.0.dev1._
