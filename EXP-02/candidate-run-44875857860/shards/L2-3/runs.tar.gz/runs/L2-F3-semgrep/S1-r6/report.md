## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.004 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ba58c91b55fb), strategy S1, run 6c9b3415-11da-46fe-a7ae-f1739b03e65e, engine 2.0.0.dev1._
