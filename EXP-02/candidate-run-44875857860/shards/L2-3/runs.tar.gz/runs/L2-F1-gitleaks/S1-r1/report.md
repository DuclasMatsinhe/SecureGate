## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_exp02_1osk6fl1/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.208 | 0 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ed8e7b284f96), strategy S1, run b1c5f8a6-a8d7-48f9-8321-43f73f944ede, engine 2.0.0.dev1._
