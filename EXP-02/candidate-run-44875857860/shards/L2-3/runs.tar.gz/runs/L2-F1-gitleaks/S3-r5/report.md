## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_exp02_1osk6fl1/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.185 | 0 |
| pip-audit | VALID | - | 0 | 0.341 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 546ce49893e2), strategy S3, run 49bc8985-25da-497e-9b1b-085625992dc6, engine 2.0.0.dev1._
