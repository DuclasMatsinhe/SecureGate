## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.204 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 3 | 0.336 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 ae020be65a90), strategy S3, run bb100fc0-b40a-4aaa-87d4-4d023d9c4f53, engine 2.0.0.dev1._
