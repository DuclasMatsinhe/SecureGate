## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.236 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | VALID | - | 0 | 0.337 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8168af51a61a), strategy S2, run ed3dba52-86a6-4d20-8883-f85280643b6b, engine 2.0.0.dev1._
