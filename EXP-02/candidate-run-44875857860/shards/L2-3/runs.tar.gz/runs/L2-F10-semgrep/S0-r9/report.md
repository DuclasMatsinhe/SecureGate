## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.237 | 0 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 57464083e0d7), strategy S0, run 94ac9baf-cb60-4664-8017-f9fe0596c84b, engine 2.0.0.dev1._
