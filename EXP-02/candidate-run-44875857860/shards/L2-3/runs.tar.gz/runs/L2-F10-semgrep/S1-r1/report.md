## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.255 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d5a49f71e095), strategy S1, run f8e6b5f7-8707-44c3-8688-6c544816b61f, engine 2.0.0.dev1._
