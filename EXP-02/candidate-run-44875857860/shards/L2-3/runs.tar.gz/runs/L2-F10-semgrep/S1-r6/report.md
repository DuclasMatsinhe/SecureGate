## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.228 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d5a49f71e095), strategy S1, run b2b92217-2bb0-4d56-8074-f2f23c94c3aa, engine 2.0.0.dev1._
