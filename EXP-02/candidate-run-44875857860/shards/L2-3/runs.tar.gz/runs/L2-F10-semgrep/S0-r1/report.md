## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.243 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | VALID | - | 0 | 0.337 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 57464083e0d7), strategy S0, run 46cf0ea1-0151-43a6-8a37-1693508a24c0, engine 2.0.0.dev1._
