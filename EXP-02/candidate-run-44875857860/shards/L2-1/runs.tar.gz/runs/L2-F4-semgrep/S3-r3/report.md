## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.018 | 0 |
| pip-audit | VALID | - | 0 | 0.29 | 0 |
| gitleaks | VALID | - | 0 | 0.258 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4a5027b48be4), strategy S3, run 25a8ecf8-d813-4f80-b623-3309e02b6b75, engine 2.0.0.dev1._
