## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.018 | 0 |
| pip-audit | VALID | - | 0 | 0.282 | 0 |
| gitleaks | VALID | - | 0 | 0.25 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4a5027b48be4), strategy S3, run 3eca12ad-cb3b-4591-81d5-b61d4c59b6cc, engine 2.0.0.dev1._
