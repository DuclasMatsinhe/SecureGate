## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.019 | 0 |
| pip-audit | VALID | - | 0 | 0.285 | 0 |
| gitleaks | VALID | - | 0 | 0.254 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 42d21fa369fe), strategy S2, run f2c5bc19-7817-4c44-8e60-e9fefe52bbc0, engine 2.0.0.dev1._
