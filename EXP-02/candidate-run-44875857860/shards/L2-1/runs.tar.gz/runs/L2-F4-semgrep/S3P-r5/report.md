## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.018 | 0 |
| pip-audit | VALID | - | 0 | 0.286 | 0 |
| gitleaks | VALID | - | 0 | 0.252 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f6f901daa0c5), strategy S3, run 2ae4733e-1102-4275-9ad6-4ecf5e2498d1, engine 2.0.0.dev1._
