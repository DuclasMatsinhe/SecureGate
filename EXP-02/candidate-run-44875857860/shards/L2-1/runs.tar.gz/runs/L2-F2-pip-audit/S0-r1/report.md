## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.164 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.253 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fee1e4fa5475), strategy S0, run e3b63087-92e3-4b64-8e75-6f3baee40eef, engine 2.0.0.dev1._
