## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.038 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.019 | 0 |
| gitleaks | VALID | - | 0 | 0.251 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0f0fe4943ff0), strategy S3, run fe6f2061-0fbb-4167-b264-6c10a519adc5, engine 2.0.0.dev1._
