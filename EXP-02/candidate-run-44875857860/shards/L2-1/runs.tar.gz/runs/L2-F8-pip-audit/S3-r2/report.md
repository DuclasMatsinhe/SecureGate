## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.057 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.282 | 0 |
| gitleaks | VALID | - | 0 | 0.249 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4db1075abe26), strategy S3, run 9b9d4360-69a1-4682-9168-e1d8d7d3138c, engine 2.0.0.dev1._
