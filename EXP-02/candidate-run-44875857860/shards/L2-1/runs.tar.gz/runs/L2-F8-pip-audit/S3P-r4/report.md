## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.045 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.287 | 0 |
| gitleaks | VALID | - | 0 | 0.249 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 eb241095d5b5), strategy S3, run 6307a8f4-10e7-4b0e-8957-9ff786151e41, engine 2.0.0.dev1._
