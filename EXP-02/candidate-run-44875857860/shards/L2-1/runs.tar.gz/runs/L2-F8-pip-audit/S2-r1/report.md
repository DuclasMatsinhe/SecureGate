## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.024 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.277 | 0 |
| gitleaks | VALID | - | 0 | 0.249 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 35a00c2d26a9), strategy S2, run 4336277f-6f17-4caa-9e22-1fcfdf52a7a6, engine 2.0.0.dev1._
