## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.065 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.281 | 0 |
| gitleaks | VALID | - | 0 | 0.255 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4db1075abe26), strategy S3, run 1c9e531c-870d-4678-9256-f4328573f3c3, engine 2.0.0.dev1._
