## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.054 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.284 | 0 |
| gitleaks | VALID | - | 0 | 0.253 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4db1075abe26), strategy S3, run 6eaae9c5-9ece-484d-83df-48507afdb76d, engine 2.0.0.dev1._
