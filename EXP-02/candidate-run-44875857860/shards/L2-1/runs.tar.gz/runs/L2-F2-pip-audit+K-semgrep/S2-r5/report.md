## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_00dmcdd9.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.063 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.019 | 0 |
| gitleaks | VALID | - | 0 | 0.25 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_00dmcdd9.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 09c5ff58a5bc), strategy S2, run c493e846-3a8a-42ef-8b31-9484da33731d, engine 2.0.0.dev1._
