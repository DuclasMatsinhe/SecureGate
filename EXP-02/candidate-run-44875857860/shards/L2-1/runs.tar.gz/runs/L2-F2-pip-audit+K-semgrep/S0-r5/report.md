## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_00dmcdd9.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.04 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.257 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_00dmcdd9.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 fee1e4fa5475), strategy S0, run fb287d5e-5c58-48a8-bc29-be94272a36e6, engine 2.0.0.dev1._
