## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_00dmcdd9.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.098 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.019 | 0 |
| gitleaks | VALID | - | 0 | 0.249 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_00dmcdd9.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 5c9373e37452), strategy S1, run 13f12d21-37da-40e1-85fa-7614155eb5b7, engine 2.0.0.dev1._
