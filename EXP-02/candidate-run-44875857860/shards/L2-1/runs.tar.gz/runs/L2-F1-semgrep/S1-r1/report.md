## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_00dmcdd9/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.278 | 0 |
| gitleaks | VALID | - | 0 | 0.256 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 030bb09ec0c2), strategy S1, run e5ccaa3c-3d4d-40b9-a4e3-57c803a86ec6, engine 2.0.0.dev1._
