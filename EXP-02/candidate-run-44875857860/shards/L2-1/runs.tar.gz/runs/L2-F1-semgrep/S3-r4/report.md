## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_00dmcdd9/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.281 | 0 |
| gitleaks | VALID | - | 0 | 0.252 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 76d13e4f94e8), strategy S3, run c8bc3331-70cb-443a-8571-fcbc5baee45a, engine 2.0.0.dev1._
