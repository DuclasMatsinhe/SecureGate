## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_00dmcdd9/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.286 | 0 |
| gitleaks | VALID | - | 0 | 0.25 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 90fa21664ca2), strategy S0, run f9c9ce70-615b-4bde-af74-ab39d4999387, engine 2.0.0.dev1._
