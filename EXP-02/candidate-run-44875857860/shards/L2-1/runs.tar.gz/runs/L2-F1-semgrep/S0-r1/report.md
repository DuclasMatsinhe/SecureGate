## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_00dmcdd9/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.281 | 0 |
| gitleaks | VALID | - | 0 | 0.261 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 90fa21664ca2), strategy S0, run 2d716925-5d78-4243-83ed-5bc85f9f17e8, engine 2.0.0.dev1._
