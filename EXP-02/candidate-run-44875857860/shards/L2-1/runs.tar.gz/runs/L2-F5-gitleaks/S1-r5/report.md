## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.033 | 0 |
| pip-audit | VALID | - | 0 | 0.285 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.277 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 05fca452b4b8), strategy S1, run e7c1094a-200d-4a68-b069-e34db197ab69, engine 2.0.0.dev1._
