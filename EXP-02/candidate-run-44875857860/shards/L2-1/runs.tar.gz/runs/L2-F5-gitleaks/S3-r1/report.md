## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.08 | 0 |
| pip-audit | VALID | - | 0 | 0.296 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.275 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5eaeb6827178), strategy S3, run 545a0d5f-7afb-4a7c-be3a-a63e2fb7f87a, engine 2.0.0.dev1._
