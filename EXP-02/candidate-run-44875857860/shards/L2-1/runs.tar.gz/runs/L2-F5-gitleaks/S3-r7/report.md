## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.122 | 0 |
| pip-audit | VALID | - | 0 | 0.292 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.28 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5eaeb6827178), strategy S3, run 31cc366f-18a8-4da2-a700-11320ab4fb0a, engine 2.0.0.dev1._
