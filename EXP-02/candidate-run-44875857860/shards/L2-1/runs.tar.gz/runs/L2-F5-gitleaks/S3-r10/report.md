## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.063 | 0 |
| pip-audit | VALID | - | 0 | 0.281 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.27 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5eaeb6827178), strategy S3, run 47f95032-f38e-46ab-a75f-267f2f1bd291, engine 2.0.0.dev1._
