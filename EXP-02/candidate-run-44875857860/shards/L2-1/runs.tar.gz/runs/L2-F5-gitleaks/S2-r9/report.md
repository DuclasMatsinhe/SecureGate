## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.062 | 0 |
| pip-audit | VALID | - | 0 | 0.284 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.277 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1f852bfa7072), strategy S2, run 1622f159-cd63-4521-90c3-f21090ac2c66, engine 2.0.0.dev1._
