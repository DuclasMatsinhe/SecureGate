## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.06 | 0 |
| pip-audit | VALID | - | 0 | 0.289 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.271 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1f852bfa7072), strategy S2, run 1e513249-936d-4aef-9c5a-6ef8e33eb937, engine 2.0.0.dev1._
