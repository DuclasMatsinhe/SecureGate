## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.028 | 0 |
| pip-audit | VALID | - | 0 | 0.293 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.273 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ad4895e3447e), strategy S3, run e169dde7-b5c4-4c0e-9af6-91a6b1a32008, engine 2.0.0.dev1._
