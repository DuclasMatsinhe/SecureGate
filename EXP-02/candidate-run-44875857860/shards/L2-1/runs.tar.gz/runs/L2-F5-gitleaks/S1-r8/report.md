## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.034 | 0 |
| pip-audit | VALID | - | 0 | 0.28 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.275 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 05fca452b4b8), strategy S1, run a631a6a4-59c9-416f-bf70-ac50dd61ccd1, engine 2.0.0.dev1._
