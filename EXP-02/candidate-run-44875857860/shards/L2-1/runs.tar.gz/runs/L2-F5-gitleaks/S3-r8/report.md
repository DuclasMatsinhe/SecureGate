## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.047 | 0 |
| pip-audit | VALID | - | 0 | 0.285 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.269 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5eaeb6827178), strategy S3, run eecef770-c5be-4cac-bc59-1f7df33068d5, engine 2.0.0.dev1._
