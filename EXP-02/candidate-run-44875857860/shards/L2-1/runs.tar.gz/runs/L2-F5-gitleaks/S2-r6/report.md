## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.046 | 0 |
| pip-audit | VALID | - | 0 | 0.285 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.275 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1f852bfa7072), strategy S2, run 04ffdc27-fd19-4d9f-99dd-3b375a94a218, engine 2.0.0.dev1._
