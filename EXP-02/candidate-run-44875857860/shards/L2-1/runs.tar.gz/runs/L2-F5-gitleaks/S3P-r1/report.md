## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.041 | 0 |
| pip-audit | VALID | - | 0 | 0.284 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.276 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ad4895e3447e), strategy S3, run 8798ab81-7e0a-4af4-b49c-0c7383dc876c, engine 2.0.0.dev1._
