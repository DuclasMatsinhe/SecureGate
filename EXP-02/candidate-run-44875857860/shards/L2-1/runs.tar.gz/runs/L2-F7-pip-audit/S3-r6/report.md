## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.063 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.31 | 0 |
| gitleaks | VALID | - | 0 | 0.254 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 503be1809144), strategy S3, run 3fbcd3c9-0875-43e8-ba46-3e26ba2d7832, engine 2.0.0.dev1._
