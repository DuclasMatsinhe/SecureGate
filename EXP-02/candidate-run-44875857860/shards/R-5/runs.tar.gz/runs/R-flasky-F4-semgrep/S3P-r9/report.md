## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.348 | 0 |
| gitleaks | VALID | - | 0 | 0.35 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 36ce13cbeb85), strategy S3, run d4be051c-94d4-4ec3-9a24-84f1fe608bb8, engine 2.0.0.dev1._
