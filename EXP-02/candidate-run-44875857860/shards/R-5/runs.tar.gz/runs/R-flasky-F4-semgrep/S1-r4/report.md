## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| pip-audit | VALID | - | 0 | 0.343 | 0 |
| gitleaks | VALID | - | 0 | 0.35 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d86e474a3d56), strategy S1, run 5cef055a-63e7-4701-8e1a-e632b031e2fa, engine 2.0.0.dev1._
