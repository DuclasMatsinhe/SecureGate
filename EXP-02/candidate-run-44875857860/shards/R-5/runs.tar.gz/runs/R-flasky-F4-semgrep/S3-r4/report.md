## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.35 | 0 |
| gitleaks | VALID | - | 0 | 0.354 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1379793ff6a2), strategy S3, run 64e43a2d-4e98-4ac7-9559-2d3af6e5e194, engine 2.0.0.dev1._
