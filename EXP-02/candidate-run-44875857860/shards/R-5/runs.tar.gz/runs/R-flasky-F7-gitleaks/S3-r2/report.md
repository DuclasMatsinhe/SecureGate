## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.219 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.344 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.379 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e4e9950c0691), strategy S3, run f79f6e8c-00f8-4b1f-a4ad-5f984001a098, engine 2.0.0.dev1._
