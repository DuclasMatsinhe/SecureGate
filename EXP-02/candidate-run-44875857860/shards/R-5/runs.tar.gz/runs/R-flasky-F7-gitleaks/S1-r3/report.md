## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.201 | 0 |
| pip-audit | VALID | - | 0 | 0.339 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.367 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 abd54658ec51), strategy S1, run 15775a27-40d7-410e-a854-9f5e61518c3f, engine 2.0.0.dev1._
