## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.202 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.343 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.376 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8993623e3c27), strategy S2, run 2766c828-2984-4ec0-97c1-9cd8c59f1593, engine 2.0.0.dev1._
