## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.227 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.346 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.383 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9d80f1e22037), strategy S3, run acc013cf-1041-475e-82f3-e35c7d710dc8, engine 2.0.0.dev1._
