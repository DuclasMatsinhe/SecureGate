## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.19 | 0 |
| pip-audit | VALID | - | 0 | 0.339 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.367 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 abd54658ec51), strategy S1, run 1ba61243-3e69-4d62-9b3c-a5bc12e56bc0, engine 2.0.0.dev1._
