## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.264 | 0 |
| pip-audit | VALID | - | 1 | 0.385 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bb940740a74d), strategy S1, run 46b42dd7-1010-486a-a72c-d91afbf0cfa4, engine 2.0.0.dev1._
