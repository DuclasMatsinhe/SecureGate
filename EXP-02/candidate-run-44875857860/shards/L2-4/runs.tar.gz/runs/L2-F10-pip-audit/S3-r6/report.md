## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.256 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.381 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 92bd902b1300), strategy S3, run 3fa7a165-70b3-4376-8d20-cb6c214bb820, engine 2.0.0.dev1._
