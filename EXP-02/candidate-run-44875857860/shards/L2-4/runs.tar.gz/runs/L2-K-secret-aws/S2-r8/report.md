## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: aws-access-token (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.24 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | VALID | - | 3 | 0.347 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | aws-access-token | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 d3b8bad3e8bc), strategy S2, run 5d283c64-8d54-4875-9d57-a2d9d163b396, engine 2.0.0.dev1._
