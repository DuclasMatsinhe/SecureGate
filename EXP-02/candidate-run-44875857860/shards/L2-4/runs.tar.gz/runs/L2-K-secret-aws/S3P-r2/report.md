## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: aws-access-token (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.257 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | VALID | - | 3 | 0.344 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | aws-access-token | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 ac5631922163), strategy S3, run df07b658-5411-4a54-b0d8-b3c9522570c9, engine 2.0.0.dev1._
