## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: pip-audit: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.259 | 0 |
| pip-audit | INVALID | TIMEOUT | None | 3.005 | 0 |
| gitleaks | VALID | - | 0 | 0.342 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7a116840becc), strategy S0, run 318f0d4c-567d-4c13-8f15-990206201bab, engine 2.0.0.dev1._
