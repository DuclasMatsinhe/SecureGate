## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 6:53AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.184 | 0 |
| pip-audit | VALID | - | 0 | 0.337 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.218 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d94ef528a1e1), strategy S0, run bc1f223e-9b88-4827-81e4-44478ed5112a, engine 2.0.0.dev1._
