## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 6:54AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 6:54AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.18 | 0 |
| pip-audit | VALID | - | 0 | 0.341 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.218 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ffdad2e5f1c8), strategy S1, run af522239-cf72-4869-b5fd-62f434a4ba89, engine 2.0.0.dev1._
