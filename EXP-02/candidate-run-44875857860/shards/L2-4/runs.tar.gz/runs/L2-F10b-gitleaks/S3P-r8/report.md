## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 6:55AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 6:55AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.193 | 0 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.218 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 02b713784b18), strategy S3, run 2be624f9-16e0-4313-8213-69126eb83450, engine 2.0.0.dev1._
