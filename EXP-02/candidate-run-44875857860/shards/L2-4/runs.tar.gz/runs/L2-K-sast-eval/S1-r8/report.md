## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_nvkec5hw.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.189 | 1 |
| pip-audit | VALID | - | 0 | 0.339 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_nvkec5hw.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 aa3fdd751911), strategy S1, run f77190d2-b07d-41ff-8a07-8415329367a0, engine 2.0.0.dev1._
