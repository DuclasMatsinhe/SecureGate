## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_nvkec5hw.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.224 | 1 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_nvkec5hw.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 ac5631922163), strategy S3, run 1d67887a-cddf-4867-ad2d-ade03da4e408, engine 2.0.0.dev1._
