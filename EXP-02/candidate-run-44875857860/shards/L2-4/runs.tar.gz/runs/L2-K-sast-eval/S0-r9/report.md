## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_nvkec5hw.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.186 | 1 |
| pip-audit | VALID | - | 0 | 0.34 | 0 |
| gitleaks | VALID | - | 0 | 0.329 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_nvkec5hw.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 6907c7a45975), strategy S0, run 3c76e89e-cb06-4431-b464-b1d35630ecc6, engine 2.0.0.dev1._
