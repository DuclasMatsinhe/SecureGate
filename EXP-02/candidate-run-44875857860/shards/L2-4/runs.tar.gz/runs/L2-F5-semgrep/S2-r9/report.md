## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 1.271 | 0 |
| pip-audit | VALID | - | 0 | 0.36 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fac915bf6403), strategy S2, run e69bb4eb-4c16-4fec-a67d-af930915772a, engine 2.0.0.dev1._
