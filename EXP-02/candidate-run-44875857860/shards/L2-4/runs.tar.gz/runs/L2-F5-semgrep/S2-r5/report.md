## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 1.308 | 0 |
| pip-audit | VALID | - | 0 | 0.366 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fac915bf6403), strategy S2, run 87025cfa-8020-45fa-a23a-cdcbaaffc3f5, engine 2.0.0.dev1._
