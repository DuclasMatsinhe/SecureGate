## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 1.303 | 0 |
| pip-audit | VALID | - | 0 | 0.365 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fac915bf6403), strategy S2, run 388c625e-d7d7-473f-abb5-10192cd42106, engine 2.0.0.dev1._
