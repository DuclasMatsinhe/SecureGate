## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 1.279 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | VALID | - | 0 | 0.339 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ede4e164ff3e), strategy S3, run cdb7316e-6670-4bce-a300-2149be304291, engine 2.0.0.dev1._
