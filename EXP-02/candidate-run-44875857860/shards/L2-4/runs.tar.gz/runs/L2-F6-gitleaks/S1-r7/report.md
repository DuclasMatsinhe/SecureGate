## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.27 | 0 |
| pip-audit | VALID | - | 0 | 0.361 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.359 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5086eca930c4), strategy S1, run 561ba604-d699-4f28-ac99-e0c40b50b532, engine 2.0.0.dev1._
