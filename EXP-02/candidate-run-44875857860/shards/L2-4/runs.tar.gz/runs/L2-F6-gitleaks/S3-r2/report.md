## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.241 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.365 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b572027c6a1c), strategy S3, run 4215f670-87d3-48c7-990d-dd89f525544d, engine 2.0.0.dev1._
