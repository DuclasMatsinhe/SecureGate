## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.26 | 0 |
| pip-audit | VALID | - | 0 | 0.361 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.367 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b572027c6a1c), strategy S3, run 03b6951f-0a09-4e0e-8dfe-cf1807cab856, engine 2.0.0.dev1._
