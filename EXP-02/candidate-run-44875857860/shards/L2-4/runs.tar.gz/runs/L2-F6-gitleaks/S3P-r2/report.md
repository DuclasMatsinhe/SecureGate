## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.248 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.354 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8fdddea1e311), strategy S3, run 74e9347a-aaf4-4a9c-9a96-46b8e7f41c94, engine 2.0.0.dev1._
