## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.256 | 0 |
| pip-audit | VALID | - | 0 | 0.536 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.354 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9142a766383b), strategy S2, run fbf52ada-b0d9-46e1-b08d-f1e24196a44d, engine 2.0.0.dev1._
