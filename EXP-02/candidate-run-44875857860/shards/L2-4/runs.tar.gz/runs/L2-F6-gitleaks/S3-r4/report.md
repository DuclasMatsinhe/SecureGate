## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.234 | 0 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.363 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b572027c6a1c), strategy S3, run 7d447460-2a0e-432a-ae12-4df510c243fa, engine 2.0.0.dev1._
