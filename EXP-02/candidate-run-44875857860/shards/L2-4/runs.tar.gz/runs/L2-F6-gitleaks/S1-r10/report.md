## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.232 | 0 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.361 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5086eca930c4), strategy S1, run 7f1e0038-dd2d-4538-9407-954b36c1ae97, engine 2.0.0.dev1._
