## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.236 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8fdddea1e311), strategy S3, run e4b3cfbe-efba-47e3-9821-839ae72d6f5d, engine 2.0.0.dev1._
