## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.259 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9142a766383b), strategy S2, run d186c698-9566-48fa-991f-40a00a2d22bb, engine 2.0.0.dev1._
