## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.21 | 0 |
| pip-audit | VALID | - | 0 | 0.022 | 0 |
| gitleaks | VALID | - | 3 | 0.34 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 35c98c275bdb), strategy S0, run 66e1a7e8-91a1-4877-8037-a4f90016d3e6, engine 2.0.0.dev1._
