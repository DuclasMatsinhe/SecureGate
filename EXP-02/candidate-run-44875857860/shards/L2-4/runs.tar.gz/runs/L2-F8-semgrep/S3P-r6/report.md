## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.198 | 0 |
| pip-audit | VALID | - | 0 | 0.342 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ac5631922163), strategy S3, run 664af9df-50af-4d20-8dd1-6909042d3f39, engine 2.0.0.dev1._
