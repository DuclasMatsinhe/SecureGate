## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (config.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 3 | 0.0 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | config.py:1 | - |

_Policy inline v1.0 (sha256 aa9b385ffe88), strategy S0, run 8e0505f8-4eed-4e77-8a24-53651110c2d8, engine 2.0.0.dev1._
