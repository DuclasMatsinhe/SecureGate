## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 c9ff4b86847b), strategy S3, run 4ad9a89e-c049-4d9d-bd8f-8a9ea6f8367f, engine 2.0.0.dev1._
