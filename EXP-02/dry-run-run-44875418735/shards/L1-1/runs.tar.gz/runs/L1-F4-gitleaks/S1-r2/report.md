## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 399578376279), strategy S1, run 3c2b3bc8-2e39-42e7-9cb4-dd802c492b50, engine 2.0.0.dev1._
