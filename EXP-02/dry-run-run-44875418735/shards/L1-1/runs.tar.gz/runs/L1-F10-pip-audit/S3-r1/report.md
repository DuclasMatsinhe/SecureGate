## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 c9ff4b86847b), strategy S3, run 89762eb9-6fbc-4e41-9c24-e43e44db8f70, engine 2.0.0.dev1._
