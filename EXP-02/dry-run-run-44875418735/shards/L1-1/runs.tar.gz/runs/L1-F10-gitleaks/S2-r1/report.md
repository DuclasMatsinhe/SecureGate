## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.0 | 0 |

_Policy inline v1.0 (sha256 ad9fd14fc93b), strategy S2, run 69e4f300-4745-4d5a-8d70-cde01749d4c6, engine 2.0.0.dev1._
