## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.207 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.371 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 83cc559140ac), strategy S1, run 4380671b-a80f-4c8e-9977-9dd53a6619b8, engine 2.0.0.dev1._
