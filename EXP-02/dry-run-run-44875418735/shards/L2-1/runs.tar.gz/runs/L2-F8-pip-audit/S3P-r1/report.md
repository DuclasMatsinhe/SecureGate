## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.32 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.375 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 29f3c2e7d0e5), strategy S3, run bf8aa72d-20cd-45ad-8692-8197ef116cc8, engine 2.0.0.dev1._
