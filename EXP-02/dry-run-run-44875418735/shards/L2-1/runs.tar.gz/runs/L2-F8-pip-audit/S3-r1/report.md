## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.309 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.37 | 0 |
| gitleaks | VALID | - | 0 | 0.34 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6aaa34a3818e), strategy S3, run dc5065a3-cab7-4183-865b-1b0c209a0f3f, engine 2.0.0.dev1._
