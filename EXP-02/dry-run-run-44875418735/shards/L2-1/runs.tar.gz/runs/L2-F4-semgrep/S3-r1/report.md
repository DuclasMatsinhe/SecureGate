## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.366 | 0 |
| gitleaks | VALID | - | 0 | 0.341 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 28cbdb5e04b4), strategy S3, run 1c9cfb25-caf5-4ff8-bd3e-83be86edccc8, engine 2.0.0.dev1._
