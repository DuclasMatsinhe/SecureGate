## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.364 | 0 |
| gitleaks | VALID | - | 0 | 0.345 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f558a0bd67b0), strategy S2, run 89a296b6-1294-48bf-800f-1756f2acf5b3, engine 2.0.0.dev1._
