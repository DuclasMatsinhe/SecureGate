## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.306 | 0 |
| pip-audit | VALID | - | 0 | 0.367 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.363 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0e115a69ca71), strategy S3, run 7c93718d-fcae-4863-b468-5114dbe7da21, engine 2.0.0.dev1._
