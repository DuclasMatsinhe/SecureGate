## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.27 | 0 |
| pip-audit | VALID | - | 0 | 0.369 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.364 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c117f371f73d), strategy S1, run d07ce12a-493b-498b-bf68-41e82c988559, engine 2.0.0.dev1._
