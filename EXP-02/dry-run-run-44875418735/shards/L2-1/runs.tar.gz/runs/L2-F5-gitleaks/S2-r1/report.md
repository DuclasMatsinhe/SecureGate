## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.299 | 0 |
| pip-audit | VALID | - | 0 | 0.37 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c3f7acc4eded), strategy S2, run 95f681c8-b49a-4f08-a581-e004ac91593d, engine 2.0.0.dev1._
