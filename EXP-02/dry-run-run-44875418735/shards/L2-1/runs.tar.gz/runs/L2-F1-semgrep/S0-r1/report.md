## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_n9l5koan/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.368 | 0 |
| gitleaks | VALID | - | 0 | 0.343 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ee1d9e69d2e3), strategy S0, run 88e5d633-1676-44e5-bd08-b6d7e59c4ae4, engine 2.0.0.dev1._
