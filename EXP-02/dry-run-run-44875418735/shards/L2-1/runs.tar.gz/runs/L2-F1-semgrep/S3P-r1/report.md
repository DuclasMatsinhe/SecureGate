## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_n9l5koan/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.371 | 0 |
| gitleaks | VALID | - | 0 | 0.344 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9b7f9f392a31), strategy S3, run e710748f-3504-4557-8f9f-16ab2869370e, engine 2.0.0.dev1._
