## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | VALID | - | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a3b4d5f9bca6), strategy S0, run 6594b5fa-5def-4e70-a3db-fbf04a48e2e7, engine 2.0.0.dev1._
