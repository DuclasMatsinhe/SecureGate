## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1155)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.401 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.368 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 dcf27c2ce835), strategy S3, run a5fa371b-8902-44ec-8c36-22ca030a3a8e, engine 2.0.0.dev1._
