## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1155)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.407 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.374 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9b45a836a62c), strategy S3, run 8c8e5d3c-b87c-483a-9f9d-bce3fc172aac, engine 2.0.0.dev1._
