## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.346 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.025 | 0 |
| gitleaks | VALID | - | 0 | 0.375 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5ad6e47ccecc), strategy S2, run 9187d0a3-ac46-4653-88f2-b13abe39b161, engine 2.0.0.dev1._
