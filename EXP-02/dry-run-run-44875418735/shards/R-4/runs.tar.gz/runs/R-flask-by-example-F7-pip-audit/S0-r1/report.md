## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.197 | 0 |
| pip-audit | VALID | - | 1 | 0.394 | 0 |
| gitleaks | VALID | - | 0 | 1.965 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 74b2d2a28b69), strategy S0, run e9f5fed0-c329-48f0-858e-6a2c82f3c160, engine 2.0.0.dev1._
