## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.214 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.395 | 0 |
| gitleaks | VALID | - | 0 | 1.954 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2ec32b148969), strategy S3, run 825df82e-3460-4956-a3f7-811eab6d863d, engine 2.0.0.dev1._
