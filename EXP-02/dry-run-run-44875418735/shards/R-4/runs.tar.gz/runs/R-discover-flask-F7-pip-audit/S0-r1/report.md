## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.2 | 0 |
| pip-audit | VALID | - | 1 | 0.381 | 0 |
| gitleaks | VALID | - | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 74b2d2a28b69), strategy S0, run 0c525853-e860-4e15-9ff2-991cfd86590a, engine 2.0.0.dev1._
