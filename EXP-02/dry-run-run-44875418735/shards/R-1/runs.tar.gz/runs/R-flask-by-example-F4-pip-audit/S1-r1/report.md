## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.209 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 1.93 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 354164abaed7), strategy S1, run 1a21d57c-c7a5-41f6-a844-ed19cb83c964, engine 2.0.0.dev1._
