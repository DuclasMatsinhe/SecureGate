## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.225 | 0 |
| pip-audit | VALID | - | 0 | 0.346 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 023c7df86661), strategy S2, run 6046d707-4899-4def-ac20-c638b8b0f4af, engine 2.0.0.dev1._
