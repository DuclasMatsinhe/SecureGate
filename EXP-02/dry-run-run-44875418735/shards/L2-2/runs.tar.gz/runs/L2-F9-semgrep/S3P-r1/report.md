## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (broken.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.204 | 0 |
| pip-audit | VALID | - | 0 | 0.34 | 0 |
| gitleaks | VALID | - | 0 | 0.328 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 263edb0f770c), strategy S3, run 6d922fad-5bd9-4ffe-a2e2-a854d5d20ea4, engine 2.0.0.dev1._
