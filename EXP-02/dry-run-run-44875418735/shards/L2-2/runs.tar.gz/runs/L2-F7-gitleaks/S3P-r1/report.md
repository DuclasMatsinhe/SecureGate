## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.176 | 0 |
| pip-audit | VALID | - | 0 | 0.34 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 312c45425d33), strategy S3, run 3fb83930-8021-4d73-8c01-95cd942f4d13, engine 2.0.0.dev1._
