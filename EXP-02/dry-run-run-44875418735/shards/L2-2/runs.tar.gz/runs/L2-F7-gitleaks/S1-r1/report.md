## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | VALID | - | 0 | 0.342 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6b791f2c5c8d), strategy S1, run 7a0b74cc-e104-473d-9d62-6422e8e6f67c, engine 2.0.0.dev1._
