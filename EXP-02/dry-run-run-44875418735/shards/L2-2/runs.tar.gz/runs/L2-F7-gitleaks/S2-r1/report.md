## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.234 | 0 |
| pip-audit | VALID | - | 0 | 0.34 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9f12bb02d60c), strategy S2, run f1213b1e-5765-4fbe-8509-34b8352e5f3d, engine 2.0.0.dev1._
