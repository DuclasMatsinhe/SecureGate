## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_t_b8llv4.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 1 |
| pip-audit | VALID | - | 0 | 0.346 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_t_b8llv4.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 4918c2736f40), strategy S3, run 21679f08-b0ab-4578-9980-cc4575885ccc, engine 2.0.0.dev1._
