## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_t_b8llv4.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.209 | 1 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_t_b8llv4.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 e900a3db7dec), strategy S3, run 07f89fad-beb9-44d4-ae7e-f5dccaf29b59, engine 2.0.0.dev1._
