## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_t_b8llv4.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.193 | 1 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_t_b8llv4.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 0752bcf9d6a0), strategy S2, run 2d82e2bc-b328-4a8f-ac15-66579c00dd8a, engine 2.0.0.dev1._
