## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.263 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 399c0f69bf67), strategy S3, run cab04960-72c8-4740-b56a-6169cd9f435c, engine 2.0.0.dev1._
