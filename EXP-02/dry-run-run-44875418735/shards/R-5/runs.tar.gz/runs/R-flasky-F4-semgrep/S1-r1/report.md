## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| pip-audit | VALID | - | 0 | 0.341 | 0 |
| gitleaks | VALID | - | 0 | 0.349 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e3af339e5397), strategy S1, run 375f213e-04fc-4197-ba64-1754d1bdb55c, engine 2.0.0.dev1._
