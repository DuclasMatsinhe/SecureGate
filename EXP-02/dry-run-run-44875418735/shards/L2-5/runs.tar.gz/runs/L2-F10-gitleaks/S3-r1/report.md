## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.209 | 0 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 373d972e40d4), strategy S3, run af485dd5-01f9-4f3b-8ed6-9bd6f418b0d3, engine 2.0.0.dev1._
