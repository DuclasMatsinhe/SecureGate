## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.182 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.369 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e8d0f3f2dbe4), strategy S3, run d1a44c93-2d3d-4854-adc0-b12d31f7a4e7, engine 2.0.0.dev1._
