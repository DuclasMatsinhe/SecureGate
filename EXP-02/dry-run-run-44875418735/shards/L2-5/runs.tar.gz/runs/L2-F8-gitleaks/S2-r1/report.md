## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.22 | 0 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ddf5ed505a06), strategy S2, run 93db3f20-d2ac-4f2c-af54-220fb383cf04, engine 2.0.0.dev1._
