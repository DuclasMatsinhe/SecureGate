## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_hk0plet4.probe-pickle-loads (app.py:5)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.24 | 1 |
| pip-audit | VALID | - | 0 | 0.435 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_hk0plet4.probe-pickle-loads | app.py:5 | - |

_Policy policy.toml vEXP-02 v1 (sha256 cd1eae277ec2), strategy S0, run 49d04e3d-a118-468a-b8af-80b72e089efe, engine 2.0.0.dev1._
