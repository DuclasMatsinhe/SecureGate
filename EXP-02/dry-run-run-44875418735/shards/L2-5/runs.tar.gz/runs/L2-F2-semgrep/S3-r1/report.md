## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| pip-audit | VALID | - | 0 | 0.392 | 0 |
| gitleaks | VALID | - | 0 | 0.329 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f8aba902a606), strategy S3, run a64cdbf3-1816-4d9e-8d23-8673ef8f7306, engine 2.0.0.dev1._
