## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: pip-audit: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.228 | 0 |
| pip-audit | INVALID | TIMEOUT | None | 3.005 | 0 |
| gitleaks | VALID | - | 0 | 0.339 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6faba490c246), strategy S2, run a2c6b9e2-deca-4196-b481-e85fe2fd433e, engine 2.0.0.dev1._
