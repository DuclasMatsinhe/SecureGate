## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.261 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.364 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7149f686b548), strategy S3, run 38d27c36-163c-4733-bc0d-dca720d8cfad, engine 2.0.0.dev1._
