## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.249 | 0 |
| pip-audit | VALID | - | 0 | 0.36 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9c329c834048), strategy S1, run 30332e4d-272e-46d0-8be0-8bde14703407, engine 2.0.0.dev1._
