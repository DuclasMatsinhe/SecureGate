## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 6:27AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 6:27AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.258 | 0 |
| pip-audit | VALID | - | 0 | 0.36 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.232 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 aab700b1ce03), strategy S3, run dff58946-5f90-4cca-bc7b-4b50960d0fc2, engine 2.0.0.dev1._
