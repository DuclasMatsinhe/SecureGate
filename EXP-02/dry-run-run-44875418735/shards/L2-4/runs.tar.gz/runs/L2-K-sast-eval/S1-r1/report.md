## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_jy9k3lek.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.262 | 1 |
| pip-audit | VALID | - | 0 | 0.362 | 0 |
| gitleaks | VALID | - | 0 | 0.341 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_jy9k3lek.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 6ea06f05e8bb), strategy S1, run ee825c0a-6ddb-4a2e-8980-1588448cd0df, engine 2.0.0.dev1._
