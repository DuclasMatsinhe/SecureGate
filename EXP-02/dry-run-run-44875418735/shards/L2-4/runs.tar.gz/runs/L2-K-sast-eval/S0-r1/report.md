## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_jy9k3lek.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.222 | 1 |
| pip-audit | VALID | - | 0 | 0.393 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_jy9k3lek.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 ab0f8a7381c1), strategy S0, run db4fc98e-4169-4766-9a1f-26a78563ec37, engine 2.0.0.dev1._
