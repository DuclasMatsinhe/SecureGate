## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1155)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.505 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.389 | 0 |
| gitleaks | VALID | - | 0 | 0.37 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d59f35a215bd), strategy S3, run a48b3189-1a85-4dd7-a260-90ce089e4c48, engine 2.0.0.dev1._
