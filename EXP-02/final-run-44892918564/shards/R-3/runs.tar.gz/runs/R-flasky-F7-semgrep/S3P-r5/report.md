## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1155)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.427 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.385 | 0 |
| gitleaks | VALID | - | 0 | 0.38 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d59f35a215bd), strategy S3, run 82de3abc-e07d-4d4a-a82a-e3ecda800e45, engine 2.0.0.dev1._
