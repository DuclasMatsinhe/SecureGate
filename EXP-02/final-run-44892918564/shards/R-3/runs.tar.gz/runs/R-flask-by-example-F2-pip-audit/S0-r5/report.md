## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.391 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.025 | 0 |
| gitleaks | VALID | - | 0 | 2.147 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9faa1bcde40b), strategy S0, run 849fffb3-750a-4f36-850e-1a7042d72d2a, engine 2.0.0.dev1._
