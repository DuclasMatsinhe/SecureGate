## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.383 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.026 | 0 |
| gitleaks | VALID | - | 0 | 2.125 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ef745f6747ee), strategy S3, run 06abe22b-6feb-43d0-8fc7-612563801710, engine 2.0.0.dev1._
