## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.367 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.025 | 0 |
| gitleaks | VALID | - | 0 | 2.135 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 68ede9439d56), strategy S3, run 86cd9505-1780-40cd-89fe-df776b39ce89, engine 2.0.0.dev1._
