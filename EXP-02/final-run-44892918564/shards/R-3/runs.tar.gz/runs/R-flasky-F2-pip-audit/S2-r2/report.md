## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.368 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.026 | 0 |
| gitleaks | VALID | - | 0 | 0.368 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b018de1a065e), strategy S2, run be5adf9f-e580-445f-9f30-5df9f99fcc29, engine 2.0.0.dev1._
