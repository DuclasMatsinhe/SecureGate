## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.4 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.025 | 0 |
| gitleaks | VALID | - | 0 | 0.386 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9faa1bcde40b), strategy S0, run f0f5c197-4069-4801-a200-7a47bf1d8457, engine 2.0.0.dev1._
