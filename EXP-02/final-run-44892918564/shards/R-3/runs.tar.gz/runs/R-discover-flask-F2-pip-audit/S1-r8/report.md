## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.37 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.383 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1cfc6b9c02dc), strategy S1, run 86b61ca5-f825-49a5-b058-2727b7459980, engine 2.0.0.dev1._
