## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.393 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.367 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9faa1bcde40b), strategy S0, run 237dcaa5-2875-492d-ac80-2f34aca7163c, engine 2.0.0.dev1._
