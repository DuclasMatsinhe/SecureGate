## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.626 | 0 |
| pip-audit | VALID | - | 0 | 0.463 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 96f62354587c), strategy S0, run 195f7249-a1ef-4ffb-a2ef-266221fe3b56, engine 2.0.0.dev1._
