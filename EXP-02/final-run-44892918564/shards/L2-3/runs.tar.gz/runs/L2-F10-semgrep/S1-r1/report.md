## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.646 | 0 |
| pip-audit | VALID | - | 0 | 0.464 | 0 |
| gitleaks | VALID | - | 0 | 0.45 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4c19457b15ef), strategy S1, run cbc1915a-fd42-4b0b-9fa3-4362ea9210bb, engine 2.0.0.dev1._
