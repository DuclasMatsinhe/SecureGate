## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.646 | 0 |
| pip-audit | VALID | - | 0 | 0.466 | 0 |
| gitleaks | VALID | - | 0 | 0.455 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2d6c839974cb), strategy S3, run 3ba713cb-e1f8-4439-8d0a-33c99cbcc9fc, engine 2.0.0.dev1._
