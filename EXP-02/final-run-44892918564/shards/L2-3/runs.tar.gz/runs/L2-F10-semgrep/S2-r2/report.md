## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.622 | 0 |
| pip-audit | VALID | - | 0 | 0.478 | 0 |
| gitleaks | VALID | - | 0 | 0.458 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d79ce19b6e2), strategy S2, run 3b1fa0ba-9462-4535-a44b-ec166f847578, engine 2.0.0.dev1._
