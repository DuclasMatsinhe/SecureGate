## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.654 | 0 |
| pip-audit | VALID | - | 0 | 0.466 | 0 |
| gitleaks | VALID | - | 0 | 0.442 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 21cfa52dfc3b), strategy S3, run 4da2b350-1110-4f0e-bd95-7dc3a7f8b710, engine 2.0.0.dev1._
