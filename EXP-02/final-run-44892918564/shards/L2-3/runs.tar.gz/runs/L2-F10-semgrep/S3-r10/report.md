## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.634 | 0 |
| pip-audit | VALID | - | 0 | 0.465 | 0 |
| gitleaks | VALID | - | 0 | 0.44 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 21cfa52dfc3b), strategy S3, run e6642f65-e23b-4d3e-a901-5fd750af01aa, engine 2.0.0.dev1._
