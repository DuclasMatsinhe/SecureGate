## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.637 | 0 |
| pip-audit | VALID | - | 0 | 0.47 | 0 |
| gitleaks | VALID | - | 0 | 0.451 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d79ce19b6e2), strategy S2, run 17aea156-b37a-4a4a-b63e-3e9f76f16e81, engine 2.0.0.dev1._
