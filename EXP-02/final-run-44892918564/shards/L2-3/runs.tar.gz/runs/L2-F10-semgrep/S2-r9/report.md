## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.65 | 0 |
| pip-audit | VALID | - | 0 | 0.468 | 0 |
| gitleaks | VALID | - | 0 | 0.445 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d79ce19b6e2), strategy S2, run 4469ba96-976f-40ef-9b0e-fe970bfb74c2, engine 2.0.0.dev1._
