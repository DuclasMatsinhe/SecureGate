## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.63 | 0 |
| pip-audit | VALID | - | 0 | 0.467 | 0 |
| gitleaks | VALID | - | 0 | 0.455 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 96f62354587c), strategy S0, run 3c5c1f42-d28c-41aa-85bb-13dbfdb6820b, engine 2.0.0.dev1._
