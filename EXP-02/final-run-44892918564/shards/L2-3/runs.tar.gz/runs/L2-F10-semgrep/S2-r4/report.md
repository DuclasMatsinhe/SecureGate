## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.661 | 0 |
| pip-audit | VALID | - | 0 | 0.468 | 0 |
| gitleaks | VALID | - | 0 | 0.453 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d79ce19b6e2), strategy S2, run 2900bf40-6acc-47de-b571-0e356759577e, engine 2.0.0.dev1._
