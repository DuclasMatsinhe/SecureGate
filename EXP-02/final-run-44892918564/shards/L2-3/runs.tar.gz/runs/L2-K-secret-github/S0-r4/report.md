## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.648 | 0 |
| pip-audit | VALID | - | 0 | 0.469 | 0 |
| gitleaks | VALID | - | 3 | 0.448 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 820698458558), strategy S0, run 65ae09c4-fdce-464b-8e1a-eae5d3daf4a5, engine 2.0.0.dev1._
