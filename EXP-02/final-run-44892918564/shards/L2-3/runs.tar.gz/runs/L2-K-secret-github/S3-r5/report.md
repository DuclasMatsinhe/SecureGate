## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.618 | 0 |
| pip-audit | VALID | - | 0 | 0.46 | 0 |
| gitleaks | VALID | - | 3 | 0.442 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 df2f3d7aca62), strategy S3, run 09e34c39-f778-4dbb-a5dc-4e7c3dc6d28d, engine 2.0.0.dev1._
