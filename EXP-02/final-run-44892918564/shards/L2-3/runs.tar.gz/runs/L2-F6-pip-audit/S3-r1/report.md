## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.628 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.511 | 0 |
| gitleaks | VALID | - | 0 | 0.461 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8c09c4685aad), strategy S3, run 38d98f2f-1228-4d0b-a5c3-a5abc7d9929e, engine 2.0.0.dev1._
