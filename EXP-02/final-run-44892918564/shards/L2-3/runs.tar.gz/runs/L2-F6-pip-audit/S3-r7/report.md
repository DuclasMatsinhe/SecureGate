## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.659 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.496 | 0 |
| gitleaks | VALID | - | 0 | 0.444 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8c09c4685aad), strategy S3, run 1ccb43ce-8d70-474a-9308-d07ff3d04f06, engine 2.0.0.dev1._
