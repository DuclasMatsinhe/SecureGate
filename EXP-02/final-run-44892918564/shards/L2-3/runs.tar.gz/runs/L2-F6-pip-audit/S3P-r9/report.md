## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.626 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.493 | 0 |
| gitleaks | VALID | - | 0 | 0.447 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ddb7041d6ee2), strategy S3, run 2d6e38b2-61a1-4b10-bc9c-343dbb023d71, engine 2.0.0.dev1._
