## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.62 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.498 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ddb7041d6ee2), strategy S3, run 969c0d0b-78fa-46e3-8f52-c3ddbb514fdf, engine 2.0.0.dev1._
