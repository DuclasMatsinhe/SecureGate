## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.614 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.49 | 0 |
| gitleaks | VALID | - | 0 | 0.442 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 37be50162b22), strategy S1, run 5f57f545-ffbe-4933-b280-113f4febc026, engine 2.0.0.dev1._
