## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.605 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.498 | 0 |
| gitleaks | VALID | - | 0 | 0.448 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8c09c4685aad), strategy S3, run 75245db5-b8d8-4a8a-8386-83ca31e5eeea, engine 2.0.0.dev1._
