## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.67 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.496 | 0 |
| gitleaks | VALID | - | 0 | 0.448 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 db11f874b19c), strategy S2, run f6c0cc38-130b-43e1-86e1-1bae6a116594, engine 2.0.0.dev1._
