## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_exp02_bcdhxemh/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.631 | 0 |
| pip-audit | VALID | - | 0 | 0.467 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 00a54f904949), strategy S0, run 88c4bcca-1d76-4d48-aaf0-dcc22418d704, engine 2.0.0.dev1._
