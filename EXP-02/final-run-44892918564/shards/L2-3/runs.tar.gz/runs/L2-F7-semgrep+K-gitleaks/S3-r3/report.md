## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 669)
- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.661 | 0 |
| pip-audit | VALID | - | 0 | 0.467 | 0 |
| gitleaks | VALID | - | 3 | 0.453 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 9474c6005af0), strategy S3, run 0ec29f6d-e944-4a88-8b86-1050211d2bea, engine 2.0.0.dev1._
