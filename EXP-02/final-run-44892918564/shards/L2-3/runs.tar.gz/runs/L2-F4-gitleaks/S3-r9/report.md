## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.604 | 0 |
| pip-audit | VALID | - | 0 | 0.46 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.029 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1af20b0da695), strategy S3, run 04a2400b-5d4b-4c5d-ba1e-ef892214af56, engine 2.0.0.dev1._
