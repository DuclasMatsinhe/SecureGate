## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.622 | 0 |
| pip-audit | VALID | - | 0 | 0.47 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1af20b0da695), strategy S3, run 2614a744-0bd2-4232-a7ae-c2f07b300b44, engine 2.0.0.dev1._
