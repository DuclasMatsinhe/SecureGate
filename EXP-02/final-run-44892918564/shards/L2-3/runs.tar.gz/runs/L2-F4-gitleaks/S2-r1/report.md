## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.618 | 0 |
| pip-audit | VALID | - | 0 | 0.462 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f53d0b9c411e), strategy S2, run af020292-72f3-4fe5-8382-f3e84f9c44a3, engine 2.0.0.dev1._
