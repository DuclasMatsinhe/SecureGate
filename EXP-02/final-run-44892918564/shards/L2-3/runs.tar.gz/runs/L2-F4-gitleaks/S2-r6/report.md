## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.631 | 0 |
| pip-audit | VALID | - | 0 | 0.469 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f53d0b9c411e), strategy S2, run 3f435326-5829-4a57-8540-184c61fa15ad, engine 2.0.0.dev1._
