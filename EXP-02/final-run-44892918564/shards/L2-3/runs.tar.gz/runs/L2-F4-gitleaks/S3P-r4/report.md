## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.64 | 0 |
| pip-audit | VALID | - | 0 | 0.466 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 87a7ce132632), strategy S3, run e168a852-a81b-450c-9df9-5581e4a84415, engine 2.0.0.dev1._
