## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.608 | 0 |
| pip-audit | VALID | - | 0 | 0.462 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.029 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1af20b0da695), strategy S3, run 872e3b66-47d2-4d12-8eed-406c373899a3, engine 2.0.0.dev1._
