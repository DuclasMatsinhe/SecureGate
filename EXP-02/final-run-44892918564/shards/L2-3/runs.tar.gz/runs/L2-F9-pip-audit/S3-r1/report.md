## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.6 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.506 | 0 |
| gitleaks | VALID | - | 0 | 0.44 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 df2f3d7aca62), strategy S3, run 59850e62-7a62-4a83-a95a-32ce27703637, engine 2.0.0.dev1._
