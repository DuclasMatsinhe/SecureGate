## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.592 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.511 | 0 |
| gitleaks | VALID | - | 0 | 0.449 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0ac915e94261), strategy S2, run aa8df5c5-ab14-4ce1-a2f2-e16273051dbe, engine 2.0.0.dev1._
