## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.599 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.509 | 0 |
| gitleaks | VALID | - | 0 | 0.458 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c7bd614f2419), strategy S3, run fba93f8c-7fca-4b44-9795-0b850526ee68, engine 2.0.0.dev1._
