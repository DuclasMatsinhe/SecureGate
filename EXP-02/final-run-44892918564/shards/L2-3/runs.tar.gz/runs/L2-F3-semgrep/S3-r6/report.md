## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.004 | 0 |
| pip-audit | VALID | - | 0 | 0.469 | 0 |
| gitleaks | VALID | - | 0 | 0.453 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 11efeb49c0ca), strategy S3, run 4959c281-bab6-4abe-8435-ed4eb827be72, engine 2.0.0.dev1._
