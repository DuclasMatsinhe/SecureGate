## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.002 | 0 |
| pip-audit | VALID | - | 0 | 0.474 | 0 |
| gitleaks | VALID | - | 0 | 0.443 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 78bdc6055274), strategy S3, run a462ad70-8a36-481d-b30f-32f20a0a0a4c, engine 2.0.0.dev1._
