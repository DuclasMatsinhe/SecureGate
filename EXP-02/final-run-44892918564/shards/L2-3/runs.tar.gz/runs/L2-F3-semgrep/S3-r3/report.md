## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 0.466 | 0 |
| gitleaks | VALID | - | 0 | 0.446 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 11efeb49c0ca), strategy S3, run 757c8950-409b-43f6-af6d-e4a07ab43099, engine 2.0.0.dev1._
