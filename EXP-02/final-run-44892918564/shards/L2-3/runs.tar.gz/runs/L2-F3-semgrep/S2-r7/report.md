## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.004 | 0 |
| pip-audit | VALID | - | 0 | 0.47 | 0 |
| gitleaks | VALID | - | 0 | 0.446 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 919d44473ea4), strategy S2, run 266bf151-3ddb-473a-b4af-d0a87c539d82, engine 2.0.0.dev1._
