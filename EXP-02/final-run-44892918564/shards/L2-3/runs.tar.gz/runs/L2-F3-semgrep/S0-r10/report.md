## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.004 | 0 |
| pip-audit | VALID | - | 0 | 0.462 | 0 |
| gitleaks | VALID | - | 0 | 0.441 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fb1c3b5a69d6), strategy S0, run ff446d96-b1a8-44dd-a601-273cc8305e7c, engine 2.0.0.dev1._
