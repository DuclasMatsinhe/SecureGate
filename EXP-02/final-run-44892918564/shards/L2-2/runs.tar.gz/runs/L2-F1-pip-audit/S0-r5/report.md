## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_exp02_r3ms4gso/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.389 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.349 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 322971916f96), strategy S0, run 99d47c8b-20e5-4d6b-8f6c-9b7bbc5c68aa, engine 2.0.0.dev1._
