## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_exp02_r3ms4gso/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.389 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.359 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f9e0cb4694e5), strategy S1, run c3c6dbd0-1f86-42d6-a1d8-476154a8a92e, engine 2.0.0.dev1._
