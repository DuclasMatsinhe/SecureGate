## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.458 | 0 |
| pip-audit | VALID | - | 0 | 0.399 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.026 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 30b4e70a477f), strategy S1, run dc284056-a090-4ad4-8617-9f924b11cd59, engine 2.0.0.dev1._
