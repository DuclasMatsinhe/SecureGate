## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.417 | 0 |
| pip-audit | VALID | - | 0 | 0.389 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.026 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 337d5cf312ec), strategy S3, run 2ddf81cc-9c85-4415-be7f-8211c1722570, engine 2.0.0.dev1._
