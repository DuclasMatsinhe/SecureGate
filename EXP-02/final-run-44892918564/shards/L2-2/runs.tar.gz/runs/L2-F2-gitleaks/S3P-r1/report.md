## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.535 | 0 |
| pip-audit | VALID | - | 0 | 0.403 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.033 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 337d5cf312ec), strategy S3, run 21a8acd6-fa7d-44c2-810e-70ab844df79b, engine 2.0.0.dev1._
