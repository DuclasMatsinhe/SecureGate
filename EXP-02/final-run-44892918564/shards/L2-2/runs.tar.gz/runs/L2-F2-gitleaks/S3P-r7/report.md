## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.406 | 0 |
| pip-audit | VALID | - | 0 | 0.397 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.027 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 337d5cf312ec), strategy S3, run e5d8f2be-dc4b-4deb-8716-33cc176c0bd6, engine 2.0.0.dev1._
