## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.454 | 0 |
| pip-audit | VALID | - | 0 | 0.399 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.027 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 658305003707), strategy S0, run b0469d47-4325-41ac-af9f-0d2f46325916, engine 2.0.0.dev1._
