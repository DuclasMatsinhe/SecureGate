## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.486 | 0 |
| pip-audit | VALID | - | 0 | 0.399 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.026 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ea97ecdb5995), strategy S2, run bc5c1804-34dd-481b-8d12-a02665444292, engine 2.0.0.dev1._
