## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.418 | 0 |
| pip-audit | VALID | - | 0 | 0.389 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.025 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6bd2518bfcfc), strategy S3, run 71a57ccf-d323-419e-a083-1296d48f3f9a, engine 2.0.0.dev1._
