## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.446 | 0 |
| pip-audit | VALID | - | 0 | 0.389 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.025 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 658305003707), strategy S0, run cfa597f3-078b-43c7-8a77-3b0a90e00fba, engine 2.0.0.dev1._
