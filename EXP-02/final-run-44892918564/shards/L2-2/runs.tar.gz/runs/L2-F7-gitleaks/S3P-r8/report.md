## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.473 | 0 |
| pip-audit | VALID | - | 0 | 0.401 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.38 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 50c4595d4c00), strategy S3, run ce156fb1-e54a-40a6-a025-c4c62a46a653, engine 2.0.0.dev1._
