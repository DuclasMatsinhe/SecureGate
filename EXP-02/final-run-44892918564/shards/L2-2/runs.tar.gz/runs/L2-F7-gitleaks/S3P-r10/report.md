## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.483 | 0 |
| pip-audit | VALID | - | 0 | 0.398 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.379 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 50c4595d4c00), strategy S3, run b3e2cb3d-3aa5-4781-8eef-2c40b5761495, engine 2.0.0.dev1._
