## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.506 | 0 |
| pip-audit | VALID | - | 0 | 0.414 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.381 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7caf752aad4), strategy S2, run 678a2b80-ec50-4c68-b970-f99d915fc281, engine 2.0.0.dev1._
