## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.47 | 0 |
| pip-audit | VALID | - | 0 | 0.397 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.385 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7caf752aad4), strategy S2, run bbc39e64-d2d6-44f8-bebf-226c8a249059, engine 2.0.0.dev1._
