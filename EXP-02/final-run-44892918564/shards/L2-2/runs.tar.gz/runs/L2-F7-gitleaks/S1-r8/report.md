## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.409 | 0 |
| pip-audit | VALID | - | 0 | 0.386 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.375 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e8a74e8cb43b), strategy S1, run a4c23dab-1333-494c-9044-fb14c26cfeac, engine 2.0.0.dev1._
