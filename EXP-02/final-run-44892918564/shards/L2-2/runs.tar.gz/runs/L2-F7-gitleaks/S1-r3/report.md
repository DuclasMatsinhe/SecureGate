## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.439 | 0 |
| pip-audit | VALID | - | 0 | 0.385 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.378 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e8a74e8cb43b), strategy S1, run be508009-49ae-4442-9f88-7d726e2cd546, engine 2.0.0.dev1._
