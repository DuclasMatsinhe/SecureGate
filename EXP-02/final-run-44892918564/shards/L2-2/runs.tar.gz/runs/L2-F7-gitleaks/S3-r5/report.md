## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.536 | 0 |
| pip-audit | VALID | - | 0 | 0.413 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.382 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d71ac82492e8), strategy S3, run 0410a08a-32e0-461b-b00b-81ce7b2d41fb, engine 2.0.0.dev1._
