## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.508 | 0 |
| pip-audit | VALID | - | 0 | 0.395 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.377 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7caf752aad4), strategy S2, run b344c188-9eb4-432f-af2c-a08414bd671f, engine 2.0.0.dev1._
