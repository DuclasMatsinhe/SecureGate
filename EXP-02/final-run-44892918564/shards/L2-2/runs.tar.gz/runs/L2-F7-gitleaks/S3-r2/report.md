## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.568 | 0 |
| pip-audit | VALID | - | 0 | 0.416 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.388 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d71ac82492e8), strategy S3, run 25bbe365-dfa7-40d4-bd9b-767a0ffa3080, engine 2.0.0.dev1._
