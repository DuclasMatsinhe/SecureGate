## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.509 | 0 |
| pip-audit | VALID | - | 0 | 0.408 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.387 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d71ac82492e8), strategy S3, run 10ba4a26-e276-4501-acfb-4a2a76ba404e, engine 2.0.0.dev1._
