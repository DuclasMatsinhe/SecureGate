## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.539 | 0 |
| pip-audit | VALID | - | 0 | 0.415 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.384 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d71ac82492e8), strategy S3, run 92cece32-8029-4ba6-90a6-f5ce498df209, engine 2.0.0.dev1._
