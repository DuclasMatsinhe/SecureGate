## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.401 | 0 |
| pip-audit | VALID | - | 0 | 0.393 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.375 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e8a74e8cb43b), strategy S1, run 40c1c95b-b248-42b5-8cc1-644e5f8923f2, engine 2.0.0.dev1._
