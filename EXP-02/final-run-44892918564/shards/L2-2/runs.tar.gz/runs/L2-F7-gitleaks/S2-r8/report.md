## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.543 | 0 |
| pip-audit | VALID | - | 0 | 0.405 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.386 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7caf752aad4), strategy S2, run b49d4bc5-e423-4151-9dd9-bec7746a3322, engine 2.0.0.dev1._
