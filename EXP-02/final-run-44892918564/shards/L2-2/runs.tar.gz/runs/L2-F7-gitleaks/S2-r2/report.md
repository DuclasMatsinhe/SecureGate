## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.574 | 0 |
| pip-audit | VALID | - | 0 | 0.393 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.38 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7caf752aad4), strategy S2, run ee112339-9eb0-4671-afbb-2a9b00598a7d, engine 2.0.0.dev1._
