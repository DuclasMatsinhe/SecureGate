## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.405 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| gitleaks | VALID | - | 0 | 0.35 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c17787ccb41d), strategy S3, run 24abe508-2e27-427f-bc06-65c12041f88c, engine 2.0.0.dev1._
