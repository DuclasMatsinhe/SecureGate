## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.542 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| gitleaks | VALID | - | 0 | 0.365 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1a80b4081490), strategy S2, run 8274e02a-3fc5-4ccd-921a-9640a9e04011, engine 2.0.0.dev1._
