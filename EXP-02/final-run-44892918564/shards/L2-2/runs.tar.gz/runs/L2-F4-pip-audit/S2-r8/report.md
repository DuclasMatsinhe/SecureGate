## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.537 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1a80b4081490), strategy S2, run f068423f-3c9e-46eb-80bd-5ee06b81fc53, engine 2.0.0.dev1._
