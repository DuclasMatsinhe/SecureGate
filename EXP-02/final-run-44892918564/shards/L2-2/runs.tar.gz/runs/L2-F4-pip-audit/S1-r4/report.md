## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.524 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| gitleaks | VALID | - | 0 | 0.4 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 de24a22c0396), strategy S1, run 7527f957-2d85-454b-8b2d-374f04a39d74, engine 2.0.0.dev1._
