## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.499 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.025 | 0 |
| gitleaks | VALID | - | 0 | 0.349 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 de24a22c0396), strategy S1, run bbf44e9c-3134-42a6-9b1f-02dc7351d2ae, engine 2.0.0.dev1._
