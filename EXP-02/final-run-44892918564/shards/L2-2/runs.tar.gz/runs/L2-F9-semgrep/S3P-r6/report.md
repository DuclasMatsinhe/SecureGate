## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (broken.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.343 | 0 |
| pip-audit | VALID | - | 0 | 0.382 | 0 |
| gitleaks | VALID | - | 0 | 0.344 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b7fd2c4b4cb2), strategy S3, run b3dbbdaf-8ad0-4e0b-90c2-a300c8e7027b, engine 2.0.0.dev1._
