## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_r3ms4gso.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.485 | 1 |
| pip-audit | VALID | - | 0 | 0.395 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.003 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_r3ms4gso.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 84eb00cd49c7), strategy S2, run ab585547-7164-4a53-95a6-ccf03e05e85d, engine 2.0.0.dev1._
