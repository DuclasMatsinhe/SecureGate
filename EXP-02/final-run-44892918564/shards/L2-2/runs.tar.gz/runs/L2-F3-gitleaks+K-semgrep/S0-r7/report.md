## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_r3ms4gso.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.434 | 1 |
| pip-audit | VALID | - | 0 | 0.409 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_r3ms4gso.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 33a1069875d7), strategy S0, run fb6d0896-371c-450b-9eb5-e1766bc83bf5, engine 2.0.0.dev1._
