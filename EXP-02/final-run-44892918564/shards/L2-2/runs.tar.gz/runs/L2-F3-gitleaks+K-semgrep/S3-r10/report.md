## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_r3ms4gso.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.464 | 1 |
| pip-audit | VALID | - | 0 | 0.394 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_r3ms4gso.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 c4fb1afd7da2), strategy S3, run f42123d2-8a3e-492e-8ff4-315ac579057b, engine 2.0.0.dev1._
