## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.551 | 0 |
| pip-audit | VALID | - | 0 | 0.4 | 0 |
| gitleaks | VALID | - | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9122c97431a5), strategy S2, run 6f85cf02-37b2-4ac5-85aa-6eaa03b0427c, engine 2.0.0.dev1._
