## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.464 | 0 |
| pip-audit | VALID | - | 0 | 0.389 | 0 |
| gitleaks | VALID | - | 0 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9122c97431a5), strategy S2, run 279ba278-9c06-4a42-997c-8fe92d90af9c, engine 2.0.0.dev1._
