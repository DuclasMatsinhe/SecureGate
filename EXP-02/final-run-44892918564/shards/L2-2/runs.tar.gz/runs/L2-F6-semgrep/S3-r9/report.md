## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.45 | 0 |
| pip-audit | VALID | - | 0 | 0.397 | 0 |
| gitleaks | VALID | - | 0 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 76c36124f8b1), strategy S3, run 13f1da79-8ddc-48e9-ac74-4a05963771ea, engine 2.0.0.dev1._
