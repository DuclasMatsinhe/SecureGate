## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 1.535 | 0 |
| pip-audit | VALID | - | 0 | 0.437 | 0 |
| gitleaks | VALID | - | 0 | 0.371 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 76c36124f8b1), strategy S3, run 3b8ea0ac-6dfb-4b8b-938d-7f646deb6374, engine 2.0.0.dev1._
