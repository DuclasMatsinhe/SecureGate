## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.513 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |
| gitleaks | VALID | - | 0 | 0.464 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6d231dd7e317), strategy S3, run 52cd6e40-d6c1-4484-aa4b-c19f3693b5a0, engine 2.0.0.dev1._
