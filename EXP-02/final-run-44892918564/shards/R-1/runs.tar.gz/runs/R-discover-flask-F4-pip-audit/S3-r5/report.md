## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.528 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.471 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6d231dd7e317), strategy S3, run df91eab7-674e-4a29-ab3f-f96ec0854a50, engine 2.0.0.dev1._
