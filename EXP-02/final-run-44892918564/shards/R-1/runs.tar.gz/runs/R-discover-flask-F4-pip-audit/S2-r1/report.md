## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.549 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.469 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b5040d1d6091), strategy S2, run d06c7beb-1abd-4c3b-960e-f0f0869c637d, engine 2.0.0.dev1._
