## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.533 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.441 | 0 |
| gitleaks | VALID | - | 0 | 0.461 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 517a2e7e0a59), strategy S3, run 77ae285b-8a1f-4dc1-8a06-9b79920b30c5, engine 2.0.0.dev1._
