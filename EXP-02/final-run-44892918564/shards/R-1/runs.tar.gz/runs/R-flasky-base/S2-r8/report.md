## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.545 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.436 | 0 |
| gitleaks | VALID | - | 0 | 0.457 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c7b56091fe09), strategy S2, run 1ffc8c73-b321-4703-b8c3-d2415becf819, engine 2.0.0.dev1._
