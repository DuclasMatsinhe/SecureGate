## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.534 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.444 | 0 |
| gitleaks | VALID | - | 0 | 0.456 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c7b56091fe09), strategy S2, run 4f25e3e1-18a4-4238-a0b7-611438a9513d, engine 2.0.0.dev1._
