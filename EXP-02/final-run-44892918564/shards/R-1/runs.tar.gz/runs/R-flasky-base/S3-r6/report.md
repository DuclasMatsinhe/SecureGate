## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.545 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.437 | 0 |
| gitleaks | VALID | - | 0 | 0.463 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fc9fb81a07c1), strategy S3, run 2c76f7be-7602-44e4-ae70-c9defa36ea2f, engine 2.0.0.dev1._
