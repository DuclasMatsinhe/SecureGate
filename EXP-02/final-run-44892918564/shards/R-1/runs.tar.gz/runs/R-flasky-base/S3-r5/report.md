## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.543 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.45 | 0 |
| gitleaks | VALID | - | 0 | 0.46 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fc9fb81a07c1), strategy S3, run 5dd1ca03-3ddd-4bb3-a823-bd4ca2e06db3, engine 2.0.0.dev1._
