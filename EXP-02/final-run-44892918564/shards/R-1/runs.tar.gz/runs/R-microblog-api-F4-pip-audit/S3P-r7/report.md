## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.542 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.474 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 973d23fb08cd), strategy S3, run 4b0d8614-c579-4c45-9529-6d836b84e6a8, engine 2.0.0.dev1._
