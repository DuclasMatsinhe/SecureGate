## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.533 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |
| gitleaks | VALID | - | 0 | 2.527 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7ef87efb2b5a), strategy S1, run 9f2e3c4c-2569-4320-8747-4e71d056fe7a, engine 2.0.0.dev1._
