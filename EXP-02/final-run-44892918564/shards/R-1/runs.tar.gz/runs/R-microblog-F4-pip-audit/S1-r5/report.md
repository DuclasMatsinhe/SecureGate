## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.519 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.462 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7ef87efb2b5a), strategy S1, run c750dc5b-40da-48a0-9fa0-4b6f62ab20c2, engine 2.0.0.dev1._
