## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.535 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |
| gitleaks | VALID | - | 0 | 0.467 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b5040d1d6091), strategy S2, run 3acaf8b8-41f3-4d80-8560-299a4d958ad5, engine 2.0.0.dev1._
