## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.253 | 0 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ee415492864b), strategy S1, run ab1519aa-8a00-418f-8ea7-50c004b78689, engine 2.0.0.dev1._
