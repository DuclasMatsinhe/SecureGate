## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.242 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.356 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 800592c64363), strategy S3, run 98d143db-374c-4f87-a534-2e2225be839f, engine 2.0.0.dev1._
