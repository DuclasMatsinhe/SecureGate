## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.24 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ee415492864b), strategy S1, run 7dca3960-3ac2-40e7-b35c-81e7886956ed, engine 2.0.0.dev1._
