## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.24 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.354 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ae3d323fe62c), strategy S3, run bc791bc9-c5e2-436e-8b1f-85bb019892e7, engine 2.0.0.dev1._
