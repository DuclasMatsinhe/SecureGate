## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.232 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.347 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ed750677055a), strategy S2, run 50d91de5-3685-470c-8620-ebb782cb3d53, engine 2.0.0.dev1._
