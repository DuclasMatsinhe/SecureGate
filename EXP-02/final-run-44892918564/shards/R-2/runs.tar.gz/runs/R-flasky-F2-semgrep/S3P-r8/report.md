## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.355 | 0 |
| gitleaks | VALID | - | 0 | 0.361 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 711ef4e8d740), strategy S3, run 02a11ed5-5b57-4d54-9356-ea4799a702c1, engine 2.0.0.dev1._
