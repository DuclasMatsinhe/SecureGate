## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | VALID | - | 0 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a4e488be8c40), strategy S1, run 48658a6e-e314-4de9-9462-12d991348c33, engine 2.0.0.dev1._
