## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.025 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.38 | 0 |
| gitleaks | VALID | - | 0 | 0.378 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4d8d60d904b8), strategy S2, run dca10ad3-ae14-4285-b541-d4ed1d51abcb, engine 2.0.0.dev1._
