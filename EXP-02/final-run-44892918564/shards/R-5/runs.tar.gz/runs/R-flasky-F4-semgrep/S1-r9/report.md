## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| pip-audit | VALID | - | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.371 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 787e65cb8094), strategy S1, run 94e1ef79-de66-4e15-a15a-f10ade8cfcf0, engine 2.0.0.dev1._
