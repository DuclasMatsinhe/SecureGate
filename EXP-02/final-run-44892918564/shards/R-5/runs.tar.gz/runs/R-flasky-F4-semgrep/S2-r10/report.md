## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.38 | 0 |
| gitleaks | VALID | - | 0 | 0.373 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4d8d60d904b8), strategy S2, run 855cf86c-1292-4710-91e8-28d833f569b3, engine 2.0.0.dev1._
