## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.382 | 0 |
| gitleaks | VALID | - | 0 | 0.371 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2181d0e6531e), strategy S3, run d5e65a04-8bb9-4f47-866c-47c42dc2e88e, engine 2.0.0.dev1._
