## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.024 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.383 | 0 |
| gitleaks | VALID | - | 0 | 0.371 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 11c34e411b0d), strategy S3, run cc686ab7-97f6-48cf-926c-7e141282c0fc, engine 2.0.0.dev1._
