## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.025 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.386 | 0 |
| gitleaks | VALID | - | 0 | 0.385 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 11c34e411b0d), strategy S3, run c229af62-e87a-49f9-a558-60fd2160a0de, engine 2.0.0.dev1._
