## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.367 | 0 |
| pip-audit | VALID | - | 0 | 0.377 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.397 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4c9905ab5f1), strategy S1, run fb7fb444-5da5-4b57-aeb1-830af77c55fe, engine 2.0.0.dev1._
