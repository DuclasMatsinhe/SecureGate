## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.362 | 0 |
| pip-audit | VALID | - | 0 | 0.381 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.397 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4c9905ab5f1), strategy S1, run 3dd4e29c-955d-4474-8f47-5b8a869dd244, engine 2.0.0.dev1._
