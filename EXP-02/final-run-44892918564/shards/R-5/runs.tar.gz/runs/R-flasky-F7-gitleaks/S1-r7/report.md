## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.373 | 0 |
| pip-audit | VALID | - | 0 | 0.38 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.402 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4c9905ab5f1), strategy S1, run 0bbc470c-38c2-4362-af5c-785cb34f61a9, engine 2.0.0.dev1._
