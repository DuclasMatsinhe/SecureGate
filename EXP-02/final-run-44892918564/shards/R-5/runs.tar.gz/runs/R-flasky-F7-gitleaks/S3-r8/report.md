## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.367 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.376 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.402 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3d498730cd39), strategy S3, run 8c5eebb1-1768-4338-acc4-ad7335c9cb1f, engine 2.0.0.dev1._
