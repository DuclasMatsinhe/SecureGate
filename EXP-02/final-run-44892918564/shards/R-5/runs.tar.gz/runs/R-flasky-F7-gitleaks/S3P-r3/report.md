## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.395 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.386 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.402 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0773b96733ee), strategy S3, run 9c79e38b-bd73-4786-b0a4-199b332037db, engine 2.0.0.dev1._
