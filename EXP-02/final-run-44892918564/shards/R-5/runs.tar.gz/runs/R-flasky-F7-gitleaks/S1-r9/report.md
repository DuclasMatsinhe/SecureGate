## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.417 | 0 |
| pip-audit | VALID | - | 0 | 0.38 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.403 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4c9905ab5f1), strategy S1, run 652655f3-409b-4f61-96c1-4448eb61c461, engine 2.0.0.dev1._
