## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.37 | 0 |
| pip-audit | VALID | - | 0 | 0.384 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.402 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4c9905ab5f1), strategy S1, run 15035d0a-87c1-4f09-983d-f1e30cc49b66, engine 2.0.0.dev1._
