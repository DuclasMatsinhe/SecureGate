## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.363 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.382 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.401 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 83d1247f0d16), strategy S2, run ce0c6ff2-4c57-4bd0-b636-18c94f054379, engine 2.0.0.dev1._
