## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.372 | 0 |
| pip-audit | VALID | - | 0 | 0.385 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.398 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4c9905ab5f1), strategy S1, run d06515e0-2732-4509-985e-1fc68e0d31c5, engine 2.0.0.dev1._
