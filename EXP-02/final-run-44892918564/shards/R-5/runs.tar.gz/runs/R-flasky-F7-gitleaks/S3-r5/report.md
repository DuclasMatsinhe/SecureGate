## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.371 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.382 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.396 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3d498730cd39), strategy S3, run 66e889f7-6f4d-44ff-98de-86ced0d46c7b, engine 2.0.0.dev1._
