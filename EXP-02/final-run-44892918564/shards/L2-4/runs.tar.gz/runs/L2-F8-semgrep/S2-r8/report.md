## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.177 | 0 |
| pip-audit | VALID | - | 0 | 0.342 | 0 |
| gitleaks | VALID | - | 0 | 0.329 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c2d484e965aa), strategy S2, run 29b0302c-0979-4398-a075-7aa50766d164, engine 2.0.0.dev1._
