## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.193 | 0 |
| pip-audit | VALID | - | 0 | 0.346 | 0 |
| gitleaks | VALID | - | 0 | 0.325 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d1434303073c), strategy S3, run 8a6de379-6a7d-4db3-be94-50df23f7ef44, engine 2.0.0.dev1._
