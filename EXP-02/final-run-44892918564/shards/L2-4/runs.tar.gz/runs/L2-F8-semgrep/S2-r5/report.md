## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.183 | 0 |
| pip-audit | VALID | - | 0 | 0.339 | 0 |
| gitleaks | VALID | - | 0 | 0.327 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c2d484e965aa), strategy S2, run 2ddc353b-0cb3-43e6-8280-7dacfb77a579, engine 2.0.0.dev1._
