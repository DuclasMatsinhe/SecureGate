## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.209 | 0 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | VALID | - | 0 | 0.329 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d664774681f), strategy S3, run 80d0b721-8915-4aa5-81eb-cfd9f9a171f8, engine 2.0.0.dev1._
