## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.201 | 0 |
| pip-audit | VALID | - | 0 | 0.343 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d664774681f), strategy S3, run de3e61a4-e47f-49e3-8f2f-7b383708165d, engine 2.0.0.dev1._
