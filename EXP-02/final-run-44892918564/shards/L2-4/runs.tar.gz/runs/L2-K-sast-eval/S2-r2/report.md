## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_82iprqr4.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.236 | 1 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_82iprqr4.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 c2d484e965aa), strategy S2, run b5612cd6-ac91-454c-9f9c-52b5fe2626b6, engine 2.0.0.dev1._
