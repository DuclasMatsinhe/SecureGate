## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_82iprqr4.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.227 | 1 |
| pip-audit | VALID | - | 0 | 0.381 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_82iprqr4.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 b8ff6ada6a80), strategy S0, run 00c56671-cec8-461b-a476-6f1d84ae9756, engine 2.0.0.dev1._
