## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_82iprqr4.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.216 | 1 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_82iprqr4.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 c2d484e965aa), strategy S2, run e0616ff0-d2f2-4b32-af7a-fcc451c6fc7c, engine 2.0.0.dev1._
