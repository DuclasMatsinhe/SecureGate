## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: aws-access-token (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | VALID | - | 3 | 0.339 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | aws-access-token | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 b8ff6ada6a80), strategy S0, run 263ba562-5f04-470d-baf5-feb1bcaffd60, engine 2.0.0.dev1._
