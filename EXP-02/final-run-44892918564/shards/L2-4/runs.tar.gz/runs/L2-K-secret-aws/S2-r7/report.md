## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: aws-access-token (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.228 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | VALID | - | 3 | 0.336 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | aws-access-token | settings.py:1 | - |

_Policy policy.toml vEXP-02 v1 (sha256 c2d484e965aa), strategy S2, run b23de8d2-6ab0-4651-81ae-e6ad239a8974, engine 2.0.0.dev1._
