## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 10:31AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.243 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.22 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3877faed2e28), strategy S0, run 5e0dbfd0-3994-4e38-be5f-3cc84a87e1c3, engine 2.0.0.dev1._
