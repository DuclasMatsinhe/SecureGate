## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 10:34AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 10:34AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.259 | 0 |
| pip-audit | VALID | - | 0 | 0.357 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.224 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 af05c74759b8), strategy S3, run e396eea9-6587-4ae3-b6b3-598c72411f8f, engine 2.0.0.dev1._
