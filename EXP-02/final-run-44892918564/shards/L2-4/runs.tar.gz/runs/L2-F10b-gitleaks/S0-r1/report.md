## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 10:31AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.225 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.221 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 3877faed2e28), strategy S0, run 01d57c3a-3b2f-4b7c-8338-4e82dc8f05dd, engine 2.0.0.dev1._
