## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 10:33AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 10:33AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.254 | 0 |
| pip-audit | VALID | - | 0 | 0.362 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.22 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 692185ee5936), strategy S3, run 71deeb5a-2fdb-4211-af45-7d9c52840b17, engine 2.0.0.dev1._
