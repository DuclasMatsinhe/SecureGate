## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 10:32AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 10:32AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.241 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.224 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 12a3dd7fb6bd), strategy S1, run caf3177b-ad43-4cbe-ba23-4b6831e280ff, engine 2.0.0.dev1._
