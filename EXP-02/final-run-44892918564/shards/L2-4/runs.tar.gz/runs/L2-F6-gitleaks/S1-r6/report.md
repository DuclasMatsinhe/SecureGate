## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.199 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 256a3a644ba1), strategy S1, run 6a289574-92c4-4bb4-b66c-40168cf92d18, engine 2.0.0.dev1._
