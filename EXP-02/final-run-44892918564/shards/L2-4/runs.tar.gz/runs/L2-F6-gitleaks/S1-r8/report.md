## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.205 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.354 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 256a3a644ba1), strategy S1, run 93d4bf22-2d5a-4c06-a15e-36cd274938ee, engine 2.0.0.dev1._
