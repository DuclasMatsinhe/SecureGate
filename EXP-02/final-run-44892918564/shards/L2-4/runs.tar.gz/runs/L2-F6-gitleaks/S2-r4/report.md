## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.261 | 0 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.363 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9715a6fa9532), strategy S2, run 93c1ee93-3d95-4e09-9879-f7ae86faf91c, engine 2.0.0.dev1._
