## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.271 | 0 |
| pip-audit | VALID | - | 0 | 0.362 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f133cd89d516), strategy S3, run ac0c5e95-4b4b-409f-a485-67c977276eed, engine 2.0.0.dev1._
