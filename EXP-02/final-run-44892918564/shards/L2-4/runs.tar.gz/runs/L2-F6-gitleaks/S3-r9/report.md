## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.202 | 0 |
| pip-audit | VALID | - | 0 | 0.347 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f133cd89d516), strategy S3, run df951f35-6c6d-4992-b0a4-9935513b574f, engine 2.0.0.dev1._
