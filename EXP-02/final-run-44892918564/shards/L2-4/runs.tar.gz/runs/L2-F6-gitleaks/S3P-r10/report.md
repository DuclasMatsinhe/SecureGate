## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.249 | 0 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.361 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 73d9e0b4d6ba), strategy S3, run adf2118a-fd8d-42b2-a0a1-1c8ac0d7ee19, engine 2.0.0.dev1._
