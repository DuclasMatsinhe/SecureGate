## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 256a3a644ba1), strategy S1, run bfac4c98-edec-4be8-b57b-617010ecdb6b, engine 2.0.0.dev1._
