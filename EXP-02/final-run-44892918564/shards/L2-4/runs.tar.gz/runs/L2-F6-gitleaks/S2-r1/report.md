## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.253 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.355 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9715a6fa9532), strategy S2, run 1561644e-340a-4e33-b934-8a2ad18fafce, engine 2.0.0.dev1._
