## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.221 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 73d9e0b4d6ba), strategy S3, run 85243a7a-88ae-440e-9cb6-10bbb0c9557d, engine 2.0.0.dev1._
