## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.182 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.368 | 0 |
| gitleaks | VALID | - | 0 | 0.326 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 08d9c9b41766), strategy S3, run 34c23bd6-f607-4c50-b730-3ad67eb86ccb, engine 2.0.0.dev1._
