## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.243 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.38 | 0 |
| gitleaks | VALID | - | 0 | 0.328 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6d69839f1582), strategy S3, run 6b40fbb4-557f-470b-bede-6b17e935f9cc, engine 2.0.0.dev1._
