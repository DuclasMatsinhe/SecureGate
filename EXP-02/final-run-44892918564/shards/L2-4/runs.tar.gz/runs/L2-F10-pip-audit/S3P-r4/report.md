## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.172 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.36 | 0 |
| gitleaks | VALID | - | 0 | 0.327 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 08d9c9b41766), strategy S3, run 1a235a94-7767-41a3-b0b9-56807a113c45, engine 2.0.0.dev1._
