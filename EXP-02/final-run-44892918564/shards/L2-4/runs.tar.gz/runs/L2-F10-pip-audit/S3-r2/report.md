## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.191 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.372 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6d69839f1582), strategy S3, run f9dd9e72-1bec-4f41-ba97-c348f6c151fb, engine 2.0.0.dev1._
