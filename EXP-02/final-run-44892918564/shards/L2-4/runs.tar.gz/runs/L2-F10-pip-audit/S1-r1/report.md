## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.239 | 0 |
| pip-audit | VALID | - | 1 | 0.383 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cddaae8e9a46), strategy S1, run 55bc1102-2778-4632-a362-3fb9728191a1, engine 2.0.0.dev1._
