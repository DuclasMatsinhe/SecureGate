## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 1.252 | 0 |
| pip-audit | VALID | - | 0 | 0.346 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ae3ef9de038f), strategy S1, run 56fd2465-9f29-4b45-8e40-d17b2cb521d8, engine 2.0.0.dev1._
