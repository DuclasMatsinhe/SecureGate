## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 1.244 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0c1a49bf00be), strategy S3, run d62cc879-e8f2-4683-b0e6-5a2d7dd15b38, engine 2.0.0.dev1._
