## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_k59ct77e.probe-pickle-loads (app.py:5)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.244 | 1 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | VALID | - | 0 | 0.34 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_k59ct77e.probe-pickle-loads | app.py:5 | - |

_Policy policy.toml vEXP-02 v1 (sha256 80e770132c56), strategy S1, run b96d0964-1081-45ba-848d-1524981ecf59, engine 2.0.0.dev1._
