## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_k59ct77e.probe-pickle-loads (app.py:5)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.256 | 1 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_k59ct77e.probe-pickle-loads | app.py:5 | - |

_Policy policy.toml vEXP-02 v1 (sha256 539694bb349c), strategy S2, run ce315a76-6156-452a-834e-649fe26b2108, engine 2.0.0.dev1._
