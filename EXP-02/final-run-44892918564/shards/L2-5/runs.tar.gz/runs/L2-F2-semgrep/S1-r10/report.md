## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 68ee8c29601f), strategy S1, run be373c96-2c36-4e6f-b535-9ce3c5e0d7a6, engine 2.0.0.dev1._
