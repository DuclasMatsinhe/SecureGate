## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.255 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.375 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 86afe073567d), strategy S2, run ea4e6994-ba97-4cf5-a6d8-310fd1ec7e16, engine 2.0.0.dev1._
