## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.243 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.38 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e2472045811d), strategy S1, run a8f4b5c9-1143-4ca4-bcaa-4c20a572295e, engine 2.0.0.dev1._
