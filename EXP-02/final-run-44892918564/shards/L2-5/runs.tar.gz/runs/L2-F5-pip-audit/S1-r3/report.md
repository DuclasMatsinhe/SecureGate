## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.249 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.381 | 0 |
| gitleaks | VALID | - | 0 | 0.343 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e2472045811d), strategy S1, run bae977e5-9311-409c-8427-a7ce5d0e5983, engine 2.0.0.dev1._
