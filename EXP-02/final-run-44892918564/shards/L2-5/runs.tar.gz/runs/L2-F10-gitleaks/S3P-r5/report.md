## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.23 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b63d7989405a), strategy S3, run b705b650-2ce2-4289-a521-01fe65fb0b1e, engine 2.0.0.dev1._
