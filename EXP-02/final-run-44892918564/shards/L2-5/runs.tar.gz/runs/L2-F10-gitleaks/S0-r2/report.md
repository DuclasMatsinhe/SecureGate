## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.223 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | VALID | - | 3 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 10121436fd12), strategy S0, run bad62f32-559c-4d3f-a193-f6b87b18f8fa, engine 2.0.0.dev1._
