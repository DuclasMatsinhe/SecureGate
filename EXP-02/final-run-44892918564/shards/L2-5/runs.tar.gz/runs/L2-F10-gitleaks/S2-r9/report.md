## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.215 | 0 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c8741c79c9e4), strategy S2, run 961460e0-3d28-47b4-bf58-90470a66f0bd, engine 2.0.0.dev1._
