## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.201 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.355 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 600fda929b58), strategy S3, run 3194364c-0d25-4696-83bc-56d65317e347, engine 2.0.0.dev1._
