## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.188 | 0 |
| pip-audit | VALID | - | 0 | 0.346 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 600fda929b58), strategy S3, run 3c5c70d6-3a62-4e25-90f5-46e55e3ab7dd, engine 2.0.0.dev1._
