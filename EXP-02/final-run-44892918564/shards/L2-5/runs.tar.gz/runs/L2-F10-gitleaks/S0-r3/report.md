## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.225 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | VALID | - | 3 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 10121436fd12), strategy S0, run 7cfe5193-e625-4de8-8f9b-ca6131f6e85a, engine 2.0.0.dev1._
