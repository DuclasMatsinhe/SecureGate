## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.236 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 3 | 0.353 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 10121436fd12), strategy S0, run 0cfc0ff9-9826-4611-9f87-dd4048bc6cb7, engine 2.0.0.dev1._
