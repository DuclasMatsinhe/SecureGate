## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.262 | 0 |
| pip-audit | VALID | - | 0 | 0.362 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.329 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 539694bb349c), strategy S2, run a9ff6c01-0cca-4d8a-b448-19ad4306f65c, engine 2.0.0.dev1._
