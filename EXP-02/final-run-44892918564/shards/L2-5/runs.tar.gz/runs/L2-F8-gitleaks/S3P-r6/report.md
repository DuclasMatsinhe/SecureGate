## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.238 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.338 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c4f78421e5fa), strategy S3, run 791a6920-89d9-4d76-a768-3d6d0e07271f, engine 2.0.0.dev1._
