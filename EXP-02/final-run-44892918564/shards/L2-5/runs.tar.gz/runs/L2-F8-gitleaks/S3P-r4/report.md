## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.248 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.328 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c4f78421e5fa), strategy S3, run 9245d7b6-3390-4c5c-8488-b5734dc9425b, engine 2.0.0.dev1._
