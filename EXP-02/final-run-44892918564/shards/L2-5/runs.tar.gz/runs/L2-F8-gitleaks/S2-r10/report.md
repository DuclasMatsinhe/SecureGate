## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.241 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.335 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 539694bb349c), strategy S2, run 2ca19edb-4fdc-432d-b98b-99442df07141, engine 2.0.0.dev1._
