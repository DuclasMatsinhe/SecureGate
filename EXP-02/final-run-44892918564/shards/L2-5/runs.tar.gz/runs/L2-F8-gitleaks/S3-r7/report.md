## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.244 | 0 |
| pip-audit | VALID | - | 0 | 0.358 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.338 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4821151cfeed), strategy S3, run 8b83d2cd-8672-4fae-9ca4-32128909c805, engine 2.0.0.dev1._
