## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.25 | 0 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 276967356723), strategy S3, run 651e3c4e-eead-43db-9fce-01c656cf8608, engine 2.0.0.dev1._
