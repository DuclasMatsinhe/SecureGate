## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.184 | 0 |
| pip-audit | VALID | - | 0 | 0.34 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 edae5356bfc9), strategy S0, run e84d79b5-419d-4667-9f40-e299b37a2614, engine 2.0.0.dev1._
