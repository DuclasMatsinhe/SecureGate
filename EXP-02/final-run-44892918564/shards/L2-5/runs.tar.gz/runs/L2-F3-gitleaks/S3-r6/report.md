## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.223 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f4668a0e6b7b), strategy S3, run 99ec1a54-4afe-436a-93e7-a601f82d8521, engine 2.0.0.dev1._
