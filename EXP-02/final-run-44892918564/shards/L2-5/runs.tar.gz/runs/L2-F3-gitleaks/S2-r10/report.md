## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.223 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6a8e1e303c62), strategy S2, run 521dc713-e910-4414-8ee2-74d457b88603, engine 2.0.0.dev1._
