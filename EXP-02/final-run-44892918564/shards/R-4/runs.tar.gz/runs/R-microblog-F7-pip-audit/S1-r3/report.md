## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.693 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.563 | 0 |
| gitleaks | VALID | - | 0 | 0.48 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f008fc467a66), strategy S1, run 6543de0b-1d05-49ed-9068-428cf61f0541, engine 2.0.0.dev1._
