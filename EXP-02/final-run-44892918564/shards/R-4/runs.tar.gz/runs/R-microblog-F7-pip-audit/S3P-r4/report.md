## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.696 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.564 | 0 |
| gitleaks | VALID | - | 0 | 0.478 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run c718456c-2796-4dc6-9a3c-87afd8599a0c, engine 2.0.0.dev1._
