## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.703 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.577 | 0 |
| gitleaks | VALID | - | 0 | 0.475 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run b3c9f49f-d9ff-499d-943e-f8778d195779, engine 2.0.0.dev1._
