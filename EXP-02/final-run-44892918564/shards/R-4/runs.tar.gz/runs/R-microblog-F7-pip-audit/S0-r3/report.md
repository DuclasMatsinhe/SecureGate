## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.676 | 0 |
| pip-audit | VALID | - | 1 | 0.564 | 0 |
| gitleaks | VALID | - | 0 | 0.481 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 13d6257075fe), strategy S0, run 7d4c8e23-b215-466a-8646-58c0baa607a8, engine 2.0.0.dev1._
