## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.715 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.564 | 0 |
| gitleaks | VALID | - | 0 | 0.474 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f008fc467a66), strategy S1, run 3ce076ad-c486-4056-879c-e9f123993c09, engine 2.0.0.dev1._
