## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.681 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.557 | 0 |
| gitleaks | VALID | - | 0 | 2.894 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run ac0256e9-ca92-44a5-81f5-e6d74d074409, engine 2.0.0.dev1._
