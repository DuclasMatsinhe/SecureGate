## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.676 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.544 | 0 |
| gitleaks | VALID | - | 0 | 2.866 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a1bf1a0d0405), strategy S3, run 9b3250ee-b0a4-47e2-b06a-10dc64068eea, engine 2.0.0.dev1._
