## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.716 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.544 | 0 |
| gitleaks | VALID | - | 0 | 2.959 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a1bf1a0d0405), strategy S3, run ecd38328-41a6-45c7-b1b4-6338ffdcfc3d, engine 2.0.0.dev1._
