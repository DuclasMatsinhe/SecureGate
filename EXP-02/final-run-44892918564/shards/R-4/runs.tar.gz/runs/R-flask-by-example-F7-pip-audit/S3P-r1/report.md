## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 208659)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.68 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.542 | 0 |
| gitleaks | VALID | - | 0 | 2.874 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run ed329e33-5997-4abf-a1cc-ba37576b0796, engine 2.0.0.dev1._
