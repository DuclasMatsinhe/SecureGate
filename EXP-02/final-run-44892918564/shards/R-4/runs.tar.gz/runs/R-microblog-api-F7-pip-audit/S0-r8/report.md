## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.682 | 0 |
| pip-audit | VALID | - | 1 | 0.546 | 0 |
| gitleaks | VALID | - | 0 | 0.482 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 13d6257075fe), strategy S0, run 0136f128-bb79-490b-84fb-dbd638d91166, engine 2.0.0.dev1._
