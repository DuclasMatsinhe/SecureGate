## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 70831)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.705 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.545 | 0 |
| gitleaks | VALID | - | 0 | 0.495 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run d7c8922f-e894-4e5b-87fb-d87e282c05cf, engine 2.0.0.dev1._
