## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.673 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.476 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.038 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e19d66b50dc2), strategy S2, run e7593fdc-a72e-4ed6-b8de-b8594c2e4a49, engine 2.0.0.dev1._
