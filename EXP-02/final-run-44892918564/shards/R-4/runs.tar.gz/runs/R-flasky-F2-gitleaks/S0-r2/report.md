## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.706 | 0 |
| pip-audit | VALID | - | 0 | 0.473 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.029 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d47cc8588672), strategy S0, run 340f6d6c-62cb-434d-b28c-2091966b2073, engine 2.0.0.dev1._
