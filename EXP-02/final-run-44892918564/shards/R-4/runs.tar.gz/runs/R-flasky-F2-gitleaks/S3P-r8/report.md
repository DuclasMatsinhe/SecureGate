## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.686 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.472 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.029 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4ca117a0eb22), strategy S3, run b3bd5567-da49-4823-95b2-8e5fdb2788b2, engine 2.0.0.dev1._
