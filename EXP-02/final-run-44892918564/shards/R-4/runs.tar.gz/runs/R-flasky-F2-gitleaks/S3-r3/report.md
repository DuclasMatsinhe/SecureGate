## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.68 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.474 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c7febcb28128), strategy S3, run 03f544de-5960-4729-b97e-fd365a1c4aca, engine 2.0.0.dev1._
