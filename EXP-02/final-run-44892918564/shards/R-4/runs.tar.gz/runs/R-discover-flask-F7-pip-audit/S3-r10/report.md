## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 19321)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.673 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.524 | 0 |
| gitleaks | VALID | - | 0 | 0.491 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a1bf1a0d0405), strategy S3, run 2bda5be9-a8ea-4c89-9455-958450ec3fb9, engine 2.0.0.dev1._
