## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 19321)
- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (manage.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.676 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.532 | 0 |
| gitleaks | VALID | - | 0 | 0.483 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run 9d7b0de7-be6b-48ea-a152-7fa519c61b91, engine 2.0.0.dev1._
