## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.694 | 0 |
| pip-audit | VALID | - | 1 | 0.532 | 0 |
| gitleaks | VALID | - | 0 | 0.486 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 13d6257075fe), strategy S0, run 6b4fb845-36af-49eb-9b8e-11342a161ef2, engine 2.0.0.dev1._
