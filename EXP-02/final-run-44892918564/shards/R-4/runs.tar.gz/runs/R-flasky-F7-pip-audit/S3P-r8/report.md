## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.709 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.502 | 0 |
| gitleaks | VALID | - | 0 | 0.476 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9979d4fe8d5), strategy S3, run a4fd79c4-4c32-4804-9c54-5f8be8e98619, engine 2.0.0.dev1._
