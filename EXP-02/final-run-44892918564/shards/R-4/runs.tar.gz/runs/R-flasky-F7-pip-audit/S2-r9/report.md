## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.687 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.503 | 0 |
| gitleaks | VALID | - | 0 | 0.472 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 216f499b289e), strategy S2, run 455fb3c0-1265-4af3-b4a5-3072ce7b29bb, engine 2.0.0.dev1._
