## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.703 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.504 | 0 |
| gitleaks | VALID | - | 0 | 0.477 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f008fc467a66), strategy S1, run ea7dc8cd-c02a-4da4-a195-fbf3e95416b5, engine 2.0.0.dev1._
