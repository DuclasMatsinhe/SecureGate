## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.676 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.503 | 0 |
| gitleaks | VALID | - | 0 | 0.482 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a1bf1a0d0405), strategy S3, run 85b1ae5a-e82a-4131-b919-b9c5413201a5, engine 2.0.0.dev1._
