## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.706 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.507 | 0 |
| gitleaks | VALID | - | 0 | 0.484 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 216f499b289e), strategy S2, run b302466b-029f-4a41-a2ac-ffc0a9daf555, engine 2.0.0.dev1._
