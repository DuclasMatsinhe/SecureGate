## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.692 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.502 | 0 |
| gitleaks | VALID | - | 0 | 0.479 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a1bf1a0d0405), strategy S3, run 094e3252-d310-47c9-9b7f-6c4b593f65fb, engine 2.0.0.dev1._
