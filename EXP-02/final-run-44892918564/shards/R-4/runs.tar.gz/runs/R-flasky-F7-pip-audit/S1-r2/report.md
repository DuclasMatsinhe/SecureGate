## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 17)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.693 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.509 | 0 |
| gitleaks | VALID | - | 0 | 0.493 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f008fc467a66), strategy S1, run 17f77c8e-0413-4203-97b3-314412e20c21, engine 2.0.0.dev1._
