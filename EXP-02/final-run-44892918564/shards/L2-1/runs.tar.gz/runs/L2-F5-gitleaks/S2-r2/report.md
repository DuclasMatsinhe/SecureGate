## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.509 | 0 |
| pip-audit | VALID | - | 0 | 0.437 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.502 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bb5c469a4f04), strategy S2, run d2a71452-bc00-464b-bf73-1b4fb8852f6f, engine 2.0.0.dev1._
