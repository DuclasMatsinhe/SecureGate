## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.535 | 0 |
| pip-audit | VALID | - | 0 | 0.458 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.371 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cc66ecbba6f4), strategy S3, run c6086297-b812-48c2-ab00-83a27089d34b, engine 2.0.0.dev1._
