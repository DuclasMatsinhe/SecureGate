## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.42 | 0 |
| pip-audit | VALID | - | 0 | 0.378 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0e1f2b38f8ad), strategy S3, run b3bf2b5c-ee67-4fa1-ac7e-f8fab00cab33, engine 2.0.0.dev1._
