## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.669 | 0 |
| pip-audit | VALID | - | 0 | 0.489 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.385 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7dc0586a99c), strategy S1, run e8d12cb3-881a-4a65-9e8d-686d3a013e3c, engine 2.0.0.dev1._
