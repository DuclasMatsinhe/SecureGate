## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.314 | 0 |
| pip-audit | VALID | - | 0 | 0.372 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.341 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cc66ecbba6f4), strategy S3, run 446474f4-ca26-48bd-80ee-eaeea24ce4bc, engine 2.0.0.dev1._
