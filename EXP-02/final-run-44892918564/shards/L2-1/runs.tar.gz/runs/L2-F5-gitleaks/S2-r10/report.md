## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.768 | 0 |
| pip-audit | VALID | - | 0 | 0.53 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.441 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bb5c469a4f04), strategy S2, run 52f03922-1bb5-4024-b82e-1ba6eee283a0, engine 2.0.0.dev1._
