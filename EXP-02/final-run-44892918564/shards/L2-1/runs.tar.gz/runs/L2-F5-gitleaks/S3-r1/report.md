## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.675 | 0 |
| pip-audit | VALID | - | 0 | 0.437 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.405 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cc66ecbba6f4), strategy S3, run fc879de9-9c2e-4d83-b1e5-588bee2b1c3e, engine 2.0.0.dev1._
