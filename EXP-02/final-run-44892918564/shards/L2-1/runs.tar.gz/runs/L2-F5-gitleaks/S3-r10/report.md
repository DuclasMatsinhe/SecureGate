## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.56 | 0 |
| pip-audit | VALID | - | 0 | 0.35 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.34 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cc66ecbba6f4), strategy S3, run bdc1cb46-de19-49d1-9d86-5ecd818d547e, engine 2.0.0.dev1._
