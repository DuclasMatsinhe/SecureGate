## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.473 | 0 |
| pip-audit | VALID | - | 0 | 0.388 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cc66ecbba6f4), strategy S3, run 7c89ee1b-d100-46fb-9259-774162ecf3df, engine 2.0.0.dev1._
