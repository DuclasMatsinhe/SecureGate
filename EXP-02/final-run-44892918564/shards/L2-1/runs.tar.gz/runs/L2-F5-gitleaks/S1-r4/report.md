## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.681 | 0 |
| pip-audit | VALID | - | 0 | 0.434 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.384 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7dc0586a99c), strategy S1, run 025e1e7f-c4a7-4f89-8bff-4923b05e804b, engine 2.0.0.dev1._
