## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.402 | 0 |
| pip-audit | VALID | - | 0 | 0.37 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.34 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0e1f2b38f8ad), strategy S3, run ed9fd1e4-5cc0-4e14-b470-2643f5ca039b, engine 2.0.0.dev1._
