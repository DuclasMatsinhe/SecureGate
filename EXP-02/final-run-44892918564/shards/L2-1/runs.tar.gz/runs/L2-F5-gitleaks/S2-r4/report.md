## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.67 | 0 |
| pip-audit | VALID | - | 0 | 0.451 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.421 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bb5c469a4f04), strategy S2, run cfc1e6fa-19c3-4ea1-8f9c-ba223fc8396c, engine 2.0.0.dev1._
