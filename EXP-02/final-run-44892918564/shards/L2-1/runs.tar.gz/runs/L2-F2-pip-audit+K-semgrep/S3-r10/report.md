## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_bx5yux_s.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.648 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.029 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_bx5yux_s.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 2d1f49bcc4e0), strategy S3, run daaa1ae1-f1b6-40f5-a62e-df28f1c3e0dd, engine 2.0.0.dev1._
