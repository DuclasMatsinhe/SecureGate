## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_bx5yux_s.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.771 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.031 | 0 |
| gitleaks | VALID | - | 0 | 0.321 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_bx5yux_s.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 06b948cb15b3), strategy S1, run 372e51d2-7a7f-4d2a-8f1e-e7192b121dde, engine 2.0.0.dev1._
