## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_bx5yux_s.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.515 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.029 | 0 |
| gitleaks | VALID | - | 0 | 0.395 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_bx5yux_s.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 1cf536c865b0), strategy S3, run 90002606-c3e2-4da8-8c39-79efbc3e7e20, engine 2.0.0.dev1._
