## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.421 | 0 |
| gitleaks | VALID | - | 0 | 0.319 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 fdbdb8ac2287), strategy S0, run 02d267a3-5c23-4c3a-9228-d8d2d00c99ba, engine 2.0.0.dev1._
