## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.387 | 0 |
| gitleaks | VALID | - | 0 | 0.305 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5742fb0de3a6), strategy S1, run 0b6fb15f-1757-47af-a5c1-04b3cb5ecc16, engine 2.0.0.dev1._
