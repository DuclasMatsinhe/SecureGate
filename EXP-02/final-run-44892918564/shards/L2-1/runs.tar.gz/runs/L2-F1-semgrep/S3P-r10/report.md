## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.365 | 0 |
| gitleaks | VALID | - | 0 | 0.328 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 55442fa76935), strategy S3, run 5512b8b8-2606-43f1-906c-a92a18fae390, engine 2.0.0.dev1._
