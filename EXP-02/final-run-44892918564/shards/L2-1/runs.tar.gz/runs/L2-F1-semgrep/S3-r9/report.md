## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.379 | 0 |
| gitleaks | VALID | - | 0 | 0.348 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6921f8aa0760), strategy S3, run 320306a7-a2d5-4e71-9f03-822593a5778d, engine 2.0.0.dev1._
