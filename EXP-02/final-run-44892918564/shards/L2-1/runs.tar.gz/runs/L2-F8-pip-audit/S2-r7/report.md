## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.391 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.39 | 0 |
| gitleaks | VALID | - | 0 | 0.317 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4166a0a5ceca), strategy S2, run f6555393-a698-4f90-bc8b-813170031d70, engine 2.0.0.dev1._
