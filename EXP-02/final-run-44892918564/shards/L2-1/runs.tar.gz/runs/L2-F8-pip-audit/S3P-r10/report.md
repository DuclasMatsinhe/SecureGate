## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.607 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.434 | 0 |
| gitleaks | VALID | - | 0 | 0.373 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4924c8d4984), strategy S3, run 3dec06dc-1de6-48ff-a545-58d4b5dd42b2, engine 2.0.0.dev1._
