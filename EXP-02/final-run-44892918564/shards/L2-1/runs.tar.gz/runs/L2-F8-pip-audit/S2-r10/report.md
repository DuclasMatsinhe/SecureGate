## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.463 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.352 | 0 |
| gitleaks | VALID | - | 0 | 0.302 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4166a0a5ceca), strategy S2, run ce582572-e9f2-4e28-86bb-747a12295a92, engine 2.0.0.dev1._
