## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.446 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.481 | 0 |
| gitleaks | VALID | - | 0 | 0.374 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4924c8d4984), strategy S3, run 947d6433-3b6a-41a0-860c-254c1b0d793d, engine 2.0.0.dev1._
