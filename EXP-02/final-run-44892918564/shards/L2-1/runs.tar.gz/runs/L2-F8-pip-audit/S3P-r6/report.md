## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.56 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.401 | 0 |
| gitleaks | VALID | - | 0 | 0.316 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b4924c8d4984), strategy S3, run 8fc66589-f2a6-42c1-88cf-9842f6a60dd1, engine 2.0.0.dev1._
