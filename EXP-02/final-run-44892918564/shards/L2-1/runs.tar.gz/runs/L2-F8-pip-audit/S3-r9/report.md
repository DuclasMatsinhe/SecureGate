## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.609 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.457 | 0 |
| gitleaks | VALID | - | 0 | 0.392 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5a39d0ee7ce4), strategy S3, run 632ec69e-499b-4c8b-a373-bfc1e77aa550, engine 2.0.0.dev1._
