## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.515 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.439 | 0 |
| gitleaks | VALID | - | 0 | 0.342 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5a39d0ee7ce4), strategy S3, run 7e19bc7e-8310-4530-802e-a4062e8dd23c, engine 2.0.0.dev1._
