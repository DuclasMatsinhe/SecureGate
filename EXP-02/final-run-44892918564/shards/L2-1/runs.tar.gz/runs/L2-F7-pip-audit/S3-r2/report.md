## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.4 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.391 | 0 |
| gitleaks | VALID | - | 0 | 0.315 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 480caf67bd57), strategy S3, run 85f784f8-cb0c-471b-b8af-d5402530cf4a, engine 2.0.0.dev1._
