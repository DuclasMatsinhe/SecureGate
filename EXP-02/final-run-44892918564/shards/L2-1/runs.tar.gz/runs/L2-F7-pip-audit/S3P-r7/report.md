## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.369 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.395 | 0 |
| gitleaks | VALID | - | 0 | 0.315 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c71e42eee7d9), strategy S3, run d59f9f2a-ad5a-41bd-90cb-d473e4263d79, engine 2.0.0.dev1._
