## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.412 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.405 | 0 |
| gitleaks | VALID | - | 0 | 0.32 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 480caf67bd57), strategy S3, run 7fc06747-ae6f-4b55-9a31-7e088d48e577, engine 2.0.0.dev1._
