## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.415 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.376 | 0 |
| gitleaks | VALID | - | 0 | 0.322 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 480caf67bd57), strategy S3, run 6b40801a-b3a6-4a22-be4f-d593df50a289, engine 2.0.0.dev1._
