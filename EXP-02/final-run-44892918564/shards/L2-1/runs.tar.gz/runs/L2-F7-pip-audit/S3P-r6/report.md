## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.348 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.328 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c71e42eee7d9), strategy S3, run 49f030b0-d9ee-4455-9326-5b12c8c15e35, engine 2.0.0.dev1._
