## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.358 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.029 | 0 |
| gitleaks | VALID | - | 0 | 0.316 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ca1f0b25e078), strategy S2, run cd5bf0bc-c1bb-4f9a-87c6-8d53da37a2e5, engine 2.0.0.dev1._
