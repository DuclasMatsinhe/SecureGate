## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.411 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.023 | 0 |
| gitleaks | VALID | - | 0 | 0.336 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ca1f0b25e078), strategy S2, run b1ba0c3c-33cc-4f29-b7db-650e03b59417, engine 2.0.0.dev1._
