## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.548 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.024 | 0 |
| gitleaks | VALID | - | 0 | 0.314 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2d1f49bcc4e0), strategy S3, run bfc44170-79a6-4da1-8ef3-a7cd0e3e24e4, engine 2.0.0.dev1._
