## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.382 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.32 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2408bf78e7aa), strategy S0, run 626a2b31-53d9-4de9-9ed4-6696f2d1d4fb, engine 2.0.0.dev1._
