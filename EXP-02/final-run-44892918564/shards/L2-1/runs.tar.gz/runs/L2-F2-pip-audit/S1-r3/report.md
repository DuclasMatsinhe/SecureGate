## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.341 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.024 | 0 |
| gitleaks | VALID | - | 0 | 0.31 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 06b948cb15b3), strategy S1, run af357840-f043-4abb-9f41-70a955e712de, engine 2.0.0.dev1._
