## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.456 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.023 | 0 |
| gitleaks | VALID | - | 0 | 0.325 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2408bf78e7aa), strategy S0, run 99034c5e-6786-4425-9bf0-adba927daebd, engine 2.0.0.dev1._
