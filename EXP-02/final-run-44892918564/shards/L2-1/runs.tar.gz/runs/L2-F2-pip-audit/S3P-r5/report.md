## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.622 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.027 | 0 |
| gitleaks | VALID | - | 0 | 0.322 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1cf536c865b0), strategy S3, run 2cb0cc8f-c7ac-4e5b-bbab-73bdc1bd864a, engine 2.0.0.dev1._
