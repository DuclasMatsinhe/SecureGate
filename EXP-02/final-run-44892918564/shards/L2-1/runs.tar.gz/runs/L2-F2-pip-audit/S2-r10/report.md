## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.411 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.023 | 0 |
| gitleaks | VALID | - | 0 | 0.322 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ca1f0b25e078), strategy S2, run 4765146f-e56f-46dd-b10e-823540a23026, engine 2.0.0.dev1._
