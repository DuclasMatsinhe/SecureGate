## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'
- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'
- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_bx5yux_s/not-installed/tool'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 09ccfa8fcf06), strategy S3, run 5a4c16d0-b683-42e4-8b9d-da270f25a860, engine 2.0.0.dev1._
