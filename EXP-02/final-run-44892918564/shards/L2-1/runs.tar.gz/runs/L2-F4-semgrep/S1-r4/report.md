## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.023 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | VALID | - | 0 | 0.312 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0f4506a7d0e4), strategy S1, run b6deb9fe-c08a-43c5-aba2-708dbcf37f82, engine 2.0.0.dev1._
