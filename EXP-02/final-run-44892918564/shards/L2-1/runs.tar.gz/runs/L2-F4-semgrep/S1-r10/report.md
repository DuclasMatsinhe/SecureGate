## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.025 | 0 |
| pip-audit | VALID | - | 0 | 0.383 | 0 |
| gitleaks | VALID | - | 0 | 0.31 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0f4506a7d0e4), strategy S1, run ea7917eb-b5ca-4a37-8887-185f5da95ecf, engine 2.0.0.dev1._
