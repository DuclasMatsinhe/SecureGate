## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.411 | 0 |
| gitleaks | VALID | - | 0 | 0.326 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4724981f0175), strategy S3, run 5c1b247b-8491-479e-95a8-724cf119593d, engine 2.0.0.dev1._
