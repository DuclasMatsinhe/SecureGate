## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.027 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | VALID | - | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9988f44ec574), strategy S2, run 5654596a-04fb-4bea-88c0-2155507ce25a, engine 2.0.0.dev1._
