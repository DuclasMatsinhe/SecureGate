## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.026 | 0 |
| pip-audit | VALID | - | 0 | 0.407 | 0 |
| gitleaks | VALID | - | 0 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d7876ec73e26), strategy S3, run 3c7b5d4d-5d67-45bf-9d8a-a74e78d7628c, engine 2.0.0.dev1._
