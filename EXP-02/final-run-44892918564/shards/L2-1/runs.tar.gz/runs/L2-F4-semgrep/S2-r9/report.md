## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.028 | 0 |
| pip-audit | VALID | - | 0 | 0.441 | 0 |
| gitleaks | VALID | - | 0 | 0.374 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9988f44ec574), strategy S2, run 85a6e094-3f6c-4215-b491-cb52be66afd0, engine 2.0.0.dev1._
