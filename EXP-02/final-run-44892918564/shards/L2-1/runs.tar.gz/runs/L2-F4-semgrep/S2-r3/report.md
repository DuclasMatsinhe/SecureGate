## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.023 | 0 |
| pip-audit | VALID | - | 0 | 0.378 | 0 |
| gitleaks | VALID | - | 0 | 0.302 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9988f44ec574), strategy S2, run 7c023f21-f58b-4d0d-9f1b-9084cf626b42, engine 2.0.0.dev1._
