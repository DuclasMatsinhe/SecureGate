## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_live_hji3r2iq.fixtures.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 1 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_live_hji3r2iq.fixtures.probe-eval | app.py:2 | - |

_Policy inline v1.0 (sha256 ad9fd14fc93b), strategy S2, run 2259a4fe-8238-4fe1-b4b2-2d7f1d1f22a1, engine 2.0.0.dev1._
