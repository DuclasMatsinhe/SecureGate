## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_exp02_tqzig8v7/not-installed/tool'
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 1 | 0.369 | 18 |
| gitleaks | VALID | - | 0 | 0.343 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4177 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4175 | dependency | - |

_Policy policy.toml vEXP-02 v1 (sha256 c46dc0a924f9), strategy S3, run b86bcde7-82b8-4ff3-aebb-f21374285ac7, engine 2.0.0.dev1._
