## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.294 | 0 |
| pip-audit | VALID | - | 0 | 0.369 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.372 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 55ec31d8b819), strategy S3, run ed78b83c-3142-4a1a-b186-7ed3577a561f, engine 2.0.0.dev1._
