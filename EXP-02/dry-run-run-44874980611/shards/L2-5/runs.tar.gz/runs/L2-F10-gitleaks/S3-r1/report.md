## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.27 | 0 |
| pip-audit | VALID | - | 0 | 0.366 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.37 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 8e763d520a18), strategy S3, run 683a9e17-d710-4a7d-9a97-58cf413d0e52, engine 2.0.0.dev1._
