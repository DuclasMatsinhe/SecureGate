## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INCONSISTENT_EXIT`: Gitleaks exited 3 (leaks found) but its report is empty

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.272 | 0 |
| pip-audit | VALID | - | 0 | 0.365 | 0 |
| gitleaks | INVALID | INCONSISTENT_EXIT | 3 | 0.359 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 40b850a5dbc7), strategy S2, run 9b51311c-6c34-402e-9f84-0433357f1ce3, engine 2.0.0.dev1._
