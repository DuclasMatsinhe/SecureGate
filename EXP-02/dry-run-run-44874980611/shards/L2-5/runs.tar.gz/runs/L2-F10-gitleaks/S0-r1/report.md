## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.245 | 0 |
| pip-audit | VALID | - | 0 | 0.367 | 0 |
| gitleaks | VALID | - | 3 | 0.364 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 cd264db4d3a1), strategy S0, run 824496a7-f7e7-48d5-853c-bb5e7eade900, engine 2.0.0.dev1._
