## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.267 | 0 |
| pip-audit | VALID | - | 0 | 0.369 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a04a890877a3), strategy S1, run 92f6f024-eb13-4d26-864b-9f9eeaf1f7bd, engine 2.0.0.dev1._
