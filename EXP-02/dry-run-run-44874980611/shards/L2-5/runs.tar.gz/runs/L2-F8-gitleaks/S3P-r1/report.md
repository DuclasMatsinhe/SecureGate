## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.319 | 0 |
| pip-audit | VALID | - | 0 | 0.366 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.338 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d621b146db00), strategy S3, run e444c664-ec8d-4a4f-b9f0-7742842487b0, engine 2.0.0.dev1._
