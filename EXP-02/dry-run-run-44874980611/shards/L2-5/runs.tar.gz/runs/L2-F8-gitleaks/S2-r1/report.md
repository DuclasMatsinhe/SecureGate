## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.317 | 0 |
| pip-audit | VALID | - | 0 | 0.372 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.339 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 48363afd05b9), strategy S2, run 727f8385-f69e-4b18-a9ed-4f14a38878b4, engine 2.0.0.dev1._
