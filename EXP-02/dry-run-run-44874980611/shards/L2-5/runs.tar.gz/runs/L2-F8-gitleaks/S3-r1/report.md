## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.305 | 0 |
| pip-audit | VALID | - | 0 | 0.367 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.337 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7d8719ad1507), strategy S3, run 0536eaa9-9c65-481f-b096-f75eb628ec9c, engine 2.0.0.dev1._
