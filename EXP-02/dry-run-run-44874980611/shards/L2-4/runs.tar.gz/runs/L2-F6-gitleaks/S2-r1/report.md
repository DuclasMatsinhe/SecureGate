## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.241 | 0 |
| pip-audit | VALID | - | 0 | 0.357 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c191a44bd607), strategy S2, run a3bcd202-6d1d-4a71-b544-68f9aae76f4f, engine 2.0.0.dev1._
