## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.25 | 0 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 993a0fced040), strategy S1, run 482b33e8-4a18-43a1-983c-7e9f5abd3318, engine 2.0.0.dev1._
