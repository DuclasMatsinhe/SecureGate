## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.228 | 0 |
| pip-audit | VALID | - | 0 | 0.361 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f84b73295ff2), strategy S3, run 69571160-a0fe-43bd-826f-c3ae74b07964, engine 2.0.0.dev1._
