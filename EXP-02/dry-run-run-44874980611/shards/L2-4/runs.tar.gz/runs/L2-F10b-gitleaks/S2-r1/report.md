## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 6:22AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 6:22AM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.244 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.227 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a76698c8d93f), strategy S2, run 7c4f5ca2-a5d4-4a3e-87c2-6c9413947de3, engine 2.0.0.dev1._
