## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.214 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.362 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c364d512c6ee), strategy S1, run b9716150-d25f-41e0-a998-a2c923fb635f, engine 2.0.0.dev1._
