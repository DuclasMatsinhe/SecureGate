## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.182 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.336 | 0 |
| gitleaks | VALID | - | 0 | 0.346 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 505becb154fe), strategy S2, run 0c6c8252-9dcf-4c24-8028-51779aeebf8d, engine 2.0.0.dev1._
