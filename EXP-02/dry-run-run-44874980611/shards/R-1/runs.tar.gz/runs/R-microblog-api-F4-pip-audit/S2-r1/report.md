## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.184 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.358 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9dfaa3885a1d), strategy S2, run f46bba95-cac8-4afb-906f-5bb229f82302, engine 2.0.0.dev1._
