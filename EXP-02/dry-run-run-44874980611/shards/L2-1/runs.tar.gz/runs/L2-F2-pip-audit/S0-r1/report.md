## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.238 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0ca53a33f7df), strategy S0, run 8da3cd1f-3cb3-4d5d-9391-29aff6e67cc3, engine 2.0.0.dev1._
