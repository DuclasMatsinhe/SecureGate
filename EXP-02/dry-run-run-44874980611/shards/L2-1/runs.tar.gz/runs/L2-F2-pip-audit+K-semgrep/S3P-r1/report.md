## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_p0tk1zlz.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.275 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_p0tk1zlz.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 a16dab7efe7c), strategy S3, run f5b9a652-b50e-491a-a831-4690cf02c0b2, engine 2.0.0.dev1._
