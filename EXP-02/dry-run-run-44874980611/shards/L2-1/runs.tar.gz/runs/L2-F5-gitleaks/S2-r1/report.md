## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.241 | 0 |
| pip-audit | VALID | - | 0 | 0.356 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.359 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0ade85e9e4b3), strategy S2, run d1e8fd6e-7bb8-479d-a391-5fd161b1f638, engine 2.0.0.dev1._
