## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 ad9fd14fc93b), strategy S2, run 937de5c0-8885-4c59-9785-3679b2bc8034, engine 2.0.0.dev1._
