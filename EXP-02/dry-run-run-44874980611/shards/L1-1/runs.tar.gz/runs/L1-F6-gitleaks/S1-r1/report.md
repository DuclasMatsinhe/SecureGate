## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 399578376279), strategy S1, run 5047ce3f-6f39-4eee-87e9-5cbf8ea79480, engine 2.0.0.dev1._
