## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Gitleaks: injected (L1)
- `TOOL_MISSING`: pip-audit: injected (L1)
- `TOOL_MISSING`: Semgrep: injected (L1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy inline v1.0 (sha256 aa9b385ffe88), strategy S0, run ef9ee149-c928-4da7-bc76-4f2341f55b6a, engine 2.0.0.dev1._
