## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: injected (L1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 ad9fd14fc93b), strategy S2, run 308b55ac-1dc6-43b2-95ad-9068f5df4efb, engine 2.0.0.dev1._
