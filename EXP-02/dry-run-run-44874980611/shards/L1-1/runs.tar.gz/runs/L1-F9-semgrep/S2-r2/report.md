## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `PARTIAL_COVERAGE`: Semgrep could not analyse 1 file(s) (broken.py)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 ad9fd14fc93b), strategy S2, run b15cd8eb-9789-4a00-a38d-8e06c433a4ca, engine 2.0.0.dev1._
