## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_live_hji3r2iq.fixtures.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 1 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.0 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_live_hji3r2iq.fixtures.probe-eval | app.py:2 | - |

_Policy inline v1.0 (sha256 c9ff4b86847b), strategy S3, run 265c89d6-a850-419b-b449-6748456a14d8, engine 2.0.0.dev1._
