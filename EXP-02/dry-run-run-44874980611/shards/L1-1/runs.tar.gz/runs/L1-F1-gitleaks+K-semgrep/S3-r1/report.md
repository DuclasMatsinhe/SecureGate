## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Gitleaks: injected (L1)
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_live_hji3r2iq.fixtures.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 1 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_live_hji3r2iq.fixtures.probe-eval | app.py:2 | - |

_Policy inline v1.0 (sha256 c9ff4b86847b), strategy S3, run 90a75de4-8dc7-46bc-b626-e8a2b6c01f1d, engine 2.0.0.dev1._
