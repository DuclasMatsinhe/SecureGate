## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: pip-audit skipped 1 of 2 dependencies (securegate-nonexistent-probe-package)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.247 | 0 |
| pip-audit | INVALID | PARTIAL_COVERAGE | 0 | 0.4 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 557c0a24c559), strategy S3, run 1724da09-9401-461f-b6b8-6b2bd72ad611, engine 2.0.0.dev1._
