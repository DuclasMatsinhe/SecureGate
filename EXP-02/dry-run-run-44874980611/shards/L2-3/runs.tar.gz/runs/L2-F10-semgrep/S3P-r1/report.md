## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 1; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 1 | 1.242 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 244c6b0f2434), strategy S3, run 62d9517c-0f18-4bf6-9461-d98980c011d4, engine 2.0.0.dev1._
