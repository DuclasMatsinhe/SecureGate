## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (manage.py); Semgrep reported no error, so their analysis may be incomplete
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2017-43 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2017-43 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-55 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-55 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-123 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-123 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-124 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-124 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-140 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-140 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-220 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-220 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-157 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-157 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-203 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-260 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-260 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1065 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1065 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.253 | 0 |
| pip-audit | VALID | - | 1 | 0.369 | 61 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2019-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-220 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-220 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |

_41 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 5e9a3dc6b4d5), strategy S3, run ba5c475c-017b-4667-9bb6-7940adbd64db, engine 2.0.0.dev1._
