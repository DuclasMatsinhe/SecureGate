## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.197 | 0 |
| pip-audit | VALID | - | 1 | 0.393 | 0 |
| gitleaks | VALID | - | 0 | 1.924 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9d88d25a55b2), strategy S0, run ab3fcf15-4dde-40c1-b36b-e9f092376420, engine 2.0.0.dev1._
