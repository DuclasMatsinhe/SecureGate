## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.221 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.411 | 0 |
| gitleaks | VALID | - | 0 | 0.355 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7a6661d57a20), strategy S3, run 746646dd-7cd4-455c-885b-73b25868bc5b, engine 2.0.0.dev1._
