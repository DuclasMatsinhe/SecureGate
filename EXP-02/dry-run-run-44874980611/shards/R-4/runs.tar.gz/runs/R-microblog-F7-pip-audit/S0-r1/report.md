## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.213 | 0 |
| pip-audit | VALID | - | 1 | 0.413 | 0 |
| gitleaks | VALID | - | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9d88d25a55b2), strategy S0, run c035db28-5c71-4ebb-b215-ef0a1e654325, engine 2.0.0.dev1._
