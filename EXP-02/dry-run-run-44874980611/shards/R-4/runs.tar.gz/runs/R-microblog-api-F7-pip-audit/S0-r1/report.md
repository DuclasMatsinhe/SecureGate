## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.207 | 0 |
| pip-audit | VALID | - | 1 | 0.398 | 0 |
| gitleaks | VALID | - | 0 | 0.361 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9d88d25a55b2), strategy S0, run 3557f37b-accb-40da-867f-8cbe2da83424, engine 2.0.0.dev1._
