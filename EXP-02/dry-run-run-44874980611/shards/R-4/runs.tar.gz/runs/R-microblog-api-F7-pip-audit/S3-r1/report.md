## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 70831)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.215 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.401 | 0 |
| gitleaks | VALID | - | 0 | 0.365 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ec4782693eb2), strategy S3, run 89e78d60-5dd4-45c3-994c-0e1b845cadbe, engine 2.0.0.dev1._
