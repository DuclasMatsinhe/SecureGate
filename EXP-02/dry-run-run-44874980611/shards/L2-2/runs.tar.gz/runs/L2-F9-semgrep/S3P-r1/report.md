## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (broken.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.221 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 b0d0eca8cfc9), strategy S3, run 1b2b23de-9eb9-4073-9526-4c2acd740d57, engine 2.0.0.dev1._
