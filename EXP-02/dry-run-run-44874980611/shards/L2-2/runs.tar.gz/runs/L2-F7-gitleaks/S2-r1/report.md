## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.283 | 0 |
| pip-audit | VALID | - | 0 | 0.359 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.355 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9307248d4f77), strategy S2, run c8ded642-8396-4f44-a77c-506f2a0762c7, engine 2.0.0.dev1._
