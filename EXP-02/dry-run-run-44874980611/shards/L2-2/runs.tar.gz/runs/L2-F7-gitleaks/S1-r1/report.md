## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.27 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.363 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2e0cafe0c262), strategy S1, run ac373d5b-2dc3-4f96-8bd2-05d6aab6fb43, engine 2.0.0.dev1._
