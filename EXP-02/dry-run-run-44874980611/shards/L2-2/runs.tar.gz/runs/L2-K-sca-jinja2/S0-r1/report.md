## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 0 |
| pip-audit | VALID | - | 1 | 0.409 | 12 |
| gitleaks | VALID | - | 0 | 0.342 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |

_Policy policy.toml vEXP-02 v1 (sha256 e1e4b6f31d7e), strategy S0, run 544549ab-0c79-4f5b-ae23-0a0180642382, engine 2.0.0.dev1._
