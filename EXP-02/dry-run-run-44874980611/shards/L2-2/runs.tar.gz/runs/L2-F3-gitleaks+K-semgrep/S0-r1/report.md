## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_uwummsz3.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.263 | 1 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_uwummsz3.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 939e5d3b02c6), strategy S0, run e5a7715e-8d4d-442b-b000-54cb380d2f06, engine 2.0.0.dev1._
