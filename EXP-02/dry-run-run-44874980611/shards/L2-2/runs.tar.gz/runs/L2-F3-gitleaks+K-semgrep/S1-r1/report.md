## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_uwummsz3.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.238 | 1 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.002 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_uwummsz3.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 9961b50cb742), strategy S1, run b1e49b43-2d75-4bd0-8422-ed937fe7edc2, engine 2.0.0.dev1._
