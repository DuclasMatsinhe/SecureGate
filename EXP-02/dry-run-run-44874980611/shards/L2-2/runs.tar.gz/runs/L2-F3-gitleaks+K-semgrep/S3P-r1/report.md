## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_exp02_uwummsz3.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.225 | 1 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_exp02_uwummsz3.probe-eval | app.py:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 bfb15ff64591), strategy S3, run 834028e4-23d9-4e8c-8960-6eae5be00a2c, engine 2.0.0.dev1._
