## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.239 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.339 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 07cf87f407fb), strategy S3, run c75814b0-9916-4afd-852f-77e94ac857d5, engine 2.0.0.dev1._
