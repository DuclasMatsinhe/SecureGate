## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.35 | 0 |
| gitleaks | VALID | - | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7bfc05c5011a), strategy S3, run d270ea90-6a1e-4db9-9dc2-48acbe3095a6, engine 2.0.0.dev1._
