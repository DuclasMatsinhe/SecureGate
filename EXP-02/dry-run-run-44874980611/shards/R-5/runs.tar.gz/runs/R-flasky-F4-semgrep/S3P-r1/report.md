## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 0.352 | 0 |
| gitleaks | VALID | - | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 59cad9ed74b4), strategy S3, run 26c7d7f3-6f49-41f7-8319-081efee0b924, engine 2.0.0.dev1._
