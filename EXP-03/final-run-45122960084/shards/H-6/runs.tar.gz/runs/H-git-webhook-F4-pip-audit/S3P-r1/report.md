## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report
- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (manage.py); Semgrep reported no error, so their analysis may be incomplete
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (app/config_docker_example.py:19)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (app/config_example.py:19)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docker/gogs/conf/app.ini:49)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (manage.py:111)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/webhookdata/gitosc.json:2)
- `BLOCKING_FINDING`: Gitleaks HIGH: private-key (docker/ssh/id_rsa:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.205 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 3 | 0.408 | 6 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | app/config_docker_example.py:19 | - |
| Gitleaks | HIGH | generic-api-key | app/config_example.py:19 | - |
| Gitleaks | HIGH | generic-api-key | manage.py:111 | - |
| Gitleaks | HIGH | private-key | docker/ssh/id_rsa:1 | - |
| Gitleaks | HIGH | generic-api-key | tests/webhookdata/gitosc.json:2 | - |
| Gitleaks | HIGH | generic-api-key | docker/gogs/conf/app.ini:49 | - |

_Policy policy.toml vEXP-02 v1 (sha256 439cf9e357da), strategy S3, run a3c07ea4-f682-4eae-aa79-d0c7e153777e, engine 2.0.0.dev1._
