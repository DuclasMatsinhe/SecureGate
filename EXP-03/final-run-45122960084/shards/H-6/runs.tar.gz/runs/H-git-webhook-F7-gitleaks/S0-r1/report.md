## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-19 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-19 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-55 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-55 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-69 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-69 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-220 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-220 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-12 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-12 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-166 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1307 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1350 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1350 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.221 | 0 |
| pip-audit | VALID | - | 1 | 0.356 | 45 |
| gitleaks | VALID | - | 3 | 0.431 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2019-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-502 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-502 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-220 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-220 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |

_25 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 5ee1d4a58096), strategy S0, run 71e066fb-a4f8-4e4b-9ebc-c9eb95950230, engine 2.0.0.dev1._
