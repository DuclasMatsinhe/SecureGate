## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (app/config_docker_example.py:19)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (app/config_example.py:19)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docker/gogs/conf/app.ini:49)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (manage.py:111)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/webhookdata/gitosc.json:2)
- `BLOCKING_FINDING`: Gitleaks HIGH: private-key (docker/ssh/id_rsa:1)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-19 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-19 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-55 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-55 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-69 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-69 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-217 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-220 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2019-220 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-12 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-12 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-166 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1307 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1350 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1350 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1433 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1434 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2858 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 1 | 0.367 | 45 |
| gitleaks | VALID | - | 3 | 0.401 | 6 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2019-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-502 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-502 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-220 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-217 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2019-220 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |

_31 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 b1a9e1cc76e3), strategy S2, run a5444c2d-dfb5-4951-80d7-3647b40bcef1, engine 2.0.0.dev1._
