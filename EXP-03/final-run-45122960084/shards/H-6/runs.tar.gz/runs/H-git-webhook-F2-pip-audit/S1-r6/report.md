## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (app/config_docker_example.py:19)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (app/config_example.py:19)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docker/gogs/conf/app.ini:49)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (manage.py:111)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/webhookdata/gitosc.json:2)
- `BLOCKING_FINDING`: Gitleaks HIGH: private-key (docker/ssh/id_rsa:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.239 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| gitleaks | VALID | - | 3 | 0.403 | 6 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | app/config_example.py:19 | - |
| Gitleaks | HIGH | generic-api-key | app/config_docker_example.py:19 | - |
| Gitleaks | HIGH | generic-api-key | manage.py:111 | - |
| Gitleaks | HIGH | private-key | docker/ssh/id_rsa:1 | - |
| Gitleaks | HIGH | generic-api-key | docker/gogs/conf/app.ini:49 | - |
| Gitleaks | HIGH | generic-api-key | tests/webhookdata/gitosc.json:2 | - |

_Policy policy.toml vEXP-02 v1 (sha256 e71fb636a2b6), strategy S1, run ac248500-f2bc-4928-80a9-c1a8ac5e13d9, engine 2.0.0.dev1._
