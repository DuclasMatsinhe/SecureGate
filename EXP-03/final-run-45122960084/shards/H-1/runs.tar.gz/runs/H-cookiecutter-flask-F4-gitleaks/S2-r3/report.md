## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.186 | 0 |
| pip-audit | VALID | - | 0 | 0.338 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.02 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 dfe7eca63f50), strategy S2, run f95e56cb-3388-4cd6-b352-48e3f26056e4, engine 2.0.0.dev1._
