## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.182 | 0 |
| pip-audit | VALID | - | 0 | 0.338 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.02 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 93b298673d24), strategy S3, run 244456a2-7c06-4110-8cbf-22a7379a5cd6, engine 2.0.0.dev1._
