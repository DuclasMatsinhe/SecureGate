## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.177 | 0 |
| pip-audit | VALID | - | 0 | 0.336 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.02 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 93b298673d24), strategy S3, run 8f911059-0b98-4318-92ef-e6047c0327e2, engine 2.0.0.dev1._
