## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.171 | 0 |
| pip-audit | VALID | - | 0 | 0.337 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.02 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 dfe7eca63f50), strategy S2, run cfac33d1-7de1-4085-acf3-7b221171e784, engine 2.0.0.dev1._
