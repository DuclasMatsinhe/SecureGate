## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `PARTIAL_COVERAGE`: 5 Python file(s) listed by Semgrep as scanned cannot be parsed ({{cookiecutter.app_name}}/autoapp.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/app.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/public/forms.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/public/views.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/user/models.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.174 | 0 |
| pip-audit | VALID | - | 0 | 0.339 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 31871be8ec3e), strategy S3, run 9cf9caeb-2ba0-40d9-a84b-229c0ad7c1bf, engine 2.0.0.dev1._
