## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.194 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.35 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9697a7af4271), strategy S2, run 0e32d053-6568-49d0-a7fb-46c3259367d9, engine 2.0.0.dev1._
