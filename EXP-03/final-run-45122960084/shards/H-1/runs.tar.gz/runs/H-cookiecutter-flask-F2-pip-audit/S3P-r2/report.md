## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `PARTIAL_COVERAGE`: 5 Python file(s) listed by Semgrep as scanned cannot be parsed ({{cookiecutter.app_name}}/autoapp.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/app.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/public/forms.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/public/views.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/user/models.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.211 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| gitleaks | VALID | - | 0 | 0.349 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e9be346e5310), strategy S3, run ecd5e90b-9aa3-49a1-973c-dae32f00e237, engine 2.0.0.dev1._
