## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 127)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.208 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.371 | 0 |
| gitleaks | VALID | - | 0 | 0.347 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 18c0669fb2b9), strategy S3, run 04733d36-b0e7-42f5-bca8-588964fae65d, engine 2.0.0.dev1._
