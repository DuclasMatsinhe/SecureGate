## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 127)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.224 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.375 | 0 |
| gitleaks | VALID | - | 0 | 0.347 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0a905caa25d0), strategy S2, run f3e956c4-7ccf-4218-bb8a-c8a8864f0a30, engine 2.0.0.dev1._
