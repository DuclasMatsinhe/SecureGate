## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 127)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.222 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.373 | 0 |
| gitleaks | VALID | - | 0 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 18c0669fb2b9), strategy S3, run 273f5a40-9b78-473f-9a8b-6c09e85e7953, engine 2.0.0.dev1._
