## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 127)
- `PARTIAL_COVERAGE`: 5 Python file(s) listed by Semgrep as scanned cannot be parsed ({{cookiecutter.app_name}}/autoapp.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/app.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/public/forms.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/public/views.py, {{cookiecutter.app_name}}/{{cookiecutter.app_name}}/user/models.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.23 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.381 | 0 |
| gitleaks | VALID | - | 0 | 0.35 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a2ae35ab22a7), strategy S3, run 8e3a81ba-94d2-4788-b2c9-0c9dae24523e, engine 2.0.0.dev1._
