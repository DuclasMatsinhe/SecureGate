## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 127)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.243 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d04bd1b2feb2), strategy S1, run 4b3a88d4-ce8d-4df7-835c-a1d80f031e58, engine 2.0.0.dev1._
