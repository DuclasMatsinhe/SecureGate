## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting value at char 127)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.221 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.344 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 18c0669fb2b9), strategy S3, run f39f446a-b930-4021-8a56-f04fb5cf7995, engine 2.0.0.dev1._
