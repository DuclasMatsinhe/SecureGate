## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.374 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bca6aac40293), strategy S2, run f09066ce-b6c2-4042-9f53-48910afa1797, engine 2.0.0.dev1._
