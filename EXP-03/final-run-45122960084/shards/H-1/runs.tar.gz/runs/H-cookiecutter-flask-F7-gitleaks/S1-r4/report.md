## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.21 | 0 |
| pip-audit | VALID | - | 0 | 0.355 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.379 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 78a42990a350), strategy S1, run c2523874-5b4a-41ae-a9d7-24948629eecf, engine 2.0.0.dev1._
