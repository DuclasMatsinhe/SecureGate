## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.371 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bca6aac40293), strategy S2, run a2e056b0-1242-446b-ad13-04d8a562f066, engine 2.0.0.dev1._
