## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.202 | 0 |
| pip-audit | VALID | - | 0 | 0.344 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.37 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bca6aac40293), strategy S2, run 36caa240-8117-4988-b7a1-518b25f3d2b9, engine 2.0.0.dev1._
