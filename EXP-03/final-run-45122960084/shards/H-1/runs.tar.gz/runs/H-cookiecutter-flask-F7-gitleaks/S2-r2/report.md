## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.194 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.369 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bca6aac40293), strategy S2, run 862a4b4d-0d26-4c11-b9d3-50a6a940a7cb, engine 2.0.0.dev1._
