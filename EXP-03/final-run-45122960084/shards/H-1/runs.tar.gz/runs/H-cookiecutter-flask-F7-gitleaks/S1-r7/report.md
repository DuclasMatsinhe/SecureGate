## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.199 | 0 |
| pip-audit | VALID | - | 0 | 0.345 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.377 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 78a42990a350), strategy S1, run b7137954-6c63-4956-abe5-ba20ba3864fc, engine 2.0.0.dev1._
