## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.214 | 0 |
| pip-audit | VALID | - | 0 | 0.349 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.378 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 78a42990a350), strategy S1, run 2157c69e-a484-468c-affa-7885f70ed878, engine 2.0.0.dev1._
