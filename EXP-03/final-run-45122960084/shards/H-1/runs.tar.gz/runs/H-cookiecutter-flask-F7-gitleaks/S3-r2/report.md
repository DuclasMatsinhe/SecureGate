## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.204 | 0 |
| pip-audit | VALID | - | 0 | 0.346 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.369 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f66b490ad3fe), strategy S3, run b80ffad7-4d4b-445e-92be-27bbc1fc3f32, engine 2.0.0.dev1._
