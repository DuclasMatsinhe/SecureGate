## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 1244)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.246 | 0 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | VALID | - | 0 | 0.355 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5d492b4b947e), strategy S3, run 399a1b44-4f66-4514-837f-36b49602c795, engine 2.0.0.dev1._
