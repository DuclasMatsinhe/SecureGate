## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting property name enclosed in double quotes at char 1244)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.234 | 0 |
| pip-audit | VALID | - | 0 | 0.353 | 0 |
| gitleaks | VALID | - | 0 | 0.348 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 5d492b4b947e), strategy S3, run c3f042d1-85f0-4e46-954c-6a8cb3b47b94, engine 2.0.0.dev1._
