## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.235 | 0 |
| pip-audit | VALID | - | 0 | 0.348 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 bf7f9146f414), strategy S1, run c966e69e-de3d-4363-83a4-7bc26c1a95b5, engine 2.0.0.dev1._
