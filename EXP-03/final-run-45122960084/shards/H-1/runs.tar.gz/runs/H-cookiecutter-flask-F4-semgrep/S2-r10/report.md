## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| pip-audit | VALID | - | 0 | 0.352 | 0 |
| gitleaks | VALID | - | 0 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c404a8904162), strategy S2, run efc327f4-eadf-422d-a48d-5025f7a2c380, engine 2.0.0.dev1._
