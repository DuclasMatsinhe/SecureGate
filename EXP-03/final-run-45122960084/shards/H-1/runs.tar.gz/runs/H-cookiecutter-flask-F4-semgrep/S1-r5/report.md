## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.352 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4b27a329e809), strategy S1, run 314bb04a-c24b-463f-ad51-357f486b0eed, engine 2.0.0.dev1._
