## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.203 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.354 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d3a4b3dddf83), strategy S1, run aeb1b0dc-ce73-49b3-9b71-1cf8b0d499b1, engine 2.0.0.dev1._
