## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.351 | 0 |
| gitleaks | VALID | - | 0 | 0.357 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1bc86bfbbb87), strategy S0, run eba34041-4a30-4051-8e1d-33b071a5ab46, engine 2.0.0.dev1._
