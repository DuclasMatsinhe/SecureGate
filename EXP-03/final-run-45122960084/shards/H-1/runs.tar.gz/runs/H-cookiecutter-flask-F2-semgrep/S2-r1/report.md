## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 0.354 | 0 |
| gitleaks | VALID | - | 0 | 0.347 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 84340c10cf86), strategy S2, run a10a6f7e-ff3f-4942-90a9-96a164977a6c, engine 2.0.0.dev1._
