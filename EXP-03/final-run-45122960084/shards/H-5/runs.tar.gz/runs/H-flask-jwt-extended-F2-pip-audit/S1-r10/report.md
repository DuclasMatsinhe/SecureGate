## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/automatic_user_loading.rst:32)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/automatic_user_loading.rst:36)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/basic_usage.rst:46)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/basic_usage.rst:50)
- `BLOCKING_FINDING`: Gitleaks HIGH: private-key (tests/test_asymmetric_crypto.py:10)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.248 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| gitleaks | VALID | - | 3 | 0.4 | 5 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | jwt | docs/basic_usage.rst:46 | - |
| Gitleaks | HIGH | jwt | docs/basic_usage.rst:50 | - |
| Gitleaks | HIGH | jwt | docs/automatic_user_loading.rst:32 | - |
| Gitleaks | HIGH | jwt | docs/automatic_user_loading.rst:36 | - |
| Gitleaks | HIGH | private-key | tests/test_asymmetric_crypto.py:10 | - |

_Policy policy.toml vEXP-02 v1 (sha256 caab99dd9910), strategy S1, run 15a4cc56-ca09-4f91-8e26-f733d4dc9c63, engine 2.0.0.dev1._
