## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/automatic_user_loading.rst:32)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/automatic_user_loading.rst:36)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/basic_usage.rst:46)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/basic_usage.rst:50)
- `BLOCKING_FINDING`: Gitleaks HIGH: private-key (tests/test_asymmetric_crypto.py:10)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.229 | 0 |
| pip-audit | VALID | - | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 3 | 0.395 | 5 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | jwt | docs/basic_usage.rst:46 | - |
| Gitleaks | HIGH | jwt | docs/basic_usage.rst:50 | - |
| Gitleaks | HIGH | jwt | docs/automatic_user_loading.rst:32 | - |
| Gitleaks | HIGH | jwt | docs/automatic_user_loading.rst:36 | - |
| Gitleaks | HIGH | private-key | tests/test_asymmetric_crypto.py:10 | - |

_Policy policy.toml vEXP-02 v1 (sha256 de225c9461b8), strategy S0, run e654f856-0328-44c7-b2d3-74f27611ef6b, engine 2.0.0.dev1._
