## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/automatic_user_loading.rst:32)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/automatic_user_loading.rst:36)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/basic_usage.rst:46)
- `BLOCKING_FINDING`: Gitleaks HIGH: jwt (docs/basic_usage.rst:50)
- `BLOCKING_FINDING`: Gitleaks HIGH: private-key (tests/test_asymmetric_crypto.py:10)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-114134 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-537c-gmf6-5ccf (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-h4gh-qq45-vh27 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-pxh4-856f-4h89 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-48 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2024-48 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1284 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1284 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-176 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-178 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-178 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-179 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2120 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2121 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-35 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-35 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3553 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3553 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3554 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4140 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4144 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4145 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4146 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4147 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4152 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4183 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 1 | 0.368 | 37 |
| gitleaks | VALID | - | 3 | 0.403 | 5 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2024-48 | dependency | - |
| pip-audit | HIGH | PYSEC-2024-48 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2121 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2120 | dependency | - |
| pip-audit | HIGH | CVE-2026-114134 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1284 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-35 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-35 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1284 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-3553 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-3553 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-3554 | dependency | - |
| pip-audit | HIGH | GHSA-h4gh-qq45-vh27 | dependency | - |
| pip-audit | HIGH | GHSA-537c-gmf6-5ccf | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-179 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-175 | dependency | - |

_22 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 8db1418de717), strategy S1, run 9a0fc4fb-1c4b-4fbc-8b07-b74c567d90a1, engine 2.0.0.dev1._
