## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 10764)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.708 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.527 | 0 |
| gitleaks | VALID | - | 0 | 0.557 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0e1f2388668f), strategy S3, run 728d4337-7e13-4815-aec0-9cd5a47e32c5, engine 2.0.0.dev1._
