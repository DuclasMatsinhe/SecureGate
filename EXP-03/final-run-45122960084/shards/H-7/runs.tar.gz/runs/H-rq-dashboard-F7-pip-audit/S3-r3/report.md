## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 10764)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.767 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.529 | 0 |
| gitleaks | VALID | - | 0 | 0.558 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0e1f2388668f), strategy S3, run 222163f9-c3b6-44b8-ae91-0147a84ac686, engine 2.0.0.dev1._
