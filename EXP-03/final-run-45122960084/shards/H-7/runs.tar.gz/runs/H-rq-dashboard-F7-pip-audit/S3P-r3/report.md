## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 10764)
- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (fabfile.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.748 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.532 | 0 |
| gitleaks | VALID | - | 0 | 0.561 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 d5b1dca7fcb0), strategy S3, run 5c29360b-5f02-46ef-b4d6-dccf840fde3a, engine 2.0.0.dev1._
