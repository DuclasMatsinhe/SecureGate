## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.798 | 0 |
| pip-audit | VALID | - | 1 | 0.57 | 0 |
| gitleaks | VALID | - | 0 | 0.579 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 255a9423db8c), strategy S0, run 1b9016b4-24a6-4bd8-9ad6-d4a6c051440d, engine 2.0.0.dev1._
