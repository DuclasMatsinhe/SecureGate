## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 10764)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.746 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.54 | 0 |
| gitleaks | VALID | - | 0 | 0.56 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 429a75ef1d0e), strategy S1, run e739a6ac-32ee-4717-bee7-070eb07a5778, engine 2.0.0.dev1._
