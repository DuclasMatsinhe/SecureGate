## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.709 | 0 |
| pip-audit | VALID | - | 1 | 0.611 | 0 |
| gitleaks | VALID | - | 0 | 0.553 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 255a9423db8c), strategy S0, run ea8638c9-6722-40be-8994-a4490f97cb5b, engine 2.0.0.dev1._
