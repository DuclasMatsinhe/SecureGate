## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.849 | 0 |
| pip-audit | VALID | - | 1 | 0.549 | 0 |
| gitleaks | VALID | - | 0 | 0.557 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 255a9423db8c), strategy S0, run 244ad392-3816-4af8-b62d-777245986864, engine 2.0.0.dev1._
