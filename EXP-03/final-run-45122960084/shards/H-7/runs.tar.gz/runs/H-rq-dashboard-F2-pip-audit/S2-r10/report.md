## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.815 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.032 | 0 |
| gitleaks | VALID | - | 0 | 0.563 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4b072f5ecda2), strategy S2, run ac971e20-d27a-4aee-92b2-9d8af2b9f993, engine 2.0.0.dev1._
