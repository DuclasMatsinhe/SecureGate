## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.776 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.032 | 0 |
| gitleaks | VALID | - | 0 | 0.568 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1ce99ad1e19a), strategy S1, run ca994026-4645-4d88-ae29-8aea759ee9d8, engine 2.0.0.dev1._
