## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.784 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.549 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1ce99ad1e19a), strategy S1, run 0d4a9f87-6aa5-49d8-8ea4-d69ef87286c7, engine 2.0.0.dev1._
