## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `PARTIAL_COVERAGE`: 1 Python file(s) listed by Semgrep as scanned cannot be parsed (fabfile.py); Semgrep reported no error, so their analysis may be incomplete

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 1.743 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.031 | 0 |
| gitleaks | VALID | - | 0 | 0.57 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0802c3cb90af), strategy S3, run f1eb9b2c-895a-4a19-a10c-a9350bfbe4be, engine 2.0.0.dev1._
