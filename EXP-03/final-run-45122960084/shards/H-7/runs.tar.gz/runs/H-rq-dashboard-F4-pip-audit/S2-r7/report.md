## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.707 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.564 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0b253090ca30), strategy S2, run 53d5f508-bc65-4296-8869-33b5527c0290, engine 2.0.0.dev1._
