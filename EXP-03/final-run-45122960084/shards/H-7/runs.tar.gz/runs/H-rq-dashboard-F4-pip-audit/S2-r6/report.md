## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.706 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.56 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0b253090ca30), strategy S2, run e5dd02bc-13cf-4f7d-84be-ef028a1fb145, engine 2.0.0.dev1._
