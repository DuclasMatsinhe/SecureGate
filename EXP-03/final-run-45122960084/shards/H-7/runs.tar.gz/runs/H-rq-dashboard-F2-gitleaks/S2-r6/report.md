## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1472 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1860 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3417 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.743 | 0 |
| pip-audit | VALID | - | 1 | 0.51 | 27 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1472 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1472 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-221 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-221 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2043 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2045 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1860 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2046 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2044 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2320 | dependency | - |

_7 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 2dbc5388e52d), strategy S2, run 632c3a47-b165-4f2a-927b-ff389dda7062, engine 2.0.0.dev1._
