## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/es_sync_config.json:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/full-stack.yml:50)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.408 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.026 | 0 |
| gitleaks | VALID | - | 3 | 0.408 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | .docker/es_sync_config.json:6 | - |
| Gitleaks | HIGH | generic-api-key | .docker/full-stack.yml:50 | - |

_Policy policy.toml vEXP-02 v1 (sha256 fae7297128b5), strategy S2, run 9060ca28-2a05-4f79-8b1a-67d9fc42d496, engine 2.0.0.dev1._
