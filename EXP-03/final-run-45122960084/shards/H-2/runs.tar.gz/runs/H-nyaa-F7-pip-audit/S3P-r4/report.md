## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 38477)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/es_sync_config.json:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/full-stack.yml:50)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.388 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.446 | 0 |
| gitleaks | VALID | - | 3 | 0.412 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | .docker/full-stack.yml:50 | - |
| Gitleaks | HIGH | generic-api-key | .docker/es_sync_config.json:6 | - |

_Policy policy.toml vEXP-02 v1 (sha256 9e9e664a5a1c), strategy S3, run e0314e7f-8a56-413f-bcb1-896023e29734, engine 2.0.0.dev1._
