## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 38477)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/es_sync_config.json:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/full-stack.yml:50)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.43 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.448 | 0 |
| gitleaks | VALID | - | 3 | 0.414 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | .docker/full-stack.yml:50 | - |
| Gitleaks | HIGH | generic-api-key | .docker/es_sync_config.json:6 | - |

_Policy policy.toml vEXP-02 v1 (sha256 23b2b4cbadae), strategy S2, run 3b3be213-41a9-4f25-b412-98d399b1ddfd, engine 2.0.0.dev1._
