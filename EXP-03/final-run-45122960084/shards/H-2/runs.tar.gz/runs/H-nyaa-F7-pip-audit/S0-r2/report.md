## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/es_sync_config.json:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/full-stack.yml:50)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.393 | 0 |
| pip-audit | VALID | - | 1 | 0.447 | 0 |
| gitleaks | VALID | - | 3 | 0.41 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | .docker/es_sync_config.json:6 | - |
| Gitleaks | HIGH | generic-api-key | .docker/full-stack.yml:50 | - |

_Policy policy.toml vEXP-02 v1 (sha256 d65b955f989c), strategy S0, run d5f2bd17-6ff1-4e43-8dca-64bc68e88320, engine 2.0.0.dev1._
