## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 38477)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/es_sync_config.json:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/full-stack.yml:50)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.462 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.452 | 0 |
| gitleaks | VALID | - | 3 | 0.412 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | .docker/es_sync_config.json:6 | - |
| Gitleaks | HIGH | generic-api-key | .docker/full-stack.yml:50 | - |

_Policy policy.toml vEXP-02 v1 (sha256 9e9e664a5a1c), strategy S3, run d6fcaf19-d582-442f-9e2f-52ed4dae6471, engine 2.0.0.dev1._
