## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2021-33026 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-114605 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-128089 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-92 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-92 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-203 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-260 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-260 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-74 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-74 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1058 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1058 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1307 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1845 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1845 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1873 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1873 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.56 | 0 |
| pip-audit | VALID | - | 1 | 0.437 | 78 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.025 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-1307 | dependency | - |
| pip-audit | HIGH | CVE-2026-114605 | dependency | - |
| pip-audit | HIGH | CVE-2026-128089 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-177 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-177 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2022-260 | dependency | - |

_58 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 8a252752b671), strategy S1, run 327346ac-d3de-4bb2-ac5b-98d92c9f462d, engine 2.0.0.dev1._
