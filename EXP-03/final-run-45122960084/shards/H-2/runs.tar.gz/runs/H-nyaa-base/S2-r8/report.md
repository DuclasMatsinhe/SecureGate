## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/es_sync_config.json:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (.docker/full-stack.yml:50)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2021-33026 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-114605 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: CVE-2026-128089 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-148 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-149 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-92 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2020-92 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-66 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-203 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-260 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-260 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-74 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-74 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1058 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1058 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1307 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1471 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1473 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1474 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1475 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1845 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1845 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1872 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1873 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1873 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2275 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2617 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-502 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.553 | 0 |
| pip-audit | VALID | - | 1 | 0.428 | 78 |
| gitleaks | VALID | - | 3 | 0.406 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-1307 | dependency | - |
| pip-audit | HIGH | CVE-2026-114605 | dependency | - |
| pip-audit | HIGH | CVE-2026-128089 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-177 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-177 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-66 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1473 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1471 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1474 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1475 | dependency | - |
| pip-audit | HIGH | PYSEC-2022-260 | dependency | - |

_60 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 3cf8e11468ea), strategy S2, run b8a2b1a7-090b-4f78-91cc-f7fc8216bed6, engine 2.0.0.dev1._
