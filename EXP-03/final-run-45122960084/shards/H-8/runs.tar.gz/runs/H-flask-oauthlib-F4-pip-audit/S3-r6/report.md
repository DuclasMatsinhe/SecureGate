## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: facebook-secret (example/facebook.py:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docs/client.rst:339)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/contrib/experiment-client/douban.py:27)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/douban.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/github.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/reddit.py:9)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:17)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:18)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/weibo.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/test_oauth2/test_password.py:66)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.201 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 3 | 0.4 | 12 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | example/weibo.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/reddit.py:9 | - |
| Gitleaks | HIGH | generic-api-key | docs/client.rst:339 | - |
| Gitleaks | HIGH | generic-api-key | example/douban.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/contrib/experiment-client/douban.py:27 | - |
| Gitleaks | HIGH | generic-api-key | example/github.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:13 | - |
| Gitleaks | HIGH | facebook-secret | example/facebook.py:6 | - |
| Gitleaks | HIGH | generic-api-key | tests/test_oauth2/test_password.py:66 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:17 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:18 | - |

_Policy policy.toml vEXP-02 v1 (sha256 e96d7cc3f8ec), strategy S3, run 1a07c7dd-2b6f-4d7d-b45f-f2a9b8447544, engine 2.0.0.dev1._
