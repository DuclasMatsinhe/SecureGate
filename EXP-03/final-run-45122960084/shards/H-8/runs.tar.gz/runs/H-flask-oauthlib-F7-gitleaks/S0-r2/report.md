## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.251 | 0 |
| pip-audit | VALID | - | 1 | 0.357 | 4 |
| gitleaks | VALID | - | 3 | 0.439 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |

_Policy policy.toml vEXP-02 v1 (sha256 12cc6cf88c72), strategy S0, run d1988c9f-ebbc-4aeb-ac64-febd11792615, engine 2.0.0.dev1._
