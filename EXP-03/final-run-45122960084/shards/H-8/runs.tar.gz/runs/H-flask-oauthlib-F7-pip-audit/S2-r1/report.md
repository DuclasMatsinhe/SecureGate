## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 2183)
- `BLOCKING_FINDING`: Gitleaks HIGH: facebook-secret (example/facebook.py:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docs/client.rst:339)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/contrib/experiment-client/douban.py:27)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/douban.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/github.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/reddit.py:9)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:17)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:18)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/weibo.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/test_oauth2/test_password.py:66)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.21 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.381 | 0 |
| gitleaks | VALID | - | 3 | 0.405 | 12 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | example/weibo.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/github.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/douban.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:17 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:18 | - |
| Gitleaks | HIGH | generic-api-key | docs/client.rst:339 | - |
| Gitleaks | HIGH | generic-api-key | example/reddit.py:9 | - |
| Gitleaks | HIGH | generic-api-key | example/contrib/experiment-client/douban.py:27 | - |
| Gitleaks | HIGH | facebook-secret | example/facebook.py:6 | - |
| Gitleaks | HIGH | generic-api-key | tests/test_oauth2/test_password.py:66 | - |

_Policy policy.toml vEXP-02 v1 (sha256 2f3428e462d6), strategy S2, run 3ccfc049-18b5-44c3-9378-ecfc01371bba, engine 2.0.0.dev1._
