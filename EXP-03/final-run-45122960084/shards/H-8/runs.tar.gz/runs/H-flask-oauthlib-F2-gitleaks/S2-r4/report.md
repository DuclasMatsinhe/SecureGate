## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.192 | 0 |
| pip-audit | VALID | - | 1 | 0.343 | 4 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |

_Policy policy.toml vEXP-02 v1 (sha256 9a17d67b125e), strategy S2, run 23ef0944-e1a1-4d0e-b815-0ce40e10f72f, engine 2.0.0.dev1._
