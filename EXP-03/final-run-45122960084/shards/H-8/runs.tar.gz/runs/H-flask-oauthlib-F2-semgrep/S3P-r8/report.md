## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: facebook-secret (example/facebook.py:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docs/client.rst:339)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/contrib/experiment-client/douban.py:27)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/douban.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/github.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/reddit.py:9)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:17)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:18)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/weibo.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/test_oauth2/test_password.py:66)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 1 | 0.347 | 4 |
| gitleaks | VALID | - | 3 | 0.403 | 12 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |
| Gitleaks | HIGH | generic-api-key | example/weibo.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/douban.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/github.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:13 | - |
| Gitleaks | HIGH | generic-api-key | docs/client.rst:339 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:17 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:18 | - |
| Gitleaks | HIGH | facebook-secret | example/facebook.py:6 | - |
| Gitleaks | HIGH | generic-api-key | example/contrib/experiment-client/douban.py:27 | - |
| Gitleaks | HIGH | generic-api-key | example/reddit.py:9 | - |
| Gitleaks | HIGH | generic-api-key | tests/test_oauth2/test_password.py:66 | - |

_Policy policy.toml vEXP-02 v1 (sha256 f1e757c136ed), strategy S3, run 4844715b-d9ff-4b20-bb6d-ad033b716faa, engine 2.0.0.dev1._
