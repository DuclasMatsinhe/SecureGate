## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1127)
- `BLOCKING_FINDING`: Gitleaks HIGH: facebook-secret (example/facebook.py:6)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (docs/client.rst:339)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/contrib/experiment-client/douban.py:27)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/douban.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:12)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/dropbox.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/github.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/reddit.py:9)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:17)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/twitter.py:18)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (example/weibo.py:13)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (tests/test_oauth2/test_password.py:66)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4114 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.224 | 0 |
| pip-audit | VALID | - | 1 | 0.353 | 4 |
| gitleaks | VALID | - | 3 | 0.407 | 12 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4114 | dependency | - |
| Gitleaks | HIGH | generic-api-key | example/weibo.py:13 | - |
| Gitleaks | HIGH | generic-api-key | docs/client.rst:339 | - |
| Gitleaks | HIGH | generic-api-key | tests/test_oauth2/test_password.py:66 | - |
| Gitleaks | HIGH | generic-api-key | example/contrib/experiment-client/douban.py:27 | - |
| Gitleaks | HIGH | generic-api-key | example/douban.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:12 | - |
| Gitleaks | HIGH | generic-api-key | example/dropbox.py:13 | - |
| Gitleaks | HIGH | generic-api-key | example/github.py:13 | - |
| Gitleaks | HIGH | facebook-secret | example/facebook.py:6 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:17 | - |
| Gitleaks | HIGH | generic-api-key | example/twitter.py:18 | - |
| Gitleaks | HIGH | generic-api-key | example/reddit.py:9 | - |

_Policy policy.toml vEXP-02 v1 (sha256 118bfebf2991), strategy S1, run 0b3f1f7e-9448-4a6f-a87d-1bf05d89f8e1, engine 2.0.0.dev1._
