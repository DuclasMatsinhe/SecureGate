## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.209 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.359 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0efecd230be0), strategy S2, run e9d47d19-76cc-46fc-bdda-6f41394c6434, engine 2.0.0.dev1._
