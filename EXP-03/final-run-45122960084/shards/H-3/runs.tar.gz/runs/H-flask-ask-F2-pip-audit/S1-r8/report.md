## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.207 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.365 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 c68eae6161fa), strategy S1, run a16f4180-7acb-4e2c-a71b-2196346e5af4, engine 2.0.0.dev1._
