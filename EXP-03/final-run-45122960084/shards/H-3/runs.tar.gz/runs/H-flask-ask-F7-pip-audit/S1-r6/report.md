## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 17184)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.366 | 0 |
| gitleaks | VALID | - | 0 | 0.361 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1bbb001f32e6), strategy S1, run 3e06824d-95d6-4bbb-b2fc-2348c52f4199, engine 2.0.0.dev1._
