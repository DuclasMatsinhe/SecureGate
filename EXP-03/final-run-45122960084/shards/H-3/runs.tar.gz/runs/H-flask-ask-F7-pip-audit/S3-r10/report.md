## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 17184)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.223 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.368 | 0 |
| gitleaks | VALID | - | 0 | 0.363 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 84fc44f4165d), strategy S3, run f60baaab-f977-40e9-a8cb-d12eba8099e2, engine 2.0.0.dev1._
