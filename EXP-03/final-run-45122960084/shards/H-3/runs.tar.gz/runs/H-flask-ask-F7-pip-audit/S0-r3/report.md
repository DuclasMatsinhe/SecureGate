## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.264 | 0 |
| pip-audit | VALID | - | 1 | 0.378 | 0 |
| gitleaks | VALID | - | 0 | 0.365 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9f9886729140), strategy S0, run 36a65a7d-0905-463e-b6b9-c8d1a2cc931b, engine 2.0.0.dev1._
