## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 17184)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.218 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.37 | 0 |
| gitleaks | VALID | - | 0 | 0.363 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0db8c6a2fcd7), strategy S3, run 71f8812d-349b-4520-85fb-3c6e1eb7e8a9, engine 2.0.0.dev1._
