## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.244 | 0 |
| pip-audit | VALID | - | 1 | 0.377 | 0 |
| gitleaks | VALID | - | 0 | 0.368 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9f9886729140), strategy S0, run c3ec54be-9528-43e2-930c-178069031aff, engine 2.0.0.dev1._
