## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 17184)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.214 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.372 | 0 |
| gitleaks | VALID | - | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 84fc44f4165d), strategy S3, run f6784876-0685-4220-872f-41f6f926646a, engine 2.0.0.dev1._
