## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-537c-gmf6-5ccf (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-5cpq-8wj7-hf2v (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-jm77-qphf-c4w8 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-23 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-23 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-24 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-24 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-52 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-52 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-203 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-11 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-11 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1283 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1283 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1285 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1285 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2268 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2268 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-35 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-35 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3553 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3554 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-800 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-800 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.25 | 0 |
| pip-audit | VALID | - | 1 | 0.354 | 48 |
| gitleaks | VALID | - | 0 | 0.364 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-52 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-52 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-11 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-800 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1283 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1285 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2141 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-11 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-35 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-35 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-800 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1283 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1285 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2141 | dependency | - |

_28 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 2b13b35fc2eb), strategy S2, run ee87c1fb-e7f0-448f-9803-ed5616005d4f, engine 2.0.0.dev1._
