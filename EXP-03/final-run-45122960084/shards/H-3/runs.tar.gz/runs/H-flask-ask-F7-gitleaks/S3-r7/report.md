## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-537c-gmf6-5ccf (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-5cpq-8wj7-hf2v (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: GHSA-jm77-qphf-c4w8 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-23 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-23 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-24 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-24 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-52 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2018-52 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2021-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2022-203 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-11 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-11 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-221 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-57 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-58 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-62 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1283 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1283 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1285 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1285 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2043 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2044 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2045 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2046 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2151 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2268 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2268 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-2320 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-35 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-35 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3553 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-3554 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4312 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-800 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-800 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.277 | 0 |
| pip-audit | VALID | - | 1 | 0.362 | 48 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.39 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2151 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-52 | dependency | - |
| pip-audit | HIGH | PYSEC-2018-52 | dependency | - |
| pip-audit | HIGH | PYSEC-2021-62 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-11 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-800 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1283 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1285 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2141 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-11 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-35 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-35 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-800 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1283 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1285 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-2141 | dependency | - |

_28 more in run_manifest.json._

_Policy policy.toml vEXP-02 v1 (sha256 6d04a118da02), strategy S3, run 8b780329-fc6d-47fe-9c4d-8656a7d3a4d5, engine 2.0.0.dev1._
