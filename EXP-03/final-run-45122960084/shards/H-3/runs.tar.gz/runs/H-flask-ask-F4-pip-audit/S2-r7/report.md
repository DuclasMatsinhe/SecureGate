## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.236 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| gitleaks | VALID | - | 0 | 0.364 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 a237ea59fd50), strategy S2, run 6a5b5179-d23c-4d05-a2b7-4ad0735c5650, engine 2.0.0.dev1._
