## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.25 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.36 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 1d8e907552f3), strategy S3, run a6d2ec76-eb51-4f41-8982-254f7074b4bc, engine 2.0.0.dev1._
