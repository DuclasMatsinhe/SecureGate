## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.21 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.366 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 939e8bbced0f), strategy S1, run 67249328-8c8b-4baf-89a4-9bdfa050e423, engine 2.0.0.dev1._
