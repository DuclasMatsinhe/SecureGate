## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.313 | 0 |
| pip-audit | VALID | - | 0 | 1.54 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.031 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2430ceb53b46), strategy S0, run 3b293677-6d9b-4e74-8696-7e9036bd4323, engine 2.0.0.dev1._
