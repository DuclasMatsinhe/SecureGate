## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.283 | 0 |
| pip-audit | VALID | - | 0 | 0.495 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9d1032cd7c81), strategy S3, run 2e96f623-fe47-4364-984a-da037d0df0f8, engine 2.0.0.dev1._
