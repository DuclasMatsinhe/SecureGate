## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.373 | 0 |
| pip-audit | VALID | - | 0 | 0.505 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.772 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 61e594f3a69f), strategy S1, run ff419165-5284-4aa0-978a-3df792ee699e, engine 2.0.0.dev1._
