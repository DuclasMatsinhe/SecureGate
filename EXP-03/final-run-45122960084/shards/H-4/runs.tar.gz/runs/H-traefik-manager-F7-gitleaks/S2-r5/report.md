## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.298 | 0 |
| pip-audit | VALID | - | 0 | 0.488 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.755 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 523c551f6730), strategy S2, run 7b61a830-c3a4-4940-a4a8-d83b71cae897, engine 2.0.0.dev1._
