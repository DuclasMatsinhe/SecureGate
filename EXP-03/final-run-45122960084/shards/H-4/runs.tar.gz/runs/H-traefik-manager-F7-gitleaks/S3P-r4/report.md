## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.337 | 0 |
| pip-audit | VALID | - | 0 | 0.503 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.791 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 6598595fc8ce), strategy S3, run e68abe08-a46a-4a25-ae07-006cba870e6f, engine 2.0.0.dev1._
