## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.301 | 0 |
| pip-audit | VALID | - | 0 | 0.49 | 0 |
| gitleaks | VALID | - | 3 | 1.759 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ce1f30800d87), strategy S0, run 635f9b90-7db8-43a0-86bd-3c0fc2cc804a, engine 2.0.0.dev1._
