## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.305 | 0 |
| pip-audit | VALID | - | 0 | 0.495 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.746 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 61e594f3a69f), strategy S1, run 615cb832-adf8-4107-97f8-b105e2bdaaaa, engine 2.0.0.dev1._
