## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: Gitleaks exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.317 | 0 |
| pip-audit | VALID | - | 0 | 0.496 | 0 |
| gitleaks | VALID | - | 3 | 1.768 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 ce1f30800d87), strategy S0, run fbffcba1-0623-40de-9d7b-d1674fbf97e9, engine 2.0.0.dev1._
