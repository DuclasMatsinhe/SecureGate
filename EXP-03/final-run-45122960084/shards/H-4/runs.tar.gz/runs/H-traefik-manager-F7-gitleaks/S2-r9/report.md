## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.313 | 0 |
| pip-audit | VALID | - | 0 | 0.498 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.737 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 523c551f6730), strategy S2, run 7d8f8a33-32c6-4e4d-800f-06bbc6632196, engine 2.0.0.dev1._
