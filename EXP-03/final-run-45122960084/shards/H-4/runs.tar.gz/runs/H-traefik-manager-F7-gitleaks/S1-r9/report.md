## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.448 | 0 |
| pip-audit | VALID | - | 0 | 0.509 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.754 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 61e594f3a69f), strategy S1, run f6f91b08-6076-4eba-bf49-362e5c623c7b, engine 2.0.0.dev1._
