## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.406 | 0 |
| pip-audit | VALID | - | 0 | 0.51 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.784 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 523c551f6730), strategy S2, run 29752b5f-2d52-4424-9ece-d72f90521137, engine 2.0.0.dev1._
