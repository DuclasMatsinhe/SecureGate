## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.288 | 0 |
| pip-audit | VALID | - | 0 | 0.493 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.779 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 523c551f6730), strategy S2, run c66bf594-66dc-4191-9b67-ae2dbdfe5e56, engine 2.0.0.dev1._
