## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.384 | 0 |
| pip-audit | VALID | - | 0 | 0.508 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.75 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7acad985296), strategy S3, run a256ae3c-c26f-48c3-a539-ef0b55284482, engine 2.0.0.dev1._
