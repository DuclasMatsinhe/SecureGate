## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 733)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.286 | 0 |
| pip-audit | VALID | - | 0 | 0.495 | 0 |
| gitleaks | INVALID | INVALID_JSON | 3 | 1.774 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 f7acad985296), strategy S3, run 8b9cf299-f63d-4a8c-80e3-65d8213a9948, engine 2.0.0.dev1._
