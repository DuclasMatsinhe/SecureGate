## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:53)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:56)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.283 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| gitleaks | VALID | - | 3 | 1.717 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:53 | - |
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:56 | - |

_Policy policy.toml vEXP-02 v1 (sha256 8aebf887ed47), strategy S1, run df8a49de-2a04-4a58-9d1d-9346136f4f91, engine 2.0.0.dev1._
