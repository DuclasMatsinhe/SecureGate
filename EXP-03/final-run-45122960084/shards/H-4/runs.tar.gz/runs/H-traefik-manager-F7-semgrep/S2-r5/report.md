## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Expecting ',' delimiter at char 1126)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:53)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:56)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 2.317 | 0 |
| pip-audit | VALID | - | 0 | 0.491 | 0 |
| gitleaks | VALID | - | 3 | 1.742 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:53 | - |
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:56 | - |

_Policy policy.toml vEXP-02 v1 (sha256 6fcda9178595), strategy S2, run 95a22ac1-caf6-40e6-95f4-699c90fa5354, engine 2.0.0.dev1._
