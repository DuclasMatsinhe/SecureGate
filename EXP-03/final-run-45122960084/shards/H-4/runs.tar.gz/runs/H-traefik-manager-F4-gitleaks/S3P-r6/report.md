## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.341 | 0 |
| pip-audit | VALID | - | 0 | 0.507 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.031 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 e6ef8425f05e), strategy S3, run 11755125-5a92-4653-be75-42eee8fb217d, engine 2.0.0.dev1._
