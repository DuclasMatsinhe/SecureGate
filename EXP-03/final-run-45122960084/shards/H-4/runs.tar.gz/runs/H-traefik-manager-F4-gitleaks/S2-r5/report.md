## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.336 | 0 |
| pip-audit | VALID | - | 0 | 0.501 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 93c16a633434), strategy S2, run a281becd-cba3-406a-8a4f-dff72534b958, engine 2.0.0.dev1._
