## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.32 | 0 |
| pip-audit | VALID | - | 0 | 0.501 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9b3481ac3a78), strategy S1, run 688dd017-f150-4155-867f-26ff66039e6c, engine 2.0.0.dev1._
