## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.378 | 0 |
| pip-audit | VALID | - | 0 | 0.505 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 4a956269f391), strategy S3, run ad49d950-afd5-4997-870b-56c5e5b651a5, engine 2.0.0.dev1._
