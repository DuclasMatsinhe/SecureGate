## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:53)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:56)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.296 | 0 |
| pip-audit | VALID | - | 0 | 0.52 | 0 |
| gitleaks | VALID | - | 3 | 1.76 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:53 | - |
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:56 | - |

_Policy policy.toml vEXP-02 v1 (sha256 86ba587d00f7), strategy S0, run e6f094b1-57dc-4401-b971-0cb897ab2963, engine 2.0.0.dev1._
