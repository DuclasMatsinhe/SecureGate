## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Expecting ':' delimiter at char 349)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:53)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:56)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.281 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 0.517 | 0 |
| gitleaks | VALID | - | 3 | 1.736 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:53 | - |
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:56 | - |

_Policy policy.toml vEXP-02 v1 (sha256 72e778bbbb4f), strategy S2, run 34c03130-b14b-49e2-8c29-00738c1352e1, engine 2.0.0.dev1._
