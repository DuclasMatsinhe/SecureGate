## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:53)
- `BLOCKING_FINDING`: Gitleaks HIGH: generic-api-key (scripts/screenshots/capture_setup.mjs:56)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.031 | 0 |
| pip-audit | VALID | - | 0 | 0.499 | 0 |
| gitleaks | VALID | - | 3 | 1.735 | 2 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:53 | - |
| Gitleaks | HIGH | generic-api-key | scripts/screenshots/capture_setup.mjs:56 | - |

_Policy policy.toml vEXP-02 v1 (sha256 4e77951307fc), strategy S3, run c6553ef5-3e0b-4341-bee5-49ff6accb912, engine 2.0.0.dev1._
