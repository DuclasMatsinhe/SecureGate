## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.182 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.343 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 0951a7e25e12), strategy S3, run d46cf2be-14c0-4aaf-9b16-773758c1d7f3, engine 2.0.0.dev1._
