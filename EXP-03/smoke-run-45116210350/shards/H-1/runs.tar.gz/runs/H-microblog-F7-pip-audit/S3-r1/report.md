## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 86204)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.169 | 0 |
| pip-audit | INVALID | INVALID_JSON | 1 | 0.4 | 0 |
| gitleaks | VALID | - | 0 | 0.343 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 2392ca5998f1), strategy S3, run 9c671bb8-74a1-48c8-8935-b0fd5c1e5475, engine 2.0.0.dev1._
