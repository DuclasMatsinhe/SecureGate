## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.172 | 0 |
| pip-audit | VALID | - | 1 | 0.398 | 0 |
| gitleaks | VALID | - | 0 | 0.344 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 7248f9c66341), strategy S0, run 3331db7c-6e80-4fe6-9d0b-9f23bddc1c8c, engine 2.0.0.dev1._
