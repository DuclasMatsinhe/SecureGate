## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.172 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.02 | 0 |
| gitleaks | VALID | - | 0 | 0.351 | 0 |

_Policy policy.toml vEXP-02 v1 (sha256 9038985e3024), strategy S2, run 0cf2cc49-d856-4bc2-b30e-fc1f6794a5a7, engine 2.0.0.dev1._
