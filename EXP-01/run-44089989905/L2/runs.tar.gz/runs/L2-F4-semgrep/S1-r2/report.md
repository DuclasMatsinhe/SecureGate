## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.031 | 0 |
| pip-audit | VALID | - | 0 | 5.517 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vexp01-pilot (sha256 b517072434e5), strategy S1, run f15e2cb1-897f-4bcc-b619-38ccb8f4ec02, engine 2.0.0.dev1._
