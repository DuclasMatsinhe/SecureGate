## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_l2_196qqgb3/not-installed/semgrep'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 5.63 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vexp01-pilot (sha256 6a95df03d218), strategy S1, run 40a212a5-cf45-4e58-ac0f-3d4c79f684e7, engine 2.0.0.dev1._
