## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.69 | 0 |
| pip-audit | VALID | - | 0 | 5.499 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.45 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run aa9cb67b-d402-438b-a10f-1236fff6d50d, engine 2.0.0.dev1._
