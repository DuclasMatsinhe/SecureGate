## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.682 | 0 |
| pip-audit | VALID | - | 0 | 5.539 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.442 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run ef37b3b4-1154-48cb-b652-ffa11f247f35, engine 2.0.0.dev1._
