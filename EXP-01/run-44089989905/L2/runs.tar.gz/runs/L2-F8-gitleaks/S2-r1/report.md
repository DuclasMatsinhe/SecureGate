## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.706 | 0 |
| pip-audit | VALID | - | 0 | 5.51 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.444 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 412b5087-7c49-43c9-abec-e7095f6a9b88, engine 2.0.0.dev1._
