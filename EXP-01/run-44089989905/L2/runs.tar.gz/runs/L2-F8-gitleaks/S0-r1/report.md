## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.709 | 0 |
| pip-audit | VALID | - | 0 | 5.555 | 0 |
| gitleaks | VALID | - | 0 | 0.452 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run f0baaabb-5ca4-44c4-b30e-32bd4f332654, engine 2.0.0.dev1._
