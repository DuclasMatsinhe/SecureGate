## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.661 | 0 |
| pip-audit | VALID | - | 0 | 5.537 | 0 |
| gitleaks | VALID | - | 0 | 0.447 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run e77a38f0-f1c5-461a-bf89-46ca39a9e303, engine 2.0.0.dev1._
