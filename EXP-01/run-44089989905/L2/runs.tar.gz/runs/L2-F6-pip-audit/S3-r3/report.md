## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.744 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.444 | 0 |

_Policy policy.toml vexp01-pilot (sha256 433b7af3d2ec), strategy S3, run 0eb6ded1-16cc-4979-a303-81dc54867125, engine 2.0.0.dev1._
