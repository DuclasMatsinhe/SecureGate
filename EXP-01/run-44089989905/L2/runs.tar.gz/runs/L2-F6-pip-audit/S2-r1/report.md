## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.699 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.451 | 0 |

_Policy policy.toml vexp01-pilot (sha256 5ade87c0fced), strategy S2, run dca0b158-27be-4d3f-ab2c-bd4b0d50853e, engine 2.0.0.dev1._
