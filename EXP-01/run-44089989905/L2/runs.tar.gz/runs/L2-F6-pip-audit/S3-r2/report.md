## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.807 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.031 | 0 |
| gitleaks | VALID | - | 0 | 0.453 | 0 |

_Policy policy.toml vexp01-pilot (sha256 433b7af3d2ec), strategy S3, run b11450bf-bcb7-4e2a-95b2-25530190bad2, engine 2.0.0.dev1._
