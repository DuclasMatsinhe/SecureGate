## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.742 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.031 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vexp01-pilot (sha256 5ade87c0fced), strategy S2, run d279b9d8-d3e7-4575-ac67-06cb1e7cda91, engine 2.0.0.dev1._
