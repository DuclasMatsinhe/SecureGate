## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report. Tool says: ERROR: No matching distribution found for securegate-nonexistent-probe-package==0.0.1

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.805 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 1 | 5.742 | 0 |
| gitleaks | VALID | - | 0 | 0.465 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run 0a94e500-1c55-4f12-a221-f5e98df9406d, engine 2.0.0.dev1._
