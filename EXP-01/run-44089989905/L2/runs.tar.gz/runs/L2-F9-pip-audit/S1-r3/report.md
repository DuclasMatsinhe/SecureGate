## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report. Tool says: ERROR: No matching distribution found for securegate-nonexistent-probe-package==0.0.1

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.773 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 1 | 5.776 | 0 |
| gitleaks | VALID | - | 0 | 0.471 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 672b0f60-6aab-49c3-83b8-cb2882df1d7b, engine 2.0.0.dev1._
