## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.704 | 0 |
| pip-audit | VALID | - | 1 | 5.696 | 0 |
| gitleaks | VALID | - | 0 | 0.452 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run c4a26c44-0375-430f-b09d-12bb8f0448d7, engine 2.0.0.dev1._
