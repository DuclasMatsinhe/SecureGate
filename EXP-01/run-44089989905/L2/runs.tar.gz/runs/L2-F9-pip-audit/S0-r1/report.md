## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `EXIT_CODE_FINDINGS`: pip-audit exit code indicates findings

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.746 | 0 |
| pip-audit | VALID | - | 1 | 5.814 | 0 |
| gitleaks | VALID | - | 0 | 0.458 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run 5ace8c7b-f7e3-4e74-b2b1-e16aa38c39c6, engine 2.0.0.dev1._
