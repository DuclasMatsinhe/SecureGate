## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.758 | 0 |
| pip-audit | VALID | - | 0 | 5.564 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.483 | 0 |

_Policy policy.toml vexp01-pilot (sha256 667883c8b5cd), strategy S2, run 9485d227-db07-41e6-8380-5cf7ccde8731, engine 2.0.0.dev1._
