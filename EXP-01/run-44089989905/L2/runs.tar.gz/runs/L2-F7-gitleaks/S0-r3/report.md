## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.72 | 0 |
| pip-audit | VALID | - | 0 | 5.562 | 0 |
| gitleaks | VALID | - | 0 | 0.48 | 0 |

_Policy policy.toml vexp01-pilot (sha256 3b858338f709), strategy S0, run 9fe01a42-d8cf-486c-a51b-ff4c604d071f, engine 2.0.0.dev1._
