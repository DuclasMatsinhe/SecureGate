## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.689 | 0 |
| pip-audit | VALID | - | 0 | 5.514 | 0 |
| gitleaks | VALID | - | 0 | 0.49 | 0 |

_Policy policy.toml vexp01-pilot (sha256 3b858338f709), strategy S0, run 9b7132bc-1ad7-4c22-a4e0-6955e7f57f34, engine 2.0.0.dev1._
