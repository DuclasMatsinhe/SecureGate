## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.744 | 0 |
| pip-audit | VALID | - | 0 | 5.598 | 0 |
| gitleaks | VALID | - | 0 | 0.492 | 0 |

_Policy policy.toml vexp01-pilot (sha256 3b858338f709), strategy S0, run 06bd5511-0d62-4b9c-aea8-e6ea26969705, engine 2.0.0.dev1._
