## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.732 | 0 |
| pip-audit | VALID | - | 0 | 5.608 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.483 | 0 |

_Policy policy.toml vexp01-pilot (sha256 667883c8b5cd), strategy S2, run aa77383b-536e-4c92-959f-2672ad1504ac, engine 2.0.0.dev1._
