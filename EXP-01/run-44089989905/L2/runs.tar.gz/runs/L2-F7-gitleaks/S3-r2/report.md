## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.702 | 0 |
| pip-audit | VALID | - | 0 | 5.577 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.477 | 0 |

_Policy policy.toml vexp01-pilot (sha256 83be04d9f4d7), strategy S3, run 0e7f505a-706a-48ac-a9bd-70e6fd9cb1f5, engine 2.0.0.dev1._
