## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.734 | 0 |
| pip-audit | VALID | - | 0 | 5.606 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.482 | 0 |

_Policy policy.toml vexp01-pilot (sha256 83be04d9f4d7), strategy S3, run 67b676c9-ef71-4abe-838c-9b39f14fa3c0, engine 2.0.0.dev1._
