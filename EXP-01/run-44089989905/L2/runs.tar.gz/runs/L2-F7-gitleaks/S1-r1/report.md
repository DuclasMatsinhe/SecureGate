## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.712 | 0 |
| pip-audit | VALID | - | 0 | 5.576 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.486 | 0 |

_Policy policy.toml vexp01-pilot (sha256 ee887715e164), strategy S1, run 81548282-15ca-4774-b7bf-088311356450, engine 2.0.0.dev1._
