## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.031 | 0 |
| pip-audit | VALID | - | 0 | 5.616 | 0 |
| gitleaks | VALID | - | 0 | 0.479 | 0 |

_Policy policy.toml vexp01-pilot (sha256 ae0fe28ccc03), strategy S3, run 6b11c588-bd66-48f1-89df-fe0604b5c56a, engine 2.0.0.dev1._
