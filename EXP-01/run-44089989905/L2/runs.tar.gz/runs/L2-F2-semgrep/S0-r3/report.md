## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.033 | 0 |
| pip-audit | VALID | - | 0 | 5.629 | 0 |
| gitleaks | VALID | - | 0 | 0.485 | 0 |

_Policy policy.toml vexp01-pilot (sha256 92a2f563e9ec), strategy S0, run 4899d403-a3d8-40ff-8b7f-ef7e13e17e50, engine 2.0.0.dev1._
