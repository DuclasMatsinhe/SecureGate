## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| pip-audit | VALID | - | 0 | 5.618 | 0 |
| gitleaks | VALID | - | 0 | 0.46 | 0 |

_Policy policy.toml vexp01-pilot (sha256 012cb76a5eec), strategy S1, run 1c69902d-2c59-4e58-908a-894bc32c2c81, engine 2.0.0.dev1._
