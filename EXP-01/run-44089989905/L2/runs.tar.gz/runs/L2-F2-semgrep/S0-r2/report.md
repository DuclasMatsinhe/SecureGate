## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| pip-audit | VALID | - | 0 | 5.622 | 0 |
| gitleaks | VALID | - | 0 | 0.463 | 0 |

_Policy policy.toml vexp01-pilot (sha256 92a2f563e9ec), strategy S0, run 2e4279e6-24c8-4ebc-a17b-6d11b9b788da, engine 2.0.0.dev1._
