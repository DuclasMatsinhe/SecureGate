## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| pip-audit | VALID | - | 0 | 5.618 | 0 |
| gitleaks | VALID | - | 0 | 0.47 | 0 |

_Policy policy.toml vexp01-pilot (sha256 ae0fe28ccc03), strategy S3, run 8d22d60a-cb41-49d9-ac7f-ac862de4b2f2, engine 2.0.0.dev1._
