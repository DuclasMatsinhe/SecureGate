## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.755 | 0 |
| pip-audit | VALID | - | 0 | 5.515 | 0 |
| gitleaks | VALID | - | 0 | 0.448 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 51013c18-24d5-4eda-b0d5-aec301544e5b, engine 2.0.0.dev1._
