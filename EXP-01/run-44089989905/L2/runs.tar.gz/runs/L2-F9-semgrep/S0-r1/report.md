## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.709 | 0 |
| pip-audit | VALID | - | 0 | 5.645 | 0 |
| gitleaks | VALID | - | 0 | 0.451 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run 5a58b293-0334-4709-954f-968bb067d789, engine 2.0.0.dev1._
