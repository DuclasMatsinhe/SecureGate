## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.772 | 0 |
| pip-audit | VALID | - | 0 | 5.58 | 0 |
| gitleaks | VALID | - | 0 | 0.447 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run c4c1c9ce-d075-4b44-9697-4cf481b9509f, engine 2.0.0.dev1._
