## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.793 | 0 |
| pip-audit | VALID | - | 0 | 5.589 | 0 |
| gitleaks | VALID | - | 0 | 0.464 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 0f146b4d-7a8e-44e9-8ae8-2839256a1090, engine 2.0.0.dev1._
