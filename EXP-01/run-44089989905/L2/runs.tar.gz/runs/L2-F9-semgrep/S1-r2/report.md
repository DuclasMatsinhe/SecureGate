## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.685 | 0 |
| pip-audit | VALID | - | 0 | 5.477 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 8b25d6a1-9bc7-41f4-a76b-9e7f10879d1c, engine 2.0.0.dev1._
