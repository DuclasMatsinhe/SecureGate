## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.692 | 0 |
| pip-audit | VALID | - | 0 | 5.524 | 0 |
| gitleaks | VALID | - | 0 | 0.461 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run 6b62b92f-ea55-46f8-91c3-eb5d2f68ecab, engine 2.0.0.dev1._
