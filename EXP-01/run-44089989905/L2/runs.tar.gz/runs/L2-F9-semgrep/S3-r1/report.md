## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.743 | 0 |
| pip-audit | VALID | - | 0 | 5.685 | 0 |
| gitleaks | VALID | - | 0 | 0.454 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run edc009ae-7806-49f2-872e-0ce39965e4b1, engine 2.0.0.dev1._
