## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.737 | 0 |
| pip-audit | VALID | - | 0 | 5.594 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vexp01-pilot (sha256 e8afbce03435), strategy S2, run 9071dc91-f905-4db3-b7f9-b4ea0b93f80d, engine 2.0.0.dev1._
