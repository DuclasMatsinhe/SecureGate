## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.769 | 0 |
| pip-audit | VALID | - | 0 | 5.707 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vexp01-pilot (sha256 ac1c55148185), strategy S1, run 0a2626b3-d3d8-4d2d-b5de-e78804b24f3c, engine 2.0.0.dev1._
