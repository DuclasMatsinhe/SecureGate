## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.74 | 0 |
| pip-audit | VALID | - | 0 | 5.624 | 0 |
| gitleaks | VALID | - | 3 | 0.454 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 9dc5e81d-000a-4eb4-9d69-836fc62bb624, engine 2.0.0.dev1._
