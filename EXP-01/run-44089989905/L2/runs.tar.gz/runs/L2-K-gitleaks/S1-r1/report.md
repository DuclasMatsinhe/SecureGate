## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.706 | 0 |
| pip-audit | VALID | - | 0 | 5.636 | 0 |
| gitleaks | VALID | - | 3 | 0.455 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run d2d3bdec-7f20-4f0a-832c-47e634f3b5e5, engine 2.0.0.dev1._
