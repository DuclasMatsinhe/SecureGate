## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report
- `BLOCKING_FINDING`: Semgrep HIGH: probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 2.047 | 1 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.032 | 0 |
| gitleaks | VALID | - | 0 | 0.473 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | probe-eval | app.py:2 | - |

_Policy policy.toml vexp01-pilot (sha256 0987f5af28a0), strategy S2, run 23243ae3-bc3b-4e87-9feb-16f0944d2d91, engine 2.0.0.dev1._
