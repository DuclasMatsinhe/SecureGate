## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.732 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 5.551 | 0 |
| gitleaks | VALID | - | 0 | 0.448 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 02e58ea8-2e12-4a63-9218-f0dcffa2dce5, engine 2.0.0.dev1._
