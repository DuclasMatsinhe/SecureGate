## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.74 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 5.598 | 0 |
| gitleaks | VALID | - | 0 | 0.479 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run a6f9b478-5f83-47b4-95d6-67fd878b0a6e, engine 2.0.0.dev1._
