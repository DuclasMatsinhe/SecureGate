## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.707 | 0 |
| pip-audit | VALID | - | 0 | 5.472 | 0 |
| gitleaks | VALID | - | 0 | 0.501 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 259f7531-ac33-41c1-a2a3-71542cdaadcd, engine 2.0.0.dev1._
