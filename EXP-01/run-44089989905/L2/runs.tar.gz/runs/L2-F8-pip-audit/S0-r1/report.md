## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.722 | 0 |
| pip-audit | VALID | - | 0 | 5.544 | 0 |
| gitleaks | VALID | - | 0 | 0.45 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run cfbfb52c-1546-49b0-8649-691b7b4982cd, engine 2.0.0.dev1._
