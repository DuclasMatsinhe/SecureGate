## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 5.598 | 0 |
| gitleaks | VALID | - | 0 | 0.457 | 0 |

_Policy policy.toml vexp01-pilot (sha256 6fc9b1d41e55), strategy S1, run c6f858b7-9807-4394-a00e-a3b4dad25a2f, engine 2.0.0.dev1._
