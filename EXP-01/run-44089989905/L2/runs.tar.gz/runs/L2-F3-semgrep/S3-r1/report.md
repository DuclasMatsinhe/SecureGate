## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 5.564 | 0 |
| gitleaks | VALID | - | 0 | 0.453 | 0 |

_Policy policy.toml vexp01-pilot (sha256 4eb1ca0c4dad), strategy S3, run db360c7c-e37a-436e-8ec6-909f75758544, engine 2.0.0.dev1._
