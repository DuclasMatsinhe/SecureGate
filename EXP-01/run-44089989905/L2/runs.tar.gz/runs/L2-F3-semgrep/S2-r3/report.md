## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 5.555 | 0 |
| gitleaks | VALID | - | 0 | 0.449 | 0 |

_Policy policy.toml vexp01-pilot (sha256 690c31a89770), strategy S2, run 75a5cd7e-9867-4209-b4e5-dfbc98dffdae, engine 2.0.0.dev1._
