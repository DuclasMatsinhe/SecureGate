## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 5.543 | 0 |
| gitleaks | VALID | - | 0 | 0.455 | 0 |

_Policy policy.toml vexp01-pilot (sha256 8b9170191f94), strategy S0, run 88185dd8-b7c8-4e44-ad8f-06345259b359, engine 2.0.0.dev1._
