## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.72 | 0 |
| pip-audit | VALID | - | 0 | 5.652 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 90be0e1567d5), strategy S0, run cd478c12-f0df-4f67-92d5-e5e2e2abb2c2, engine 2.0.0.dev1._
