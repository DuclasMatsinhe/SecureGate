## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.734 | 0 |
| pip-audit | VALID | - | 0 | 5.654 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.031 | 0 |

_Policy policy.toml vexp01-pilot (sha256 eeb142f36af2), strategy S1, run 4b685000-af27-41d7-ae65-c45c3e6ac5c4, engine 2.0.0.dev1._
