## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.682 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.45 | 0 |

_Policy policy.toml vexp01-pilot (sha256 4c046d223d65), strategy S3, run 8ab85177-3e43-4641-87d9-2a8def2910b0, engine 2.0.0.dev1._
