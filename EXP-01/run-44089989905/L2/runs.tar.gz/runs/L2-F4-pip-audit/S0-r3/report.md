## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.743 | 0 |
| pip-audit | VALID | - | 0 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.452 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0409ee27caf9), strategy S0, run 281c4f55-836d-4524-bd54-c9ffd3123937, engine 2.0.0.dev1._
