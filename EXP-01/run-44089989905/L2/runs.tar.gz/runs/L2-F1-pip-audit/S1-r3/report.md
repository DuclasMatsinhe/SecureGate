## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_l2_196qqgb3/not-installed/pip-audit'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.71 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.441 | 0 |

_Policy policy.toml vexp01-pilot (sha256 cac4ef25a662), strategy S1, run f69e8b36-f5b9-41c2-9f0a-37151885e8e8, engine 2.0.0.dev1._
