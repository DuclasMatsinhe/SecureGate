## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_l2_196qqgb3/not-installed/pip-audit'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.695 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.45 | 0 |

_Policy policy.toml vexp01-pilot (sha256 bf6a4efa8438), strategy S0, run b3c25c65-b999-4f23-8696-02a71c613d57, engine 2.0.0.dev1._
