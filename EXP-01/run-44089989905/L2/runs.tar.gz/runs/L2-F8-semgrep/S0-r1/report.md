## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.716 | 0 |
| pip-audit | VALID | - | 0 | 5.5 | 0 |
| gitleaks | VALID | - | 0 | 0.449 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run cea788a0-6237-47a4-ab40-86231731d036, engine 2.0.0.dev1._
