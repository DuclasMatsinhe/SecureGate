## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.682 | 0 |
| pip-audit | VALID | - | 0 | 5.494 | 0 |
| gitleaks | VALID | - | 0 | 0.452 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run ca14c9b9-4dc9-4483-880f-5f7a35196e52, engine 2.0.0.dev1._
