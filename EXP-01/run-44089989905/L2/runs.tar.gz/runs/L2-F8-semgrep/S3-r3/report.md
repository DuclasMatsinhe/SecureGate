## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Semgrep reports that it scanned 0 files

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_COVERAGE | 0 | 1.699 | 0 |
| pip-audit | VALID | - | 0 | 5.512 | 0 |
| gitleaks | VALID | - | 0 | 0.447 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run b1ab4978-f0cb-479e-b9c4-86f42b5d824d, engine 2.0.0.dev1._
