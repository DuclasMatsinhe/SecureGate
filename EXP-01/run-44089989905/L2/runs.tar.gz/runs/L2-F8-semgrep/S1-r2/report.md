## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.69 | 0 |
| pip-audit | VALID | - | 0 | 5.528 | 0 |
| gitleaks | VALID | - | 0 | 0.448 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 47bab524-73c3-4d4c-84fa-9fb51f66cf13, engine 2.0.0.dev1._
