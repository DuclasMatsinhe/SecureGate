## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_l2_196qqgb3/not-installed/gitleaks'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.712 | 0 |
| pip-audit | VALID | - | 0 | 5.523 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.001 | 0 |

_Policy policy.toml vexp01-pilot (sha256 4592700c2011), strategy S0, run 894957cb-377d-471f-99bf-96e32dce4950, engine 2.0.0.dev1._
