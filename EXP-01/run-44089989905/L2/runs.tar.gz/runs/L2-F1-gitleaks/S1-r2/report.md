## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_l2_196qqgb3/not-installed/gitleaks'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.728 | 0 |
| pip-audit | VALID | - | 0 | 5.596 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2905b935df8b), strategy S1, run b7f0e633-f600-4bb4-9312-d10d901791e7, engine 2.0.0.dev1._
