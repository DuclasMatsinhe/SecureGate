## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_l2_196qqgb3/not-installed/gitleaks'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.688 | 0 |
| pip-audit | VALID | - | 0 | 5.546 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vexp01-pilot (sha256 9d08e56021a9), strategy S2, run 31aefaf5-5675-4bfa-b1a1-d7575e851b86, engine 2.0.0.dev1._
