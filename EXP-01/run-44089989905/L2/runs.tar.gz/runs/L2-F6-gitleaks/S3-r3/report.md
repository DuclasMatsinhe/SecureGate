## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.721 | 0 |
| pip-audit | VALID | - | 0 | 5.579 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 7e5bddcfce4b), strategy S3, run 27bc9436-9f58-47be-a471-a5fcb8071db7, engine 2.0.0.dev1._
