## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.805 | 0 |
| pip-audit | VALID | - | 0 | 5.542 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 727d8cc302ec), strategy S1, run b98384b2-ca57-4ceb-9203-f8a58e2519bf, engine 2.0.0.dev1._
