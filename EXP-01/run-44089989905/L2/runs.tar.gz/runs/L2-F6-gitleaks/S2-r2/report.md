## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.695 | 0 |
| pip-audit | VALID | - | 0 | 5.532 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 506a54efce8b), strategy S2, run 9954d5c7-9116-4d1d-9068-17754e00a9f7, engine 2.0.0.dev1._
