## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.798 | 0 |
| pip-audit | VALID | - | 0 | 5.53 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.031 | 0 |

_Policy policy.toml vexp01-pilot (sha256 7e5bddcfce4b), strategy S3, run 48e4678c-de5b-46d7-9f03-2de0999923ca, engine 2.0.0.dev1._
