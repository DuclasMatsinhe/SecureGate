## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.696 | 0 |
| pip-audit | VALID | - | 0 | 5.529 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.031 | 0 |

_Policy policy.toml vexp01-pilot (sha256 7e5bddcfce4b), strategy S3, run aa58d6d3-1eee-4a3b-880b-d57df5442b1a, engine 2.0.0.dev1._
