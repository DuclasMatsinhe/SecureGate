## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.7 | 0 |
| pip-audit | VALID | - | 0 | 5.537 | 0 |
| gitleaks | VALID | - | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 3958faa924c1), strategy S0, run c779ff2f-1952-4ad6-9af8-9f8b3f077226, engine 2.0.0.dev1._
