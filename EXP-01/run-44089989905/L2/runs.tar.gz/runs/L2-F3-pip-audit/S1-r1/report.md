## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: pip-audit: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.692 | 0 |
| pip-audit | INVALID | TIMEOUT | None | 3.005 | 0 |
| gitleaks | VALID | - | 0 | 0.442 | 0 |

_Policy policy.toml vexp01-pilot (sha256 93b0de31c619), strategy S1, run 6f8089f9-31bc-4a16-b5ea-b80119ee035e, engine 2.0.0.dev1._
