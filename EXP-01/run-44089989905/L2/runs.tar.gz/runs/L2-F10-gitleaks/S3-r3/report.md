## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:59PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 1:59PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.787 | 0 |
| pip-audit | VALID | - | 0 | 5.686 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.302 | 0 |

_Policy policy.toml vexp01-pilot (sha256 817b8ff09615), strategy S3, run 2ffa3758-963d-4f37-96d7-32930ff7f672, engine 2.0.0.dev1._
