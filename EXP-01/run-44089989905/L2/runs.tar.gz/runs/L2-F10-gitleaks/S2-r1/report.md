## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:58PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 1:58PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.802 | 0 |
| pip-audit | VALID | - | 0 | 5.727 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.302 | 0 |

_Policy policy.toml vexp01-pilot (sha256 5cd2df24a4a4), strategy S2, run e7bc3b83-9b9b-42b4-a9ac-bf537d3bdcaf, engine 2.0.0.dev1._
