## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:57PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.841 | 0 |
| pip-audit | VALID | - | 0 | 5.647 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.292 | 0 |

_Policy policy.toml vexp01-pilot (sha256 451cb8be78f7), strategy S0, run 929430b8-205f-428a-ab93-8d067ceb0436, engine 2.0.0.dev1._
