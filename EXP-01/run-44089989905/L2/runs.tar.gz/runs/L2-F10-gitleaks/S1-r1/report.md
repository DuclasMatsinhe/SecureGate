## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:58PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 1:58PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.81 | 0 |
| pip-audit | VALID | - | 0 | 5.748 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.292 | 0 |

_Policy policy.toml vexp01-pilot (sha256 a140012ab8f4), strategy S1, run 2ee02d83-feb5-4135-830d-b80b915bcbdb, engine 2.0.0.dev1._
