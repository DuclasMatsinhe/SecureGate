## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.734 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.451 | 0 |

_Policy policy.toml vexp01-pilot (sha256 a6bad0f416c5), strategy S3, run 157b3eb6-70e0-4767-ab20-ddbcca992724, engine 2.0.0.dev1._
