## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.728 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.03 | 0 |
| gitleaks | VALID | - | 0 | 0.444 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0987f5af28a0), strategy S2, run afafa6e4-d2df-48fe-b085-4dd38a4e4a64, engine 2.0.0.dev1._
