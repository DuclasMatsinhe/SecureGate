## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 650)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.769 | 0 |
| pip-audit | VALID | - | 0 | 5.583 | 0 |
| gitleaks | VALID | - | 0 | 0.456 | 0 |

_Policy policy.toml vexp01-pilot (sha256 f012494e4e1a), strategy S3, run 4cabfbea-3ff4-4fa2-8f41-6a25747a372d, engine 2.0.0.dev1._
