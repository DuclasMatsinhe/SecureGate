## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 650)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.759 | 0 |
| pip-audit | VALID | - | 0 | 5.531 | 0 |
| gitleaks | VALID | - | 0 | 0.46 | 0 |

_Policy policy.toml vexp01-pilot (sha256 773e14a8060d), strategy S2, run 03d5e1d3-60f2-4f23-96e4-bba7907c8bc4, engine 2.0.0.dev1._
