## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.764 | 0 |
| pip-audit | VALID | - | 0 | 5.549 | 0 |
| gitleaks | VALID | - | 0 | 0.45 | 0 |

_Policy policy.toml vexp01-pilot (sha256 620c6bba1704), strategy S0, run ef5355a8-99f8-4818-aa67-30d0229c4992, engine 2.0.0.dev1._
