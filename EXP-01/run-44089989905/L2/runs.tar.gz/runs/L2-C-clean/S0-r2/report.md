## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.749 | 0 |
| pip-audit | VALID | - | 0 | 5.702 | 0 |
| gitleaks | VALID | - | 0 | 0.461 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run f87f8695-ab4a-4b75-a17b-f038ec75eb33, engine 2.0.0.dev1._
