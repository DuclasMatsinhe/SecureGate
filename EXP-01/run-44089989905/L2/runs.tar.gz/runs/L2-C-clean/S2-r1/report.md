## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.821 | 0 |
| pip-audit | VALID | - | 0 | 5.735 | 0 |
| gitleaks | VALID | - | 0 | 0.455 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 0b3090a5-79d3-442a-a63c-d050d58e586d, engine 2.0.0.dev1._
