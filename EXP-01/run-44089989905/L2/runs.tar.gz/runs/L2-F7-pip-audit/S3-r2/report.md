## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.697 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 5.544 | 0 |
| gitleaks | VALID | - | 0 | 0.458 | 0 |

_Policy policy.toml vexp01-pilot (sha256 f8249b7a111a), strategy S3, run 142bb45e-3ddd-4b35-bb8a-fd86ec449b85, engine 2.0.0.dev1._
