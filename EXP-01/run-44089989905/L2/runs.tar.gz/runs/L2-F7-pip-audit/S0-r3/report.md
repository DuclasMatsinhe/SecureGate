## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.785 | 0 |
| pip-audit | VALID | - | 0 | 5.519 | 0 |
| gitleaks | VALID | - | 0 | 0.447 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0eb3a40d13e3), strategy S0, run 41cfec83-4030-4041-916b-1c3d92e0e6fb, engine 2.0.0.dev1._
