## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: pip-audit report is not valid JSON (Unterminated string starting at at char 34)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.715 | 0 |
| pip-audit | INVALID | INVALID_JSON | 0 | 5.56 | 0 |
| gitleaks | VALID | - | 0 | 0.456 | 0 |

_Policy policy.toml vexp01-pilot (sha256 f8249b7a111a), strategy S3, run 3ec5455c-39ab-4151-af4c-336cc30498cc, engine 2.0.0.dev1._
