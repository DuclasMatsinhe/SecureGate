## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.773 | 1 |
| pip-audit | VALID | - | 0 | 5.585 | 0 |
| gitleaks | VALID | - | 0 | 0.457 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | probe-eval | app.py:2 | - |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 6d2937bc-ea3e-463d-a334-19e026f68d5e, engine 2.0.0.dev1._
