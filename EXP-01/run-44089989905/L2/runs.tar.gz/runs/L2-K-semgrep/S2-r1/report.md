## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.786 | 1 |
| pip-audit | VALID | - | 0 | 5.673 | 0 |
| gitleaks | VALID | - | 0 | 0.462 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | probe-eval | app.py:2 | - |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 4829c822-da9b-4b7c-a1ed-8c7a5570f0fb, engine 2.0.0.dev1._
