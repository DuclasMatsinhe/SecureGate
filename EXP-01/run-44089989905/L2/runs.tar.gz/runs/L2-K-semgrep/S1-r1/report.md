## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.725 | 1 |
| pip-audit | VALID | - | 0 | 5.551 | 0 |
| gitleaks | VALID | - | 0 | 0.448 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | probe-eval | app.py:2 | - |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 79d1e2ab-4dd1-41d9-9b69-7e91cdbbddf8, engine 2.0.0.dev1._
