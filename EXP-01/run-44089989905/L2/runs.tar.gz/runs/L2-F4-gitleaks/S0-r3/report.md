## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.774 | 0 |
| pip-audit | VALID | - | 0 | 5.495 | 0 |
| gitleaks | VALID | - | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 a2076c591c91), strategy S0, run f06ec1e2-ef7f-4219-be85-7cf8ccfdffbf, engine 2.0.0.dev1._
