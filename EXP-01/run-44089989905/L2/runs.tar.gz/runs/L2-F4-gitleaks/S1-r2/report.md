## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.784 | 0 |
| pip-audit | VALID | - | 0 | 5.542 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 03091c9f2413), strategy S1, run 8d2e781e-afae-45fd-8305-366997b294bf, engine 2.0.0.dev1._
