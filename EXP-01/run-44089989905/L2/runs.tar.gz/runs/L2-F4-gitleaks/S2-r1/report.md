## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.841 | 0 |
| pip-audit | VALID | - | 0 | 5.51 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.032 | 0 |

_Policy policy.toml vexp01-pilot (sha256 8396a13d4970), strategy S2, run e313c88f-acf1-4875-aebb-9d82a176387c, engine 2.0.0.dev1._
