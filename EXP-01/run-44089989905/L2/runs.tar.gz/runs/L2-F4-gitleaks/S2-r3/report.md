## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.718 | 0 |
| pip-audit | VALID | - | 0 | 5.528 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.031 | 0 |

_Policy policy.toml vexp01-pilot (sha256 8396a13d4970), strategy S2, run 09d6fe9c-5a9a-433a-b8e2-a2ae03bacb90, engine 2.0.0.dev1._
