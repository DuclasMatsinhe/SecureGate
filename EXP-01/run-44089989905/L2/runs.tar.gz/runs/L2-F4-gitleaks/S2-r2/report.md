## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.699 | 0 |
| pip-audit | VALID | - | 0 | 5.517 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.03 | 0 |

_Policy policy.toml vexp01-pilot (sha256 8396a13d4970), strategy S2, run 89d7a363-b510-4ff0-a1d6-11665be3821a, engine 2.0.0.dev1._
