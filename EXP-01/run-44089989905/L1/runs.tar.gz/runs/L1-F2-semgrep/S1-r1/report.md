## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 0aba01b4cf14), strategy S1, run bc8a20bc-9554-4836-8b4c-57cd14db07ee, engine 2.0.0.dev1._
