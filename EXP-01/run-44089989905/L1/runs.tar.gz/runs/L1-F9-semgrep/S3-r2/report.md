## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `PARTIAL_COVERAGE`: Semgrep could not analyse 1 file(s) (broken.py)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | PARTIAL_COVERAGE | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 4ce99317fb58), strategy S3, run 37c53d31-5ad0-41d9-aff6-d0cffd76bfe9, engine 2.0.0.dev1._
