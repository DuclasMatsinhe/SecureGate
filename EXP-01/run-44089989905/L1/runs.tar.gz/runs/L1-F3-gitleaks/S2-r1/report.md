## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: injected (L1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 0.0 | 0 |

_Policy inline v1.0 (sha256 d134df70270f), strategy S2, run 8f4b5c7b-6b0f-4744-9b05-6a1e5dc96bfc, engine 2.0.0.dev1._
