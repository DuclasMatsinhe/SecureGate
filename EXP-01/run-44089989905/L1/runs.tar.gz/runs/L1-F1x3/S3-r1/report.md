## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Gitleaks: injected (L1)
- `TOOL_MISSING`: pip-audit: injected (L1)
- `TOOL_MISSING`: Semgrep: injected (L1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy inline v1.0 (sha256 4ce99317fb58), strategy S3, run 89ca3e3e-a6ca-4631-810a-e8c69032dddc, engine 2.0.0.dev1._
