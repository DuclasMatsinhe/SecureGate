## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.0 | 0 |

_Policy inline v1.0 (sha256 0aba01b4cf14), strategy S1, run 7c28bdbb-dab9-44ba-b121-ac446e018780, engine 2.0.0.dev1._
