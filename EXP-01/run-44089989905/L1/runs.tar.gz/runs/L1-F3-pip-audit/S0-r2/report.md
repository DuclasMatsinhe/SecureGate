## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: pip-audit: injected (L1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | INVALID | TIMEOUT | None | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 f3180d3d6d91), strategy S0, run 082ecb46-19b0-4fa2-85f4-e6e562bb9d9f, engine 2.0.0.dev1._
