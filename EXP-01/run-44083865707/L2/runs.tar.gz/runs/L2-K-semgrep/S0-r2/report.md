## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Semgrep HIGH: probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.205 | 1 |
| pip-audit | VALID | - | 0 | 3.639 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | probe-eval | app.py:2 | - |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run 4ee5a47f-c1c1-436c-b6c2-cff3fe8b1e1b, engine 2.0.0.dev1._
