## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.206 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 3.624 | 0 |
| gitleaks | VALID | - | 0 | 0.328 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run 0730bdb2-c774-4a59-92ce-53bee66d0413, engine 2.0.0.dev1._
