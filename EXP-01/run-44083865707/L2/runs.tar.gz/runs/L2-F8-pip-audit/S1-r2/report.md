## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.193 | 0 |
| pip-audit | VALID | - | 0 | 3.62 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 03fb3cb8-3f05-402b-8c78-cd3ea26cdb7e, engine 2.0.0.dev1._
