## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: pip-audit audited no dependencies

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.21 | 0 |
| pip-audit | INVALID | NO_COVERAGE | 0 | 3.654 | 0 |
| gitleaks | VALID | - | 0 | 0.339 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run f9e8167d-f196-4650-83e4-87f809bd6cda, engine 2.0.0.dev1._
