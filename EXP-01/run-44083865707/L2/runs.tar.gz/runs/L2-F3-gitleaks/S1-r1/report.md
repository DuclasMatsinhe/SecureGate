## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.203 | 0 |
| pip-audit | VALID | - | 0 | 3.644 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.004 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d5b0f71a81ee), strategy S1, run 1e02fc82-a1c0-4b73-a685-0f30c0ccb737, engine 2.0.0.dev1._
