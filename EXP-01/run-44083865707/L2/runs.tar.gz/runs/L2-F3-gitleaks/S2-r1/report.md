## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.196 | 0 |
| pip-audit | VALID | - | 0 | 3.666 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vexp01-pilot (sha256 23e5105f8745), strategy S2, run d0afd514-c295-4d6f-89af-3d7fad0252ca, engine 2.0.0.dev1._
