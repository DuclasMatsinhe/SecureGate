## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: Gitleaks: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.219 | 0 |
| pip-audit | VALID | - | 0 | 3.684 | 0 |
| gitleaks | INVALID | TIMEOUT | None | 3.005 | 0 |

_Policy policy.toml vexp01-pilot (sha256 b97963486231), strategy S3, run 86b3eac6-4092-44ca-9911-b89d0b9be8b0, engine 2.0.0.dev1._
