## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.239 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| gitleaks | VALID | - | 0 | 0.334 | 0 |

_Policy policy.toml vexp01-pilot (sha256 047a0fb8bf6b), strategy S1, run b0b01f1d-79af-4c5c-9735-8773dec1d43b, engine 2.0.0.dev1._
