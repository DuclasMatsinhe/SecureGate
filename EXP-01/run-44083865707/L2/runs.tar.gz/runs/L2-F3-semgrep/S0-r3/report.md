## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 3.627 | 0 |
| gitleaks | VALID | - | 0 | 0.328 | 0 |

_Policy policy.toml vexp01-pilot (sha256 7e82a261700d), strategy S0, run 9f235d82-14c3-45c2-9bea-f080dda01ab3, engine 2.0.0.dev1._
