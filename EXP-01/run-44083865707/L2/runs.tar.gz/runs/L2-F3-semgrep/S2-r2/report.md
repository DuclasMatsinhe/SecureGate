## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TIMEOUT`: Semgrep: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TIMEOUT | None | 3.005 | 0 |
| pip-audit | VALID | - | 0 | 3.656 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2b8b6f909f3e), strategy S2, run 3f3dd023-e73d-4d95-b73b-f49330ac1794, engine 2.0.0.dev1._
