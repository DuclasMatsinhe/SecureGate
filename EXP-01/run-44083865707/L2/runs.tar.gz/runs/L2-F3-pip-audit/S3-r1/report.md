## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TIMEOUT`: pip-audit: Exceeded the 3 s timeout and was stopped.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 0 |
| pip-audit | INVALID | TIMEOUT | None | 3.005 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

_Policy policy.toml vexp01-pilot (sha256 9d8a9c790df7), strategy S3, run 678c280e-5095-4871-b2be-c2c44167f097, engine 2.0.0.dev1._
