## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.197 | 0 |
| pip-audit | VALID | - | 1 | 3.655 | 18 |
| gitleaks | VALID | - | 0 | 0.337 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4177 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4175 | dependency | - |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run 8624c17f-bbdc-490d-9cab-2246df7b267c, engine 2.0.0.dev1._
