## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Semgrep exited with code 2; expected [0]
- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 3.688 | 0 |
| gitleaks | VALID | - | 0 | 0.338 | 0 |

_Policy policy.toml vexp01-pilot (sha256 cfa20afe9691), strategy S3, run 283719f8-f713-468d-b1e9-9b991e9e8b7e, engine 2.0.0.dev1._
