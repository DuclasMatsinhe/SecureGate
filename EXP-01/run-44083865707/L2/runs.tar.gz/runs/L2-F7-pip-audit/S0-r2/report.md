## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.201 | 0 |
| pip-audit | VALID | - | 0 | 3.685 | 0 |
| gitleaks | VALID | - | 0 | 0.34 | 0 |

_Policy policy.toml vexp01-pilot (sha256 4e27291a49f3), strategy S0, run bba71fed-e40e-464e-9173-b98c080c11a9, engine 2.0.0.dev1._
