## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.237 | 0 |
| pip-audit | VALID | - | 0 | 3.741 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |

_Policy policy.toml vexp01-pilot (sha256 10197a3ab1dc), strategy S1, run aea4f28c-1e66-4910-9562-1b14d980d21d, engine 2.0.0.dev1._
