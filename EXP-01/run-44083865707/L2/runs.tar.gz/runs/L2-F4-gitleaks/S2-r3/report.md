## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.233 | 0 |
| pip-audit | VALID | - | 0 | 3.697 | 0 |
| gitleaks | INVALID | NO_OUTPUT | 0 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 67f878edebda), strategy S2, run c0047db8-f5e8-4d28-8480-69090661e8e9, engine 2.0.0.dev1._
