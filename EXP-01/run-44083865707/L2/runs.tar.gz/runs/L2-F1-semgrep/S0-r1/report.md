## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_l2_2b671p8k/not-installed/semgrep'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 3.697 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2d6fee9d9be5), strategy S0, run 773796b0-5b8d-433a-8350-3ba2e22bc262, engine 2.0.0.dev1._
