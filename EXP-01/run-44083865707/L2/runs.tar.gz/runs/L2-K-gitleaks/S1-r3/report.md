## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.194 | 0 |
| pip-audit | VALID | - | 0 | 3.641 | 0 |
| gitleaks | VALID | - | 3 | 0.334 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run 04e41a07-e80c-4520-be68-b87408be39fc, engine 2.0.0.dev1._
