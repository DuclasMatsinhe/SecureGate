## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.212 | 0 |
| pip-audit | VALID | - | 0 | 3.662 | 0 |
| gitleaks | VALID | - | 3 | 0.337 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 84fe72f9-2228-44c8-9af4-c1c1b5458393, engine 2.0.0.dev1._
