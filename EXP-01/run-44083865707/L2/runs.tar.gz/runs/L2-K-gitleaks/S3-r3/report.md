## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `BLOCKING_FINDING`: Gitleaks HIGH: github-pat (settings.py:1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.214 | 0 |
| pip-audit | VALID | - | 0 | 3.642 | 0 |
| gitleaks | VALID | - | 3 | 0.341 | 1 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Gitleaks | HIGH | github-pat | settings.py:1 | - |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run 06f9064c-57be-4bbe-a9f0-c0e536469d16, engine 2.0.0.dev1._
