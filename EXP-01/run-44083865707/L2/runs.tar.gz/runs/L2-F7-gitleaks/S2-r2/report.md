## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.207 | 0 |
| pip-audit | VALID | - | 0 | 3.656 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.353 | 0 |

_Policy policy.toml vexp01-pilot (sha256 391266faf5f0), strategy S2, run f96274b2-edf7-4dd8-869a-3c86ad6ddfee, engine 2.0.0.dev1._
