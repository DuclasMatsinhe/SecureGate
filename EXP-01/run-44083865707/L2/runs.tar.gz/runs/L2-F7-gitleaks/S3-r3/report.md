## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.233 | 0 |
| pip-audit | VALID | - | 0 | 3.689 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.356 | 0 |

_Policy policy.toml vexp01-pilot (sha256 3695beee7e11), strategy S3, run c640f975-7163-47e0-a61b-e331ba169750, engine 2.0.0.dev1._
