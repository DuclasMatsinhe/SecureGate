## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.198 | 0 |
| pip-audit | VALID | - | 0 | 3.621 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.356 | 0 |

_Policy policy.toml vexp01-pilot (sha256 e41a2d18e532), strategy S1, run 3e8eb1f5-f50a-4042-b0e9-5c7758c1c924, engine 2.0.0.dev1._
