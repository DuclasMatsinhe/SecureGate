## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.2 | 0 |
| pip-audit | VALID | - | 0 | 3.655 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.355 | 0 |

_Policy policy.toml vexp01-pilot (sha256 e41a2d18e532), strategy S1, run 50fd01bc-f592-4398-b38e-77059b20999e, engine 2.0.0.dev1._
