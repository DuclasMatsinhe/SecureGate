## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.191 | 0 |
| pip-audit | VALID | - | 0 | 3.638 | 0 |
| gitleaks | VALID | - | 0 | 0.355 | 0 |

_Policy policy.toml vexp01-pilot (sha256 62b0b8f53b47), strategy S0, run 722be688-8d27-4ce9-9640-6c484dabef16, engine 2.0.0.dev1._
