## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.204 | 0 |
| pip-audit | VALID | - | 0 | 3.626 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.355 | 0 |

_Policy policy.toml vexp01-pilot (sha256 391266faf5f0), strategy S2, run db7f5603-5acc-46a7-a440-f0c33396c1c7, engine 2.0.0.dev1._
