## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.2 | 0 |
| pip-audit | VALID | - | 0 | 3.662 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.355 | 0 |

_Policy policy.toml vexp01-pilot (sha256 3695beee7e11), strategy S3, run ca86e270-f6e5-4df6-b77d-fc72fe8a194b, engine 2.0.0.dev1._
