## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Gitleaks report is not valid JSON (Expecting value at char 1)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 0 |
| pip-audit | VALID | - | 0 | 3.645 | 0 |
| gitleaks | INVALID | INVALID_JSON | 0 | 0.354 | 0 |

_Policy policy.toml vexp01-pilot (sha256 391266faf5f0), strategy S2, run fbed7c62-32cd-46e0-b5d8-d1c3a96da6ae, engine 2.0.0.dev1._
