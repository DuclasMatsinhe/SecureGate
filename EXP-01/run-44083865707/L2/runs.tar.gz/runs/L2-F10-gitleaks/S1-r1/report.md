## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:04PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 1:04PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.193 | 0 |
| pip-audit | VALID | - | 0 | 3.612 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.215 | 0 |

_Policy policy.toml vexp01-pilot (sha256 e55ca35bcda7), strategy S1, run af6cf0b2-5fab-464d-9893-f5b5907ac6c4, engine 2.0.0.dev1._
