## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:04PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.188 | 0 |
| pip-audit | VALID | - | 0 | 3.611 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.217 | 0 |

_Policy policy.toml vexp01-pilot (sha256 8a482b4d7cac), strategy S0, run 64504e98-acc6-4c5f-88e5-742a3778e03d, engine 2.0.0.dev1._
