## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:04PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 1:04PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.213 | 0 |
| pip-audit | VALID | - | 0 | 3.669 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.219 | 0 |

_Policy policy.toml vexp01-pilot (sha256 7374ded5d9b1), strategy S2, run 3d024249-8573-40f2-af9c-7a94d4f55e27, engine 2.0.0.dev1._
