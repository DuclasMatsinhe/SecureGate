## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: 1:05PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number
- `NO_OUTPUT`: Gitleaks produced no report. Tool says: 1:05PM FTL unable to load gitleaks config, err: While parsing config: toml: incomplete number

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.2 | 0 |
| pip-audit | VALID | - | 0 | 3.678 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.22 | 0 |

_Policy policy.toml vexp01-pilot (sha256 88db3d748630), strategy S3, run e529139f-c7fe-41e2-83b9-5c11f61622d2, engine 2.0.0.dev1._
