## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.196 | 0 |
| pip-audit | VALID | - | 0 | 3.63 | 0 |
| gitleaks | VALID | - | 0 | 0.331 | 0 |

_Policy policy.toml vexp01-pilot (sha256 2c408a6cd46a), strategy S0, run aee8c8bf-d4d4-4623-a917-474e9ad0ca72, engine 2.0.0.dev1._
