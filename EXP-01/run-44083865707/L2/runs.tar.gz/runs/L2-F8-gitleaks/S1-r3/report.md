## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.175 | 0 |
| pip-audit | VALID | - | 0 | 3.626 | 0 |
| gitleaks | VALID | - | 0 | 0.327 | 0 |

_Policy policy.toml vexp01-pilot (sha256 373e9d7b615b), strategy S1, run dd46d66d-7309-43d3-a92b-236cd5179987, engine 2.0.0.dev1._
