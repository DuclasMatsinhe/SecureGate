## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.181 | 0 |
| pip-audit | VALID | - | 0 | 3.616 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.329 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 515ae87a-4375-488a-8515-ac6898ef3bcf, engine 2.0.0.dev1._
