## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.185 | 0 |
| pip-audit | VALID | - | 0 | 3.625 | 0 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.332 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run cebfc930-205b-4c5f-8e30-2d4bafccc0d3, engine 2.0.0.dev1._
