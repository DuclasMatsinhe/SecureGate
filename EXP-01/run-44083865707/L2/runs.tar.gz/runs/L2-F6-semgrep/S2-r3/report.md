## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 3.64 | 0 |
| gitleaks | VALID | - | 0 | 0.329 | 0 |

_Policy policy.toml vexp01-pilot (sha256 228ca54d0d09), strategy S2, run 3f8f56c3-c24d-4a2c-bb21-ac951a4eb2eb, engine 2.0.0.dev1._
