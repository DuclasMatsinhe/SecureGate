## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Semgrep: Semgrep report has no 'results' or 'errors' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | SCHEMA_INVALID | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 3.669 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0935b1acd1eb), strategy S3, run a2d01b90-1144-4c50-9414-91eef09d2da6, engine 2.0.0.dev1._
