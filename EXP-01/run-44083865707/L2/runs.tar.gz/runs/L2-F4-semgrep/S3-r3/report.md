## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.023 | 0 |
| pip-audit | VALID | - | 0 | 3.742 | 0 |
| gitleaks | VALID | - | 0 | 0.343 | 0 |

_Policy policy.toml vexp01-pilot (sha256 aa80d41784c9), strategy S3, run 6741bb3f-0c24-4a69-89d1-aec7bbfb2a55, engine 2.0.0.dev1._
