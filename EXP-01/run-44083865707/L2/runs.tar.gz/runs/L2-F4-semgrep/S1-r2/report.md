## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.022 | 0 |
| pip-audit | VALID | - | 0 | 3.733 | 0 |
| gitleaks | VALID | - | 0 | 0.335 | 0 |

_Policy policy.toml vexp01-pilot (sha256 91c4425bbf7f), strategy S1, run 9e34bcb4-4aa7-4651-90d8-9fc083648492, engine 2.0.0.dev1._
