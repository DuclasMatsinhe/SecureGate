## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.023 | 0 |
| pip-audit | VALID | - | 0 | 3.758 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vexp01-pilot (sha256 5e0e11ec4d2d), strategy S2, run 7addd95e-6fd1-4b86-84d7-3ee57408d54c, engine 2.0.0.dev1._
