## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: Semgrep produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | NO_OUTPUT | 0 | 0.023 | 0 |
| pip-audit | VALID | - | 0 | 3.726 | 0 |
| gitleaks | VALID | - | 0 | 0.337 | 0 |

_Policy policy.toml vexp01-pilot (sha256 91c4425bbf7f), strategy S1, run 2c47d64e-aa4f-4b75-9647-dcf202d38c8d, engine 2.0.0.dev1._
