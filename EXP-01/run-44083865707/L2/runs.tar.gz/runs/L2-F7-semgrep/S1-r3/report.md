## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INVALID_JSON`: Semgrep report is not valid JSON (Unterminated string starting at at char 653)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | INVALID_JSON | 0 | 1.227 | 0 |
| pip-audit | VALID | - | 0 | 3.631 | 0 |
| gitleaks | VALID | - | 0 | 0.337 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0d1ccdca37d4), strategy S1, run 07aead02-35bd-4b2e-9d03-6e39ba8343f9, engine 2.0.0.dev1._
