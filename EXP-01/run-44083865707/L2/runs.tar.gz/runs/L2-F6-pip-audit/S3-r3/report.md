## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.214 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.022 | 0 |
| gitleaks | VALID | - | 0 | 0.33 | 0 |

_Policy policy.toml vexp01-pilot (sha256 56f55e758b4a), strategy S3, run e26d51ab-73ce-4a94-b5a0-d29a3256b0db, engine 2.0.0.dev1._
