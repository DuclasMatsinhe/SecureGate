## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: pip-audit: pip-audit report has no 'dependencies' key

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 0 |
| pip-audit | INVALID | SCHEMA_INVALID | 0 | 0.021 | 0 |
| gitleaks | VALID | - | 0 | 0.333 | 0 |

_Policy policy.toml vexp01-pilot (sha256 56f55e758b4a), strategy S3, run ec711b46-40b0-4ce3-977c-0c3aac27f1db, engine 2.0.0.dev1._
