## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_l2_2b671p8k/not-installed/gitleaks'
- `TOOL_MISSING`: pip-audit: [Errno 2] No such file or directory: '/tmp/sg_l2_2b671p8k/not-installed/pip-audit'
- `TOOL_MISSING`: Semgrep: [Errno 2] No such file or directory: '/tmp/sg_l2_2b671p8k/not-installed/semgrep'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| pip-audit | INVALID | TOOL_MISSING | None | 0.0 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vexp01-pilot (sha256 45ecf341f606), strategy S3, run 46b91a93-42cf-4dbf-b500-938ccf05a682, engine 2.0.0.dev1._
