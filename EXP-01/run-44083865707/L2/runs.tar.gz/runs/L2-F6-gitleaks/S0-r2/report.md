## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.211 | 0 |
| pip-audit | VALID | - | 0 | 3.664 | 0 |
| gitleaks | VALID | - | 0 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 cbe6b1113ea9), strategy S0, run a8ff9527-3f59-41a8-bc80-5b2efff8ac98, engine 2.0.0.dev1._
