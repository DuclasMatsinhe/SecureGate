## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.196 | 0 |
| pip-audit | VALID | - | 0 | 3.637 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 00f6af95be2f), strategy S2, run 27a425f6-4f04-4ce8-802f-53a657bc451f, engine 2.0.0.dev1._
