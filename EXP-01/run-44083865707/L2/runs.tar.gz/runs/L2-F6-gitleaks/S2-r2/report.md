## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.193 | 0 |
| pip-audit | VALID | - | 0 | 3.645 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 00f6af95be2f), strategy S2, run df7ef277-4ccd-4a0e-9ebf-ae82d989ef5e, engine 2.0.0.dev1._
