## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.2 | 0 |
| pip-audit | VALID | - | 0 | 3.653 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 f5674b4ad65f), strategy S3, run e399ba47-7201-4ea8-a973-afe85dbe3769, engine 2.0.0.dev1._
