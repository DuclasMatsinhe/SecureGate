## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.198 | 0 |
| pip-audit | VALID | - | 0 | 3.638 | 0 |
| gitleaks | VALID | - | 0 | 0.022 | 0 |

_Policy policy.toml vexp01-pilot (sha256 cbe6b1113ea9), strategy S0, run 7db89d77-232b-4abf-a557-db445cd34a03, engine 2.0.0.dev1._
