## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.194 | 0 |
| pip-audit | VALID | - | 0 | 3.656 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 f5674b4ad65f), strategy S3, run 05bc9c59-5cd6-4fbd-acd5-d44f0ff84c19, engine 2.0.0.dev1._
