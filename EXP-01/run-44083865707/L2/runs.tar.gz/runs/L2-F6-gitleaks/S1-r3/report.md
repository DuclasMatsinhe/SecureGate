## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.196 | 0 |
| pip-audit | VALID | - | 0 | 3.644 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.022 | 0 |

_Policy policy.toml vexp01-pilot (sha256 6d15cd950936), strategy S1, run ef6ae4db-cea4-4b14-90fb-3b2dd7d0f6a4, engine 2.0.0.dev1._
