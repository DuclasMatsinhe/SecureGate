## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `TOOL_MISSING`: Gitleaks: [Errno 2] No such file or directory: '/tmp/sg_l2_2b671p8k/not-installed/gitleaks'

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.19 | 0 |
| pip-audit | VALID | - | 0 | 3.633 | 0 |
| gitleaks | INVALID | TOOL_MISSING | None | 0.0 | 0 |

_Policy policy.toml vexp01-pilot (sha256 547761d99f78), strategy S3, run e897e712-fc39-4cf1-94dc-060413c624ff, engine 2.0.0.dev1._
