## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: pip-audit exited with code 2; expected [0, 1]
- `NO_OUTPUT`: pip-audit produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.233 | 0 |
| pip-audit | INVALID | NONZERO_EXIT | 2 | 0.022 | 0 |
| gitleaks | VALID | - | 0 | 0.337 | 0 |

_Policy policy.toml vexp01-pilot (sha256 572864435e25), strategy S1, run 5429f51c-f1d8-4726-bc57-a42efe75b2a6, engine 2.0.0.dev1._
