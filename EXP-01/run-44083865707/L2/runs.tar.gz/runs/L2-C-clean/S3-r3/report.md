## SecureGate verdict: PASS

**PASS**: all required scanners produced valid evidence and no blocking findings were found.

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.19 | 0 |
| pip-audit | VALID | - | 0 | 3.604 | 0 |
| gitleaks | VALID | - | 0 | 0.329 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run d4d03e30-e1da-447d-8d06-be593d4fd261, engine 2.0.0.dev1._
