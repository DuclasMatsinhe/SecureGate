## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 2; expected [0, 3]
- `NO_OUTPUT`: Gitleaks produced no report

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.201 | 0 |
| pip-audit | VALID | - | 0 | 3.655 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 2 | 0.021 | 0 |

_Policy policy.toml vexp01-pilot (sha256 32174a9e81a2), strategy S3, run d9fee171-7aae-4e2a-a255-2a8b2d2e11e5, engine 2.0.0.dev1._
