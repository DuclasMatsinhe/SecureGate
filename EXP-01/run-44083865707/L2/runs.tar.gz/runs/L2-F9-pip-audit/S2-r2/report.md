## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report. Tool says: ERROR: No matching distribution found for securegate-nonexistent-probe-package==0.0.1

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.198 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 1 | 3.641 | 0 |
| gitleaks | VALID | - | 0 | 0.327 | 0 |

_Policy policy.toml vexp01-pilot (sha256 d195a818c8ca), strategy S2, run 0328bd76-d165-4811-a775-799ad5368b92, engine 2.0.0.dev1._
