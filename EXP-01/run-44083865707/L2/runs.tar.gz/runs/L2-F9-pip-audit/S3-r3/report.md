## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_OUTPUT`: pip-audit produced no report. Tool says: ERROR: No matching distribution found for securegate-nonexistent-probe-package==0.0.1

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 1.178 | 0 |
| pip-audit | INVALID | NO_OUTPUT | 1 | 3.669 | 0 |
| gitleaks | VALID | - | 0 | 0.332 | 0 |

_Policy policy.toml vexp01-pilot (sha256 0bec7d6bb171), strategy S3, run 8cbee209-1ae2-471c-9d2f-cbea17c3ffcc, engine 2.0.0.dev1._
