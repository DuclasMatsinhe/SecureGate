## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `SCHEMA_INVALID`: Gitleaks: Gitleaks report is not a JSON list
- `BLOCKING_FINDING`: Semgrep HIGH: tmp.sg_live_hji3r2iq.fixtures.probe-eval (app.py:2)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 1 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | SCHEMA_INVALID | 0 | 0.0 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| Semgrep | HIGH | tmp.sg_live_hji3r2iq.fixtures.probe-eval | app.py:2 | - |

_Policy inline v1.0 (sha256 0aba01b4cf14), strategy S1, run dd26b65c-306e-4d30-becf-d4ac73b9cbcb, engine 2.0.0.dev1._
