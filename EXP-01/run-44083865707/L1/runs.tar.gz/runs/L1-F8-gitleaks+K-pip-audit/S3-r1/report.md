## SecureGate verdict: INCOMPLETE

**INCOMPLETE**: security was not established, because at least one scanner's evidence is missing or invalid. This is not a security clearance. Fix the pipeline and rerun.

### Reasons

- `NO_COVERAGE`: Gitleaks found no git repository at the target, so it scanned nothing
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-192 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2023-212 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-141 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1994 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1995 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1996 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1998 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-1999 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4175 (dependency)
- `BLOCKING_FINDING`: pip-audit HIGH: PYSEC-2026-4177 (dependency)

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 1 | 0.0 | 18 |
| gitleaks | INVALID | NO_COVERAGE | 0 | 0.0 | 0 |

### Findings

| Tool | Severity | Rule | Location | Note |
|---|---|---|---|---|
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-192 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2023-212 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-141 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1999 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1998 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1995 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1994 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-1996 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4177 | dependency | - |
| pip-audit | HIGH | PYSEC-2026-4175 | dependency | - |

_Policy inline v1.0 (sha256 4ce99317fb58), strategy S3, run 5c4a1beb-a851-45ec-ab24-2889bdb0f3cb, engine 2.0.0.dev1._
