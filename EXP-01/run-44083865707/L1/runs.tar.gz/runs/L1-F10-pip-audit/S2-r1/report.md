## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `INCONSISTENT_EXIT`: pip-audit exited 1 (vulnerabilities found) but its report lists none

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | INVALID | INCONSISTENT_EXIT | 1 | 0.0 | 0 |
| gitleaks | VALID | - | 0 | 0.0 | 0 |

_Policy inline v1.0 (sha256 d134df70270f), strategy S2, run 1cfd868f-d643-4c48-be60-37fad246cfad, engine 2.0.0.dev1._
