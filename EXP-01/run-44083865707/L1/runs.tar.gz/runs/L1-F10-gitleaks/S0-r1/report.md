## SecureGate verdict: BLOCK

**BLOCK**: valid evidence shows a security problem at or above the policy threshold, or (strategies S0 to S2) a scanner failed.

### Reasons

- `NONZERO_EXIT`: Gitleaks exited with code 1; expected [0, 3]. Tool says: synthetic error

### Scanner health

| Scanner | Evidence | Category | Exit code | Time (s) | Findings |
|---|---|---|---|---|---|
| semgrep | VALID | - | 0 | 0.0 | 0 |
| pip-audit | VALID | - | 0 | 0.0 | 0 |
| gitleaks | INVALID | NONZERO_EXIT | 1 | 0.0 | 0 |

_Policy inline v1.0 (sha256 f3180d3d6d91), strategy S0, run 95e9be00-066e-457c-8c11-c970b4419cd2, engine 2.0.0.dev1._
